#!/usr/bin/env python3
"""Command-line entry point of the hololive wiki person cache v3.

The implementation lives in hololive_cache_core.py. Keeping this script small
lets Python reuse that module's cached bytecode (__pycache__) on every run
instead of recompiling it; `verify` alone always runs from the source.
`import hololive_cache` exposes the same API (Cache, Person, Page,
select_article_lines, ...).
"""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
if __name__ == "__main__" and "verify" in sys.argv[1:]:        # also after --cache DIR
    # verify checks these files, so it runs from their source, never from bytecode in __pycache__.
    sys.dont_write_bytecode = True
    _path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "hololive_cache_core.py")
    _core = type(sys)("hololive_cache_core")
    _core.__file__ = _path
    sys.modules["hololive_cache_core"] = _core
    with open(_path, "rb") as _stream:
        exec(compile(_stream.read(), _path, "exec", dont_inherit=True), _core.__dict__)
from hololive_cache_core import *  # noqa: E402,F401,F403
from hololive_cache_core import run_cli  # noqa: E402

if __name__ == "__main__":
    raise SystemExit(run_cli())
