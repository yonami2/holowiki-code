#!/usr/bin/env python3
"""v1-compatible entry point: lookup.py list/show/find/nicknames/sources on the v3 cache.

The arguments are those of the v1 lookup.py. Each command now reads catalog.json
and the named person's files instead of the 2.9 MB v1 index. The implementation
is hololive_cache_core.py; hololive_cache.py offers the full command set.
"""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from hololive_cache_core import run_cli  # noqa: E402

if __name__ == "__main__":
    raise SystemExit(run_cli())
