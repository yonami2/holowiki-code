@echo off
rem Runs hololive_cache.py with Python 3.9+ in UTF-8 mode (py -3, else python).
setlocal
set PYTHONUTF8=1
set "PYEXE="
py -3 -I -S -c "import sys; sys.exit(sys.version_info < (3, 9))" >nul 2>nul
if not errorlevel 1 set "PYEXE=py -3"
if defined PYEXE goto havepython
python -I -S -c "import sys; sys.exit(sys.version_info < (3, 9))" >nul 2>nul
if not errorlevel 1 set "PYEXE=python"
if not defined PYEXE goto nopython
:havepython
%PYEXE% "%~dp0hololive_cache.py" %*
exit /b %errorlevel%
:nopython
echo Python 3.9 or later was not found. Install it from https://www.python.org/downloads/windows/ 1>&2
echo and keep "py launcher" or tick "Add python.exe to PATH", then run this again. 1>&2
exit /b 9009
