# 索引

START_HERE.md の規則で読んでください。人物は `people/<slug>/PROFILE.md` が入口です。区分は元キャッシュの名簿の区分です。「wikiトップの掲載」はwikiのトップページでの掲載欄で、公式サイトとは照合していません。物語では会話で指定された前提を優先します。

人物 82名、本文のあるページ 1,149件（812,059行）、URLだけのページはありません。

## 人物

| 地域 | 区分 | 名前 | wikiトップの掲載 | 本文ページ | 入口 |
|---|---|---|---|---:|---|
| JP | 0期生 | ときのそら | 在籍メンバー欄に掲載 | 16/16（うち16件オンライン） | [PROFILE](people/tokino_sora/PROFILE.md) |
| JP | 0期生 | ロボ子さん | 在籍メンバー欄に掲載 | 14/14（うち14件オンライン） | [PROFILE](people/robocosan/PROFILE.md) |
| JP | 0期生 | AZKi | 在籍メンバー欄に掲載 | 14/14（うち14件オンライン） | [PROFILE](people/azki/PROFILE.md) |
| JP | 0期生 | さくらみこ | 在籍メンバー欄に掲載 | 14/14（うち14件オンライン） | [PROFILE](people/sakura_miko/PROFILE.md) |
| JP | 0期生 | 星街すいせい | 在籍メンバー欄に掲載 | 15/15（うち15件オンライン） | [PROFILE](people/hoshimachi_suisei/PROFILE.md) |
| JP | 1期生 | アキ・ローゼンタール | 在籍メンバー欄に掲載 | 14/14（うち14件オンライン） | [PROFILE](people/aki_rosenthal/PROFILE.md) |
| JP | 1期生 | 赤井はあと | 在籍メンバー欄に掲載 | 14/14（うち14件オンライン） | [PROFILE](people/akai_haato/PROFILE.md) |
| JP | 1期生 | 夜空メル | 「活動終了／卒業生メンバー」欄に掲載（元1期生） | 13/13（うち13件オンライン） | [PROFILE](people/yozora_mel/PROFILE.md) |
| JP | 1期生 | 白上フブキ | 在籍メンバー欄に掲載 | 14/14（うち14件オンライン） | [PROFILE](people/shirakami_fubuki/PROFILE.md) |
| JP | 1期生 | 夏色まつり | 在籍メンバー欄に掲載 | 14/14（うち14件オンライン） | [PROFILE](people/natsuiro_matsuri/PROFILE.md) |
| JP | 2期生 | 百鬼あやめ | 在籍メンバー欄に掲載 | 15/15（うち15件オンライン） | [PROFILE](people/nakiri_ayame/PROFILE.md) |
| JP | 2期生 | 癒月ちょこ | 在籍メンバー欄に掲載 | 14/14（うち14件オンライン） | [PROFILE](people/yuzuki_choco/PROFILE.md) |
| JP | 2期生 | 大空スバル | 在籍メンバー欄に掲載 | 14/14（うち14件オンライン） | [PROFILE](people/oozora_subaru/PROFILE.md) |
| JP | 2期生 | 湊あくあ | 「卒業生」欄に掲載（元2期生） | 14/14（うち14件オンライン） | [PROFILE](people/minato_aqua/PROFILE.md) |
| JP | 2期生 | 紫咲シオン | 「卒業生」欄に掲載（元2期生） | 14/14（うち14件オンライン） | [PROFILE](people/murasaki_shion/PROFILE.md) |
| JP | ゲーマーズ | 大神ミオ | 在籍メンバー欄に掲載 | 14/14（うち14件オンライン） | [PROFILE](people/ookami_mio/PROFILE.md) |
| JP | ゲーマーズ | 猫又おかゆ | 在籍メンバー欄に掲載 | 14/14（うち14件オンライン） | [PROFILE](people/nekomata_okayu/PROFILE.md) |
| JP | ゲーマーズ | 戌神ころね | 在籍メンバー欄に掲載 | 14/14（うち14件オンライン） | [PROFILE](people/inugami_korone/PROFILE.md) |
| JP | 3期生 | 兎田ぺこら | 在籍メンバー欄に掲載 | 14/14（うち14件オンライン） | [PROFILE](people/usada_pekora/PROFILE.md) |
| JP | 3期生 | 不知火フレア | 在籍メンバー欄に掲載 | 14/14（うち14件オンライン） | [PROFILE](people/shiranui_flare/PROFILE.md) |
| JP | 3期生 | 白銀ノエル | 在籍メンバー欄に掲載 | 14/14（うち14件オンライン） | [PROFILE](people/shirogane_noel/PROFILE.md) |
| JP | 3期生 | 宝鐘マリン | 在籍メンバー欄に掲載 | 14/14（うち14件オンライン） | [PROFILE](people/houshou_marine/PROFILE.md) |
| JP | 4期生 | 天音かなた | 「卒業生」欄に掲載（元4期生） | 14/14（うち14件オンライン） | [PROFILE](people/amane_kanata/PROFILE.md) |
| JP | 4期生 | 角巻わため | 在籍メンバー欄に掲載 | 14/14（うち14件オンライン） | [PROFILE](people/tsunomaki_watame/PROFILE.md) |
| JP | 4期生 | 常闇トワ | 在籍メンバー欄に掲載 | 14/14（うち14件オンライン） | [PROFILE](people/tokoyami_towa/PROFILE.md) |
| JP | 4期生 | 姫森ルーナ | 在籍メンバー欄に掲載 | 14/14（うち14件オンライン） | [PROFILE](people/himemori_luna/PROFILE.md) |
| JP | 5期生 | 雪花ラミィ | 在籍メンバー欄に掲載 | 15/15（うち15件オンライン） | [PROFILE](people/yukihana_lamy/PROFILE.md) |
| JP | 5期生 | 桃鈴ねね | 在籍メンバー欄に掲載 | 14/14（うち14件オンライン） | [PROFILE](people/momosuzu_nene/PROFILE.md) |
| JP | 5期生 | 獅白ぼたん | 在籍メンバー欄に掲載 | 15/15（うち15件オンライン） | [PROFILE](people/shishiro_botan/PROFILE.md) |
| JP | 5期生 | 尾丸ポルカ | 在籍メンバー欄に掲載 | 14/14（うち14件オンライン） | [PROFILE](people/omaru_polka/PROFILE.md) |
| JP | holoX | ラプラス・ダークネス | 在籍メンバー欄に掲載 | 14/14（うち14件オンライン） | [PROFILE](people/laplus_darknesss/PROFILE.md) |
| JP | holoX | 鷹嶺ルイ | 在籍メンバー欄に掲載 | 14/14（うち14件オンライン） | [PROFILE](people/takane_lui/PROFILE.md) |
| JP | holoX | 博衣こより | 在籍メンバー欄に掲載 | 15/15（うち15件オンライン） | [PROFILE](people/hakui_koyori/PROFILE.md) |
| JP | holoX | 沙花叉クロヱ | 在籍メンバー欄に掲載（【配信活動終了】の注記あり） | 14/14（うち14件オンライン） | [PROFILE](people/sakamata_chloe/PROFILE.md) |
| JP | holoX | 風真いろは | 在籍メンバー欄に掲載 | 14/14（うち14件オンライン） | [PROFILE](people/kazama_iroha/PROFILE.md) |
| JP | ReGLOSS | 火威青 | 「卒業生」欄に掲載（元DEV_IS ReGLOSS） | 14/14（うち14件オンライン） | [PROFILE](people/hiodoshi_ao/PROFILE.md) |
| JP | ReGLOSS | 音乃瀬奏 | 在籍メンバー欄に掲載 | 14/14（うち14件オンライン） | [PROFILE](people/otonose_kanade/PROFILE.md) |
| JP | ReGLOSS | 一条莉々華 | 在籍メンバー欄に掲載 | 14/14（うち14件オンライン） | [PROFILE](people/ichijou_ririka/PROFILE.md) |
| JP | ReGLOSS | 儒烏風亭らでん | 在籍メンバー欄に掲載 | 15/15（うち15件オンライン） | [PROFILE](people/juufuutei_raden/PROFILE.md) |
| JP | ReGLOSS | 轟はじめ | 在籍メンバー欄に掲載 | 14/14（うち14件オンライン） | [PROFILE](people/todoroki_hajime/PROFILE.md) |
| JP | FLOW GLOW | 響咲リオナ | 在籍メンバー欄に掲載 | 14/14（うち14件オンライン） | [PROFILE](people/isaki_riona/PROFILE.md) |
| JP | FLOW GLOW | 虎金妃笑虎 | 在籍メンバー欄に掲載 | 14/14（うち14件オンライン） | [PROFILE](people/koganei_niko/PROFILE.md) |
| JP | FLOW GLOW | 水宮枢 | 在籍メンバー欄に掲載 | 14/14（うち14件オンライン） | [PROFILE](people/mizumiya_su/PROFILE.md) |
| JP | FLOW GLOW | 輪堂千速 | 在籍メンバー欄に掲載 | 14/14（うち14件オンライン） | [PROFILE](people/rindo_chihaya/PROFILE.md) |
| JP | FLOW GLOW | 綺々羅々ヴィヴィ | 在籍メンバー欄に掲載 | 14/14（うち14件オンライン） | [PROFILE](people/kikirara_vivi/PROFILE.md) |
| JP | 1期生 | 人見クリス | メンバー一覧に未掲載 | 0/0 | [PROFILE](people/hitomi_chris/PROFILE.md) |
| JP | 3期生 | 潤羽るしあ | 「活動終了／卒業生メンバー」欄に掲載（元3期生） | 19/19（うち19件オンライン） | [PROFILE](people/uruha_rushia/PROFILE.md) |
| JP | 4期生 | 桐生ココ | 「卒業生」欄に掲載（元4期生） | 18/18（うち18件オンライン） | [PROFILE](people/kiryu_coco/PROFILE.md) |
| JP | 5期生 | 魔乃アロエ | 「活動終了／卒業生メンバー」欄に掲載（元5期生） | 6/6（うち6件オンライン） | [PROFILE](people/mano_aloe/PROFILE.md) |
| JP | アソビ★まわり隊！ | 宙科そぴあ | 在籍メンバー欄に掲載 | 9/9（うち9件オンライン） | [PROFILE](people/sorashina_sopia/PROFILE.md) |
| JP | アソビ★まわり隊！ | 熱千めら | 在籍メンバー欄に掲載 | 9/9（うち9件オンライン） | [PROFILE](people/achichi_mela/PROFILE.md) |
| JP | アソビ★まわり隊！ | 百灯キョーコ | 在籍メンバー欄に掲載 | 9/9（うち9件オンライン） | [PROFILE](people/hyakuto_kyoko/PROFILE.md) |
| JP | アソビ★まわり隊！ | 鈴鳴つづり | 在籍メンバー欄に掲載 | 9/9（うち9件オンライン） | [PROFILE](people/suzuna_tsuzuri/PROFILE.md) |
| EN | advent | Fuwawa Abyssgard | 在籍メンバー欄に掲載 | 11/11（うち11件オンライン） | [PROFILE](people/fuwawa_abyssgard/PROFILE.md) |
| EN | advent | Koseki Bijou | 在籍メンバー欄に掲載 | 14/14（うち14件オンライン） | [PROFILE](people/koseki_bijou/PROFILE.md) |
| EN | advent | Mococo Abyssgard | 在籍メンバー欄に掲載 | 11/11（うち11件オンライン） | [PROFILE](people/mococo_abyssgard/PROFILE.md) |
| EN | advent | Nerissa Ravencroft | 在籍メンバー欄に掲載 | 12/12（うち12件オンライン） | [PROFILE](people/nerissa_ravencroft/PROFILE.md) |
| EN | advent | Shiori Novella | 在籍メンバー欄に掲載 | 14/14（うち14件オンライン） | [PROFILE](people/shiori_novella/PROFILE.md) |
| EN | council | Ceres Fauna | 「卒業生」欄に掲載（元EN -Promise-） | 14/14（うち14件オンライン） | [PROFILE](people/ceres_fauna/PROFILE.md) |
| EN | council | Hakos Baelz | 在籍メンバー欄に掲載 | 14/14（うち14件オンライン） | [PROFILE](people/hakos_baelz/PROFILE.md) |
| EN | council | Nanashi Mumei | 「卒業生」欄に掲載（元EN -Promise-） | 14/14（うち14件オンライン） | [PROFILE](people/nanashi_mumei/PROFILE.md) |
| EN | council | Ouro Kronii | 在籍メンバー欄に掲載 | 14/14（うち14件オンライン） | [PROFILE](people/ouro_kronii/PROFILE.md) |
| EN | council | Tsukumo Sana | 「卒業生」欄に掲載（元EN -Council-） | 17/17（うち17件オンライン） | [PROFILE](people/tsukumo_sana/PROFILE.md) |
| EN | hope | IRyS | 在籍メンバー欄に掲載 | 14/14（うち14件オンライン） | [PROFILE](people/irys/PROFILE.md) |
| EN | justice | Cecilia Immergreen | 在籍メンバー欄に掲載 | 12/12（うち12件オンライン） | [PROFILE](people/cecilia_immergreen/PROFILE.md) |
| EN | justice | Elizabeth Rose Bloodflame | 在籍メンバー欄に掲載 | 12/12（うち12件オンライン） | [PROFILE](people/elizabeth_rose_bloodflame/PROFILE.md) |
| EN | justice | Gigi Murin | 在籍メンバー欄に掲載 | 12/12（うち12件オンライン） | [PROFILE](people/gigi_murin/PROFILE.md) |
| EN | justice | Raora Panthera | 在籍メンバー欄に掲載 | 12/12（うち12件オンライン） | [PROFILE](people/raora_panthera/PROFILE.md) |
| EN | myth | Gawr Gura | 「卒業生」欄に掲載（元EN -Myth-） | 14/14（うち14件オンライン） | [PROFILE](people/gawr_gura/PROFILE.md) |
| EN | myth | Mori Calliope | 在籍メンバー欄に掲載 | 15/15（うち15件オンライン） | [PROFILE](people/mori_calliope/PROFILE.md) |
| EN | myth | Ninomae Ina'nis | 在籍メンバー欄に掲載 | 14/14（うち14件オンライン） | [PROFILE](people/ninomae_inanis/PROFILE.md) |
| EN | myth | Takanashi Kiara | 在籍メンバー欄に掲載 | 14/14（うち14件オンライン） | [PROFILE](people/takanashi_kiara/PROFILE.md) |
| EN | myth | Watson Amelia | 在籍メンバー欄に掲載（【配信活動終了】の注記あり） | 20/20（うち20件オンライン） | [PROFILE](people/watson_amelia/PROFILE.md) |
| ID | id1 | Airani Iofifteen | 在籍メンバー欄に掲載 | 15/15（うち15件オンライン） | [PROFILE](people/airani_iofifteen/PROFILE.md) |
| ID | id1 | Ayunda Risu | 在籍メンバー欄に掲載 | 14/14（うち14件オンライン） | [PROFILE](people/ayunda_risu/PROFILE.md) |
| ID | id1 | Moona Hoshinova | 在籍メンバー欄に掲載 | 14/14（うち14件オンライン） | [PROFILE](people/moona_hoshinova/PROFILE.md) |
| ID | id2 | Anya Melfissa | 在籍メンバー欄に掲載 | 14/14（うち14件オンライン） | [PROFILE](people/anya_melfissa/PROFILE.md) |
| ID | id2 | Kureiji Ollie | 在籍メンバー欄に掲載 | 14/14（うち14件オンライン） | [PROFILE](people/kureiji_ollie/PROFILE.md) |
| ID | id2 | Pavolia Reine | 在籍メンバー欄に掲載 | 14/14（うち14件オンライン） | [PROFILE](people/pavolia_reine/PROFILE.md) |
| ID | id3 | Kaela Kovalskia | 在籍メンバー欄に掲載 | 14/14（うち14件オンライン） | [PROFILE](people/kaela_kovalskia/PROFILE.md) |
| ID | id3 | Kobo Kanaeru | 在籍メンバー欄に掲載 | 14/14（うち14件オンライン） | [PROFILE](people/kobo_kanaeru/PROFILE.md) |
| ID | id3 | Vestia Zeta | 在籍メンバー欄に掲載 | 15/15（うち15件オンライン） | [PROFILE](people/vestia_zeta/PROFILE.md) |

## 共有ページ

`python hololive_cache.py read shared <ID> --find 語` で読みます。

| ID | ページ | 行数 | wiki最終更新 | 取得日 | 取得元 |
|---|---|---:|---|---|---|
| `friendships` | [交友関係](https://seesaawiki.jp/hololivetv/d/%b8%f2%cd%a7%b4%d8%b7%b8) | 5,559 | 2026-10-05 | 2026-10-08 | オンライン取得 |
| `combos_units` | [ホロライブ【コンビ／ユニット名一覧】](https://seesaawiki.jp/hololivetv/d/%a5%db%a5%ed%a5%e9%a5%a4%a5%d6%a1%da%a5%b3%a5%f3%a5%d3%a1%bf%a5%e6%a5%cb%a5%c3%a5%c8%cc%be%b0%ec%cd%f7%a1%db) | 610 | 2026-10-04 | 2026-10-08 | オンライン取得 |
| `episodes` | [ホロライブ【エピソード集】](https://seesaawiki.jp/hololivetv/d/%a5%db%a5%ed%a5%e9%a5%a4%a5%d6%a1%da%a5%a8%a5%d4%a5%bd%a1%bc%a5%c9%bd%b8%a1%db) | 105 | 2026-01-04 | 2026-09-27 | オンライン取得 |
| `origins` | [ホロライブ【元ネタ集】](https://seesaawiki.jp/hololivetv/d/%a5%db%a5%ed%a5%e9%a5%a4%a5%d6%a1%da%b8%b5%a5%cd%a5%bf%bd%b8%a1%db) | 56 | 2025-06-01 | 2026-09-27 | オンライン取得 |
| `costumes` | [ホロライブ【衣装一覧】](https://seesaawiki.jp/hololivetv/d/%a5%db%a5%ed%a5%e9%a5%a4%a5%d6%a1%da%b0%e1%c1%f5%b0%ec%cd%f7%a1%db) | 4,563 | 2026-10-05 | 2026-10-08 | オンライン取得 |
| `activity_history` | [活動経歴一覧](https://seesaawiki.jp/hololivetv/d/%b3%e8%c6%b0%b7%d0%ce%f2%b0%ec%cd%f7) | 10,758 | 2025-04-27 | 2026-10-08 | オンライン取得 |
| `designers_modelers` | [ホロライブ【デザイナー／モデラー一覧】](https://seesaawiki.jp/hololivetv/d/%a5%db%a5%ed%a5%e9%a5%a4%a5%d6%a1%da%a5%c7%a5%b6%a5%a4%a5%ca%a1%bc%a1%bf%a5%e2%a5%c7%a5%e9%a1%bc%b0%ec%cd%f7%a1%db) | 105 | 2026-04-27 | 2026-09-27 | オンライン取得 |
| `en_glossary` | [ホロライブEN【関連語】](https://seesaawiki.jp/hololivetv/d/%a5%db%a5%ed%a5%e9%a5%a4%a5%d6EN%a1%da%b4%d8%cf%a2%b8%ec%a1%db) | 980 | 2026-09-24 | 2026-09-27 | オンライン取得 |
| `en_quotes` | [ホロライブEN【語録】](https://seesaawiki.jp/hololivetv/d/%A5%DB%A5%ED%A5%E9%A5%A4%A5%D6EN%A1%DA%B8%EC%CF%BF%A1%DB) | 382 | 2026-09-06 | 2026-09-27 | オンライン取得 |
| `group_advent` | [Advent](https://seesaawiki.jp/hololivetv/d/Advent) | 298 | 2026-10-04 | 2026-10-08 | オンライン取得 |
| `group_asobi` | [アソビ★まわり隊！](https://seesaawiki.jp/hololivetv/d/%a5%a2%a5%bd%a5%d3%a1%fa%a4%de%a4%ef%a4%ea%c2%e2%a1%aa) | 101 | 2026-10-08 | 2026-10-08 | オンライン取得 |
| `group_council` | [Council](https://seesaawiki.jp/hololivetv/d/Council) | 80 | 2026-06-21 | 2026-09-27 | オンライン取得 |
| `group_fuwamoco` | [FUWAMOCO](https://seesaawiki.jp/hololivetv/d/FUWAMOCO) | 98 | 2026-07-11 | 2026-09-27 | オンライン取得 |
| `group_fuwamoco_bgm` | [FUWAMOCO【使用BGM】](https://seesaawiki.jp/hololivetv/d/FUWAMOCO%a1%da%bb%c8%cd%d1BGM%a1%db) | 5 | 2026-09-27 | 2026-09-27 | オンライン取得 |
| `group_fuwamoco_episodes` | [FUWAMOCO【エピソード集】](https://seesaawiki.jp/hololivetv/d/FUWAMOCO%A1%DA%A5%A8%A5%D4%A5%BD%A1%BC%A5%C9%BD%B8%A1%DB) | 217 | 2026-09-17 | 2026-09-27 | オンライン取得 |
| `group_fuwamoco_membership` | [FUWAMOCO【メンバーシップ】](https://seesaawiki.jp/hololivetv/d/FUWAMOCO%A1%DA%A5%E1%A5%F3%A5%D0%A1%BC%A5%B7%A5%C3%A5%D7%A1%DB) | 31 | 2026-08-19 | 2026-09-27 | オンライン取得 |
| `group_fuwamoco_minecraft` | [FUWAMOCO【Minecraft】](https://seesaawiki.jp/hololivetv/d/FUWAMOCO%A1%DAMinecraft%A1%DB) | 12 | 2025-12-15 | 2026-09-27 | オンライン取得 |
| `group_fuwamoco_videos` | [FUWAMOCO【動画一覧】](https://seesaawiki.jp/hololivetv/d/FUWAMOCO%a1%da%c6%b0%b2%e8%b0%ec%cd%f7%a1%db) | 1,071 | 2025-12-31 | 2026-09-27 | オンライン取得 |
| `group_hololive_en` | [ホロライブEnglish](https://seesaawiki.jp/hololivetv/d/%a5%db%a5%ed%a5%e9%a5%a4%a5%d6English) | 721 | 2026-09-16 | 2026-09-27 | オンライン取得 |
| `group_id1` | [ID1期生](https://seesaawiki.jp/hololivetv/d/ID1%b4%fc%c0%b8) | 158 | 2026-10-08 | 2026-10-08 | オンライン取得 |
| `group_id2` | [ID2期生](https://seesaawiki.jp/hololivetv/d/ID2%b4%fc%c0%b8) | 145 | 2026-10-06 | 2026-10-08 | オンライン取得 |
| `group_id3` | [ID3期生](https://seesaawiki.jp/hololivetv/d/ID3%b4%fc%c0%b8) | 181 | 2026-10-04 | 2026-10-08 | オンライン取得 |
| `group_justice` | [Justice](https://seesaawiki.jp/hololivetv/d/Justice) | 196 | 2026-10-07 | 2026-10-08 | オンライン取得 |
| `group_myth` | [Myth](https://seesaawiki.jp/hololivetv/d/Myth) | 365 | 2026-09-21 | 2026-09-27 | オンライン取得 |
| `group_promise` | [Promise](https://seesaawiki.jp/hololivetv/d/Promise) | 189 | 2026-10-08 | 2026-10-08 | オンライン取得 |
| `id_glossary` | [ホロライブID【関連語】](https://seesaawiki.jp/hololivetv/d/%A5%DB%A5%ED%A5%E9%A5%A4%A5%D6ID%A1%DA%B4%D8%CF%A2%B8%EC%A1%DB) | 648 | 2026-10-06 | 2026-10-08 | オンライン取得 |
| `id_quotes` | [ホロライブID【語録】](https://seesaawiki.jp/hololivetv/d/%A5%DB%A5%ED%A5%E9%A5%A4%A5%D6ID%A1%DA%B8%EC%CF%BF%A1%DB) | 102 | 2026-09-06 | 2026-09-27 | オンライン取得 |
| `live_en_1st_concert` | [hololive English 1st Concert - Connect the World -](https://seesaawiki.jp/hololivetv/d/hololive%20English%201st%20Concert%20%2d%20Connect%20the%20World%20%2d) | 124 | 2026-01-02 | 2026-09-27 | オンライン取得 |
| `live_kiara_ina_1st_concert` | [Takanashi Kiara / Ninomae Ina'nis 1st Concert "Drawn to Dawn"](https://seesaawiki.jp/hololivetv/d/Takanashi%20Kiara%20/%20Ninomae%20Ina%27nis%201st%20Concert%20%22Drawn%20to%20Dawn%22) | 102 | 2026-04-27 | 2026-09-27 | オンライン取得 |
| `nicknames_all` | [ホロライブ【呼称一覧】](https://seesaawiki.jp/hololivetv/d/%A5%DB%A5%ED%A5%E9%A5%A4%A5%D6%A1%DA%B8%C6%BE%CE%B0%EC%CD%F7%A1%DB) | 8,768 | 2026-09-19 | 2026-10-08 | オンライン取得 |
| `wiki_top` | [ホロライブ非公式wiki](https://seesaawiki.jp/hololivetv/) | 1,651 | 2026-10-08 | 2026-10-08 | オンライン取得 |

ページの一覧（1行1ページ）は `pages.jsonl`、タイトル・URLからの逆引きは `page_index.json` にあります。
