# 熱千めら

> wikiトップ（2026-09-27取得）: 在籍メンバー欄に掲載。非公式wikiの記載で、公式サイトとは照合していない。物語では会話で指定された前提を優先する。

地域: JP
区分: アソビ★まわり隊！

## 記事の取得状況

取得記事: 9 URL（2026-09-27に取得した本文）
構造検査とモデル全文読了は別です。

## 呼称の向き（Wiki表の転記）

本人→相手が『呼び方』、相手→本人が『呼ばれ方』。

- 宙科そぴあ: 本人→相手『そぴあ』／相手→本人『めらち』
- 熱千めら: 本人→相手『わし』／相手→本人『』
- 百灯キョーコ: 本人→相手『キョーコ』／相手→本人『めらち、めらちゃん』
- 鈴鳴つづり: 本人→相手『つづり』／相手→本人『めらち、めら』

## 参照記事

- 熱千めら — 291行 — https://seesaawiki.jp/hololivetv/d/%c7%ae%c0%e9%a4%e1%a4%e9
- 熱千めら【エピソード集】 — 35行 — https://seesaawiki.jp/hololivetv/d/%c7%ae%c0%e9%a4%e1%a4%e9%a1%da%a5%a8%a5%d4%a5%bd%a1%bc%a5%c9%bd%b8%a1%db
- 熱千めら【動画一覧】 — 64行 — https://seesaawiki.jp/hololivetv/d/%c7%ae%c0%e9%a4%e1%a4%e9%a1%da%c6%b0%b2%e8%b0%ec%cd%f7%a1%db
- 熱千めら【参考資料】 — 97行 — https://seesaawiki.jp/hololivetv/d/%c7%ae%c0%e9%a4%e1%a4%e9%a1%da%bb%b2%b9%cd%bb%f1%ce%c1%a1%db
- 熱千めら【歌唱楽曲一覧】 — 3203行 — https://seesaawiki.jp/hololivetv/d/%c7%ae%c0%e9%a4%e1%a4%e9%a1%da%b2%ce%be%a7%b3%da%b6%ca%b0%ec%cd%f7%a1%db
- 熱千めら【自作作品集】 — 74行 — https://seesaawiki.jp/hololivetv/d/%c7%ae%c0%e9%a4%e1%a4%e9%a1%da%bc%ab%ba%ee%ba%ee%c9%ca%bd%b8%a1%db
- 熱千めら【衣装一覧】 — 14行 — https://seesaawiki.jp/hololivetv/d/%c7%ae%c0%e9%a4%e1%a4%e9%a1%da%b0%e1%c1%f5%b0%ec%cd%f7%a1%db
- 熱千めら【語録】 — 54行 — https://seesaawiki.jp/hololivetv/d/%c7%ae%c0%e9%a4%e1%a4%e9%a1%da%b8%ec%cf%bf%a1%db
- 熱千めら【関連語】 — 37行 — https://seesaawiki.jp/hololivetv/d/%c7%ae%c0%e9%a4%e1%a4%e9%a1%da%b4%d8%cf%a2%b8%ec%a1%db
