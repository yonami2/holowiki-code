# 熱千めら

> wikiトップ（2026-10-08取得）: 在籍メンバー欄に掲載。非公式wikiの記載で、公式サイトとは照合していない。物語では会話で指定された前提を優先する。

地域: JP
区分: アソビ★まわり隊！

## 記事の取得状況

取得記事: 9 URL（2026-09-27〜2026-10-08に取得した本文）
構造検査とモデル全文読了は別です。

## 呼称の向き（Wiki表の転記）

本人→相手が『呼び方』、相手→本人が『呼ばれ方』。

- (視聴者): 本人→相手『おぬしら』／相手→本人『』
- AZKi: 本人→相手『AZKi先輩、あずき先輩』／相手→本人『めらちゃん』
- さくらみこ: 本人→相手『みこ先輩』／相手→本人『めら、あちめらたん』
- ときのそら: 本人→相手『そら先輩』／相手→本人『』
- アキ・ローゼンタール: 本人→相手『アキロゼ先輩』／相手→本人『』
- ラプラス・ダークネス: 本人→相手『ラプ先輩』／相手→本人『』
- 一条莉々華: 本人→相手『りりか先輩』／相手→本人『めらちゃん』
- 不知火フレア: 本人→相手『フレア先輩』／相手→本人『』
- 兎田ぺこら: 本人→相手『ぺこら先輩』／相手→本人『めらちゃん』
- 博衣こより: 本人→相手『こより先輩』／相手→本人『めらちゃん』
- 夏色まつり: 本人→相手『まつり先輩』／相手→本人『あちちん、わしちゃん』
- 大神ミオ: 本人→相手『ミオ先輩』／相手→本人『』
- 大空スバル: 本人→相手『スバル先輩』／相手→本人『めらちゃん』
- 宙科そぴあ: 本人→相手『そぴあ』／相手→本人『めらち』
- 宝鐘マリン: 本人→相手『マリン先輩』／相手→本人『めらさん』
- 尾丸ポルカ: 本人→相手『ポルカ先輩』／相手→本人『』
- 続き 22件は nicknames.json（未記載行も保存）

## 参照記事

- 熱千めら — 331行 — https://seesaawiki.jp/hololivetv/d/%c7%ae%c0%e9%a4%e1%a4%e9
- 熱千めら【エピソード集】 — 47行 — https://seesaawiki.jp/hololivetv/d/%c7%ae%c0%e9%a4%e1%a4%e9%a1%da%a5%a8%a5%d4%a5%bd%a1%bc%a5%c9%bd%b8%a1%db
- 熱千めら【動画一覧】 — 64行 — https://seesaawiki.jp/hololivetv/d/%c7%ae%c0%e9%a4%e1%a4%e9%a1%da%c6%b0%b2%e8%b0%ec%cd%f7%a1%db
- 熱千めら【参考資料】 — 97行 — https://seesaawiki.jp/hololivetv/d/%c7%ae%c0%e9%a4%e1%a4%e9%a1%da%bb%b2%b9%cd%bb%f1%ce%c1%a1%db
- 熱千めら【歌唱楽曲一覧】 — 3231行 — https://seesaawiki.jp/hololivetv/d/%c7%ae%c0%e9%a4%e1%a4%e9%a1%da%b2%ce%be%a7%b3%da%b6%ca%b0%ec%cd%f7%a1%db
- 熱千めら【自作作品集】 — 100行 — https://seesaawiki.jp/hololivetv/d/%c7%ae%c0%e9%a4%e1%a4%e9%a1%da%bc%ab%ba%ee%ba%ee%c9%ca%bd%b8%a1%db
- 熱千めら【衣装一覧】 — 14行 — https://seesaawiki.jp/hololivetv/d/%c7%ae%c0%e9%a4%e1%a4%e9%a1%da%b0%e1%c1%f5%b0%ec%cd%f7%a1%db
- 熱千めら【語録】 — 82行 — https://seesaawiki.jp/hololivetv/d/%c7%ae%c0%e9%a4%e1%a4%e9%a1%da%b8%ec%cf%bf%a1%db
- 熱千めら【関連語】 — 82行 — https://seesaawiki.jp/hololivetv/d/%c7%ae%c0%e9%a4%e1%a4%e9%a1%da%b4%d8%cf%a2%b8%ec%a1%db
