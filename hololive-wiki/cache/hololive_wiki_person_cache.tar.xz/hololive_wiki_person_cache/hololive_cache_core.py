#!/usr/bin/env python3
"""Offline reader for the hololive wiki person cache v3 (standard library only).

This module holds the implementation; hololive_cache.py is its small command
line entry point, so Python can reuse this file's cached bytecode on every run.
The skill's wrapper runs it differently: it compiles this file from bytes it has
checked against MANIFEST.sha256 and calls verify_reads(), after which every file
read from the cache is hashed and compared first, hololive_story/hololive_names
are compiled the same way, and no cached bytecode is used (CacheIntegrityError).
A cache named with --cache is then checked against its own MANIFEST.sha256 (one
is required); the skill does not ship that manifest, so a change made together
with it goes unnoticed, and a difference is an error, not a reason to unpack.

Every command reads only the small files it needs: catalog.json (the whole
roster) plus the named people's card, page, nickname or source files.

  list          people, optionally one region/generation
  show          summary cards of one or more people (--digest: long JP digest;
                --section 語: only its sections whose heading has the word)
  scene         cards plus how every listed person calls every other one
  story         a bounded material pack for fiction: identity, how each one
                talks, catchphrases with their situations, personality,
                reaction cues, how the cast call one another and where they
                mention one another, with line references (hololive_story.py)
  status        each person's listing on the wiki's top page (member table,
                graduate or activity-ended sections), not checked officially
  profile       person.json (--field to pick one item)
  pages         a person's pages: id, label, lines, last update, text or URL only
  read          one page with the reader's --find/--context/--section/--start/--lines
                rules; --title/--url address it like the reader; --online asks the
                reader for pages whose text is not cached; --links lists the URLs
                of the [n] references shown; --previous reads the older version
  find          one person's pages, card and supplements (case-insensitive)
  search        every cached page (optionally one region)
  nicknames     calls=本人→相手, called_by=相手→本人; --reverse shows other tables
  sources       URLs, fetch times and HTML hashes behind a person's data
  tables        a page's tables (rowspan/colspan already resolved)
  footnotes     a page's footnotes
  check-updates compare cached pages with the live wiki through the reader (HTTP)
  verify        check every file against MANIFEST.sha256

Line numbers of pages/<id>.txt are the reader's article line numbers.
Names resolve through names.json (hololive_names.py): official names, slugs,
aliases, readings, X accounts and nicknames that the wiki's tables use for
exactly one person; kana and width differences are ignored.
Import it as a module for many lookups in one process: Cache().person("名前").
"""

from __future__ import annotations

import json
import os
import re
import sys

SCHEMAS = ("hololive-wiki-person-cache/3", "hololive-wiki-person-cache/2")
ROOT = os.path.dirname(os.path.abspath(__file__))
WORLD_NOTE = '過去の創作用設定「卒業生はいない」はwikiの事実ではありません。今回の会話で利用者が採用している場合だけ適用し、現実の所属・活動状態は公式情報を優先して確認してください。'
HEADING_NOTE = ("見出し行は解析済み見出しから再構成（リンク番号[n]なし）。本文中の [n] はリンク参照番号で、"
                "元キャッシュのページにはURL対応表が無い。")
SNAPSHOT_NOTE = "行は取得時のリーダー出力そのもの。本文中の [n] はリンク参照番号で、--links でURLを表示できる。"
NICKNAME_NOTE = "calls=本人→相手、called_by=相手→本人。空欄は資料に記載なし（不存在を意味しない）。"
READER_NAME = "hololive_wiki_reader_v31.py"
CODE_DIR = os.path.dirname(os.path.abspath(__file__))
_MODULES = {}
_VERIFIED = None        # [(root folder, {relative path: SHA-256}, shipped)] after verify_reads()


def _module(name):
    """hololive_names / hololive_story from this file's folder, loaded once (from checked source bytes,
    never cached bytecode, after verify_reads())."""
    if name not in _MODULES:
        loaded = sys.modules.get(name)
        path = os.path.join(CODE_DIR, name + ".py")
        if _VERIFIED is not None:
            loaded = type(sys)(name)
            loaded.__file__ = path
            sys.modules[name] = loaded
            exec(compile(_read_bytes(path), path, "exec", dont_inherit=True), loaded.__dict__)
        elif loaded is None or os.path.abspath(getattr(loaded, "__file__", "") or "") != path:
            import importlib.util
            spec = importlib.util.spec_from_file_location(name, path)
            loaded = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(loaded)
        _MODULES[name] = loaded
    return _MODULES[name]


class CacheError(Exception):
    pass


class CacheIntegrityError(CacheError):
    """A file of a verified cache differs from MANIFEST.sha256, is missing, or is not listed."""


def verify_reads(root, digests):
    """From now on hash every file read below root and compare it with digests ({relative: SHA-256}), the
    manifest the skill's wrapper ships: a difference raises CacheIntegrityError."""
    global _VERIFIED
    _VERIFIED = [(os.path.abspath(root), dict(digests), True)]


def _inside_root(path, root):
    """Containment after resolving links; a symlink used as the root itself remains usable."""
    resolved_root = os.path.normcase(os.path.realpath(root))
    resolved_path = os.path.normcase(os.path.realpath(path))
    return resolved_path.startswith(resolved_root.rstrip(os.sep) + os.sep)


def _verify_other_cache(root):
    """--cache under the skill's wrapper: that folder is checked against its own MANIFEST.sha256. The skill
    does not ship that manifest, so a change made together with it is not caught; a difference is an error
    (CacheError), not a reason to unpack anything again."""
    full = os.path.abspath(root)
    folded = os.path.normcase(full)
    if any(shipped and (folded == os.path.normcase(known)
                       or folded.startswith(os.path.normcase(known.rstrip(os.sep) + os.sep)))
           for known, _, shipped in _VERIFIED):
        return
    _VERIFIED[:] = [entry for entry in _VERIFIED if entry[2]]      # its manifest is read again on every command
    manifest = os.path.join(root, "MANIFEST.sha256")
    if not _inside_root(manifest, root):
        raise CacheError(f"--cache の MANIFEST.sha256 が検証対象のフォルダー外を参照しています: {manifest}")
    try:
        with open(manifest, "rb") as stream:
            raw = stream.read()
    except OSError:
        raise CacheError(f"--cache のフォルダーに MANIFEST.sha256 がありません: {root}。"
                         "スキルのラッパーは、目録で照合できるキャッシュだけを読みます。") from None
    import hashlib
    from pathlib import PurePosixPath
    digests = {"MANIFEST.sha256": hashlib.sha256(raw).hexdigest()}
    for line in raw.decode("utf-8", "replace").splitlines():
        digest, separator, name = line.partition("  ")
        path = PurePosixPath(name)
        if (separator != "  " or not re.fullmatch(r"[0-9a-f]{64}", digest) or not name
                or path.is_absolute() or ".." in path.parts or "\\" in name or ":" in name
                or str(path) != name or name in digests):
            raise CacheError(f"--cache のフォルダーの MANIFEST.sha256 を読めません: {root}")
        digests[name] = digest
    _VERIFIED.append((full, digests, False))
    sys.stderr.write("注意: --cache のキャッシュは、そのフォルダーの MANIFEST.sha256 と照合します。スキルが配布した目録では"
                     "ないため、目録ごと書き換えた変更は検出できません。違いがあっても展開し直しません。\n")


def _read_scope(path, allow_external=False):
    """Identify a checked cache before opening a file; only explicitly selected reader code may be outside."""
    full = os.path.abspath(path)
    folded = os.path.normcase(full)
    covering = [entry for entry in _VERIFIED
                if folded.startswith(os.path.normcase(entry[0].rstrip(os.sep) + os.sep))]
    if not covering:
        if allow_external:
            return None
        raise CacheError(f"キャッシュのファイルが検証対象のフォルダー外を参照しています: {path}")
    root, digests, shipped = max(covering, key=lambda entry: len(entry[0]))
    if not _inside_root(full, root):
        raise CacheError(f"キャッシュのファイルが検証対象のフォルダー外を参照しています: {path}")
    # Use the manifest's spelling: normcase lowercases on Windows (MANIFEST.sha256, START_HERE.md).
    relative = os.path.relpath(full, root).replace(os.sep, "/")
    return relative, digests, shipped


def _checked(data, scope):
    relative, digests, shipped = scope
    expected = digests.get(relative)
    if not shipped:
        if expected is None:
            if data is None:
                return None                              # not there and not listed: an ordinary missing file
            raise CacheError(f"--cache のキャッシュの目録にないファイルです: {relative}")
        if data is None:
            raise CacheError(f"--cache のキャッシュにファイルがありません（目録にはあります）: {relative}")
    elif expected is None:
        raise CacheIntegrityError(f"キャッシュの目録にないファイルです: {relative}")
    import hashlib
    if data is None or hashlib.sha256(data).hexdigest() != expected:
        if not shipped:
            raise CacheError(f"--cache のキャッシュのファイルが、そのフォルダーの MANIFEST.sha256 と違います: {relative}"
                             "（展開し直しません。キャッシュを作り直すか元に戻してください）")
        raise CacheIntegrityError(f"キャッシュのファイルが検証済みの内容と違います: {relative}")
    return data


def _read_bytes(path, *, allow_external=False):
    scope = _read_scope(path, allow_external) if _VERIFIED is not None else None
    try:
        with open(path, "rb") as stream:
            data = stream.read()
    except FileNotFoundError as exc:
        if scope is not None:
            _checked(None, scope)
        raise CacheError(f"キャッシュのファイルがありません: {path}") from exc
    return data if scope is None else _checked(data, scope)


_LAST_JSON = [None]     # the cache JSON file read last, named when data of another shape stops a command


def _json(path):
    """A cache JSON file (every one is an object). One that is not JSON, nests deeper than the decoder
    follows ([[[[...]]]]) or is not an object is a CacheError naming the file; it was a traceback. How deep
    the decoder follows depends on the platform (GitHub's Windows Python read 10,000 levels)."""
    data = _read_bytes(path)
    try:
        value = json.loads(data)
    except (ValueError, RecursionError) as exc:
        raise CacheError(f"キャッシュのファイルを JSON として読めません: {path}（{type(exc).__name__}）") from exc
    if not isinstance(value, dict):
        raise CacheError(f"キャッシュのファイルの形が違います（JSONのオブジェクトではありません）: {path}")
    _LAST_JSON[0] = path
    return value


def _text(path):
    return _read_bytes(path).decode("utf-8")


def normalize_key(text):
    """NFKC + casefold, ignoring spaces, underscores, dots and apostrophes."""
    import unicodedata
    return re.sub(r"[\s_\-・･·'’`]+", "", unicodedata.normalize("NFKC", str(text)).casefold())


def url_path_key(url):
    from urllib.parse import unquote_to_bytes, urlsplit
    parts = urlsplit(url.partition("#")[0])
    return parts.netloc.lower() + ":" + unquote_to_bytes(parts.path).hex()


# --- cache, people and pages ---------------------------------------------------

class Cache:
    def __init__(self, root=None):
        self.root = os.fspath(root) if root else ROOT
        self._catalog = None
        self._names = None
        self._page_index = None

    def path(self, *parts):
        return os.path.join(self.root, *parts)

    @property
    def catalog(self):
        if self._catalog is None:
            path = self.path("catalog.json")
            if not os.path.isfile(path):
                hint = (" v1 形式（data/index.json）です。build_fast_cache.py build で変換してください。"
                        if os.path.isfile(self.path("data", "index.json")) else "")
                raise CacheError(f"catalog.json がありません: {self.root}{hint}")
            data = _json(path)
            if data.get("schema") not in SCHEMAS:
                raise CacheError(f"未対応のキャッシュ形式です: {data.get('schema')}（{path}）")
            self._catalog = data
        return self._catalog

    @property
    def people(self):
        return self.catalog["people"]

    @property
    def names(self):
        """names.json, or (for caches built before it existed) an index of the catalog's names."""
        if self._names is None:
            names = _module("hololive_names")
            path = self.path("names.json")
            if os.path.isfile(path):
                try:
                    index = json.loads(_read_bytes(path).decode("utf-8"))
                    if index.get("schema") != names.SCHEMA:
                        raise ValueError("unsupported names index: " + str(index.get("schema")))
                    self._names = index
                except (ValueError, OSError, RecursionError, AttributeError) as exc:
                    raise CacheError(f"names.json を読めません: {exc or type(exc).__name__}") from exc
            else:
                self._names = names.build_index(self.people)
        return self._names

    def match(self, query):
        """{"slug", "name", "via", "matched"}: how a query was understood."""
        names = _module("hololive_names")
        try:
            return names.resolve(self.names, query)
        except names.NameError_ as exc:
            raise CacheError(str(exc)) from None

    def resolve(self, query):
        """Official name, slug, alias, reading or X account; then a nickname that the wiki's
        tables use for one person only; then the start of a word of a name; then part of one."""
        slug = self.match(query)["slug"]
        return next(entry for entry in self.people if entry["slug"] == slug)

    def person(self, query):
        return Person(self, self.resolve(query))

    def shared(self):
        return SharedPages(self)

    @property
    def page_index(self):
        if self._page_index is None:
            self._page_index = _json(self.path("page_index.json"))["pages"]
        return self._page_index

    def locate(self, *, title=None, url=None):
        """Find a page by exact wiki title or URL, as the reader addresses pages."""
        if url is not None:
            try:
                key = url_path_key(url)
            except ValueError as exc:
                raise CacheError(f"URLを解釈できません: {url}（{exc}）") from None
            hits = [item for item in self.page_index if item["url"] and url_path_key(item["url"]) == key]
        else:
            hits = [item for item in self.page_index if item["title"] == title]
        if not hits:
            return None
        item = hits[0]
        if item["owner"] == "shared":
            return self.shared().page(item["id"])
        if item["owner"] == "related":
            return RemotePage(item)
        return Person(self, next(e for e in self.people if e["slug"] == item["owner"])).page(item["id"])


class Person:
    def __init__(self, cache, entry):
        self.cache, self.entry = cache, entry
        self.slug, self.name = entry["slug"], entry["name"]
        self._pages = None

    def file(self, key):
        relative = self.entry["files"].get(key)
        return self.cache.path(relative) if isinstance(relative, str) else None

    def card(self):
        return _text(self.file("card"))

    def digest(self):
        path = self.file("digest")
        return _text(path) if path else None

    def info(self):
        return _json(self.file("person"))

    def nicknames(self):
        return _json(self.file("nicknames"))

    def sources(self):
        return _json(self.file("sources"))

    def pages(self):
        if self._pages is None:
            self._pages = _json(self.file("pages"))
        return self._pages

    def text_pages(self):
        directory = os.path.join(os.path.dirname(self.file("pages")), "pages")
        return [Page(directory, entry, owner=self.name) for entry in self.pages()["pages"] if entry["text"]]

    def page(self, which="main"):
        pages = self.pages()["pages"]
        entry = match_page(pages, which, prefix=self.name)
        if entry is None:
            known = "、".join(f"{p['id']}（{p['label']}）" for p in pages) or "なし"
            raise CacheError(f"{self.name} にページ「{which}」はありません。候補: {known}")
        if not entry["text"]:
            return RemotePage(entry, owner=self)
        return Page(os.path.join(os.path.dirname(self.file("pages")), "pages"), entry, owner=self.name)

    def related(self):
        return self.pages().get("related") or []


def match_page(pages, which, prefix=""):
    """Match a page id, label, full title, the title after the name, or 【label】."""
    key = normalize_key(which)
    for entry in pages:
        title = entry.get("title") or ""
        label = entry.get("label") or ""
        names = {entry["id"], label, title, "【" + label + "】"}
        if prefix and title.startswith(prefix):
            names.add(title[len(prefix):])
        if key in {normalize_key(name) for name in names if name}:
            return entry
    return None


class SharedPages:
    def __init__(self, cache):
        self.cache = cache
        self.data = _json(cache.path("shared", "pages.json"))

    def pages(self):
        return [Page(self.cache.path("shared"), entry, owner="共有ページ") for entry in self.data["pages"]]

    def page(self, which):
        entry = match_page(self.data["pages"], which)
        if entry is None:
            raise CacheError("共有ページが見つかりません。候補: "
                             + "、".join(f"{p['id']}（{p['title']}）" for p in self.data["pages"]))
        return Page(self.cache.path("shared"), entry, owner="共有ページ")


class Page:
    """One cached article: text lines plus the stored structure."""
    has_text = True

    def __init__(self, directory, entry, owner=""):
        self.directory, self.entry, self.owner = directory, entry, owner
        self._text = self._lines = self._meta = None

    @property
    def title(self):
        return self.entry["title"]

    @property
    def url(self):
        return self.entry["url"]

    @property
    def text(self):
        if self._text is None:
            self._text = _text(os.path.join(self.directory, self.entry["text"]))
        return self._text

    @property
    def lines(self):
        if self._lines is None:
            self._lines = self.text[:-1].split("\n") if self.text else []
        return self._lines

    @property
    def meta(self):
        if self._meta is None:
            self._meta = _json(os.path.join(self.directory, self.entry["meta"]))
        return self._meta

    @property
    def record(self):
        return self.meta["record"]

    @property
    def origin(self):
        return self.entry.get("origin") or "v1_cache"

    def note(self):
        return SNAPSHOT_NOTE if self.origin == "online_snapshot" else HEADING_NOTE

    def links(self):
        return self.record.get("links") or {}

    def previous(self):
        """The older cached version of a page that an online snapshot replaced."""
        older = self.entry.get("previous")
        if not older:
            raise CacheError(f"{self.title} に旧版はありません。")
        # Identity is shared, but version-specific values belong to the old
        # metadata. Never label a v1 page with the new snapshot's reader/counts.
        meta = _json(os.path.join(self.directory, older["meta"]))
        entry = {key: self.entry[key] for key in ("id", "title", "label", "role", "url")
                 if key in self.entry}
        for key in ("title", "url", "last_updated", "fetched_at", "html_sha256",
                    "line_count", "sections", "tables", "footnotes", "links",
                    "origin", "reader_version"):
            if key in meta:
                entry[key] = meta[key]
        entry.update(older)
        entry["previous"] = None
        entry.setdefault("links", len(meta.get("record", {}).get("links") or {}))
        previous = Page(self.directory, entry, owner=self.owner)
        previous._meta = meta
        return previous

    def headings(self):
        return [{"level": s["level"], "text": s["heading"], "article_line": s["article_line"],
                 "path": s.get("path", [])} for s in self.record.get("sections") or []]

    def select(self, **options):
        return select_article_lines({"lines": self.lines, "headings": self.headings()}, Options(**options))

    def tables(self, section=None):
        tables = self.record.get("tables") or []
        if section is None:
            return tables
        found = [table for table in tables if section in (table.get("section") or [])]
        bare = bare_heading(section)
        if not found and bare and bare != section:
            found = [table for table in tables if bare in (table.get("section") or [])]
        return found

    def footnotes(self):
        return self.record.get("footnotes") or {}

    def grep(self, folded_term):
        """(line number, line) whose casefolded text contains the term."""
        if folded_term not in self.text.casefold():
            return []
        return [(number, line) for number, line in enumerate(self.lines, 1) if folded_term in line.casefold()]


def bare_heading(text):
    """A heading as copied from the displayed text ("123: #### 2024年  [186]") without the line number,
    the # marks and the trailing link numbers, which the heading's own text does not carry."""
    text = re.sub(r"^\s*(?:\d+:\s*)?#{1,6}\s+", "", text)
    return re.sub(r"(?:\s*\[\d+\])+\s*$", "", text).strip()


class RemotePage:
    """A page known only by URL and metadata; its text is not in the cache."""
    has_text = False

    def __init__(self, entry, owner=None):
        self.entry, self.owner = entry, owner
        self.title, self.url = entry["title"], entry["url"]


# --- the reader's selection rules (kept identical; see the parity tests) -------

class Options:
    def __init__(self, section=None, find=None, context=0, start=1, lines=80, all=False):
        if context and find is None:
            raise CacheError("--context には --find が必要です。")
        if start < 1 or lines < 1:
            raise CacheError("--start と --lines は1以上です。")
        self.section, self.find, self.context = section, find, context
        self.start, self.lines, self.all = start, lines, all


def select_article_lines(parsed, args):
    """Port of hololive_wiki_reader_v31.select_article_lines (v3.8.3)."""
    import bisect
    numbered = list(enumerate(parsed["lines"], 1))
    section = None
    if args.section is not None:
        marks = []
        for entry in parsed.get("headings", []):
            start = entry.get("article_line")
            if not start:
                continue
            match = re.match(r"^(#{1,6})\s+", parsed["lines"][start - 1])
            if match and len(match.group(1)) == entry["level"]:
                marks.append({"line": start, "level": entry["level"], "text": entry["text"], "heading": entry})
        exact = [mark for mark in marks if mark["text"] == args.section]
        candidates = exact or [mark for mark in marks if args.section in mark["text"]]
        if not candidates:
            # A heading copied from the displayed text ("#### 2024年  [186]") carries the marks and link
            # numbers that the heading's own text does not; only then drop them and try again.
            bare = bare_heading(args.section)
            if bare and bare != args.section:
                exact = [mark for mark in marks if mark["text"] == bare]
                candidates = exact or [mark for mark in marks if bare in mark["text"]]
        if not candidates:
            raise CacheError(f"見出しが見つかりません: {args.section}")
        if len(candidates) != 1:
            raise CacheError("複数の見出しに一致します。より詳しく指定してください: "
                             + " / ".join(f"{m['line']}行 {m['text']}" for m in candidates[:20]))
        chosen = candidates[0]
        end = next((mark["line"] - 1 for mark in marks
                    if mark["line"] > chosen["line"] and mark["level"] <= chosen["level"]), len(numbered))
        section = {"heading": chosen["text"], "level": chosen["level"], "start_line": chosen["line"],
                   "end_line": end, "total_lines": end - chosen["line"] + 1,
                   "source_heading": chosen["heading"]}
        numbered = [(i, line) for i, line in numbered if chosen["line"] <= i <= end]
    matches = numbered if args.find is None else [(i, line) for i, line in numbered if args.find in line]
    selection = matches
    contextual = args.find is not None and args.context
    if contextual:
        wanted = {j for i, _ in matches for j in range(max(1, i - args.context), i + args.context + 1)}
        selection = [(i, line) for i, line in numbered if i in wanted]
    offset = 0 if args.all else args.start - 1
    selection_offset = offset
    if contextual and not args.all:
        if offset >= len(matches):
            selected = []
            selection_offset = len(selection)
        else:
            first_match = matches[offset][0]
            lower = max(first_match - args.context, matches[offset - 1][0] + 1 if offset else 1)
            selection_lines = [line for line, _ in selection]
            selection_offset = bisect.bisect_left(selection_lines, lower)
            first_position = bisect.bisect_left(selection_lines, first_match)
            selection_offset = max(selection_offset, first_position - args.lines + 1)
            selected = selection[selection_offset:selection_offset + args.lines]
    else:
        selected = selection if args.all else selection[offset:offset + args.lines]
    info = {"more_before": selection_offset > 0 and bool(selection),
            "more_after": selection_offset + len(selected) < len(selection),
            "total_selection_lines": len(selection), "selection_offset": selection_offset + 1}
    if section:
        info["section"] = section
    if args.find is not None:
        last_line = selected[-1][0] if selected else float("inf")
        more_matches = any(line > last_line for line, _ in matches[offset:])
        info.update(total_matches=len(matches), more_matches=more_matches, match_offset=offset + 1, context=args.context)
    return selected, info


# --- commands ---------------------------------------------------------------------

def out(text=""):
    sys.stdout.write(text + "\n")


def cmd_list(cache, args):
    shown = 0
    for entry in cache.people:
        if args.region and entry["region"] != args.region:
            continue
        if args.generation and normalize_key(args.generation) not in normalize_key(entry["generation"]):
            continue
        out(f"{entry['region']}\t{entry['generation']}\t{entry['name']}\t{entry['slug']}\t"
            f"{entry['status']}\t本文{entry['pages_with_text']}/{entry['pages_known']}ページ")
        shown += 1
    if not shown:
        # stdout stays the bare rows; the empty answer is said on stderr, as tables does.
        sys.stderr.write("条件に合う人物はいません（--region・--generation）。条件を付けない list で、地域と期の表記を確認できます。\n")


def header(person):
    entry = person.entry
    info = person.info()
    status = info["status"]
    lines = [f"{entry['name']} | {entry['region']} | {entry['generation']}", WORLD_NOTE,
             f"cache={status['collection_status']} pages={entry['pages_with_text']}/{entry['pages_known']} "
             f"machine={status['structural_audit']} model_full_read={status['model_full_read']}"]
    listing = info.get("wiki_status")
    if listing:
        lines.append(f"{listing['label']}（公式未照合。物語では会話の前提を優先）")
    if status.get("coverage_note"):
        lines.append("資料注記: " + status["coverage_note"])
    if not entry["pages_with_text"] and entry["pages_known"]:
        lines.append("本文は未収録（URL・行数のみ）。read <名前> <ページ> --online でリーダー取得できます。")
    elif entry["pages_with_text"] < entry["pages_known"]:
        lines.append(f"本文があるのは {entry['pages_with_text']}/{entry['pages_known']} ページ（pages で一覧）。"
                     "残りは read <名前> <ページ> --online でリーダー取得できます。")
    if entry.get("pages_from_online_snapshots"):
        lines.append(f"うち {entry['pages_from_online_snapshots']} ページはオンライン取得の新しい版（取得日は pages / sources）。")
    return "\n".join(lines)


# A digest longer than this is announced with its headings (the story pack's --part size).
DIGEST_NOTE_CHARACTERS = 15000
MARKDOWN_HEADING = re.compile(r"^(#{1,6})\s+(.*?)\s*$")


def digest_headings(lines):
    """[(index, level, text)] of a digest's heading lines."""
    return [(index, len(match.group(1)), match.group(2)) for index, line in enumerate(lines)
            for match in (MARKDOWN_HEADING.match(line),) if match]


def digest_heading_names(text):
    """The digest's section headings (##), as one line."""
    return " / ".join(heading for _, level, heading in digest_headings(text.split("\n")) if level == 2)


def digest_sections(text, words):
    """(the title line and the sections of a digest whose heading is one of the words, else contains it,
    each with its subsections, in the digest's order; the words that no heading contains). A heading
    copied with its # marks is found too."""
    lines = text.rstrip("\n").split("\n")
    marks = [mark for mark in digest_headings(lines) if mark[1] >= 2]
    spans, missing = [], []
    for word in words:
        key = bare_heading(word)
        # A heading that is the word itself wins (### 口癖, not all of ## 語録（口癖・定番の台詞）).
        found = [mark for mark in marks if mark[2] == key] or [mark for mark in marks if key in mark[2]]
        if not found:
            missing.append(word)
        for index, level, _ in found:
            spans.append((index, next((other for other, other_level, _ in marks
                                       if other > index and other_level <= level), len(lines))))
    merged = []
    for start, end in sorted(spans):
        if merged and start < merged[-1][1]:            # a subsection of a section already chosen
            merged[-1] = (merged[-1][0], max(merged[-1][1], end))
        else:
            merged.append((start, end))
    out_lines = lines[:1] if lines and lines[0].startswith("# ") else []
    if missing:
        out_lines += ["", f"（このダイジェストには「{'」「'.join(missing)}」を含む見出しがない。"
                          f"見出し: {digest_heading_names(text)}）"]
    for start, end in merged:
        chunk = lines[start:end]
        while chunk and not chunk[-1].strip():
            chunk.pop()
        out_lines += [""] + chunk
    return "\n".join(out_lines) + "\n", missing


def digest_note(person, text):
    """For a long digest: its length and its sections' headings and lengths, to read it by --section."""
    lines = text.split("\n")
    marks = [mark for mark in digest_headings(lines) if mark[1] == 2]
    sizes = []
    for position, (index, _, heading) in enumerate(marks):
        end = marks[position + 1][0] if position + 1 < len(marks) else len(lines)
        sizes.append(f"{heading}（{sum(len(line) + 1 for line in lines[index:end]):,}字）")
    return (f"（{person.name}のダイジェストは{len(text):,}字。出力が途中で省略される場合は、--section 見出しの語 で"
            f"節ごとに読める（繰り返し可）。見出し: " + "、".join(sizes) + "）\n")


def cmd_show(cache, args):
    if args.section and not args.digest:
        raise CacheError("--section は --digest と使います（ダイジェストの節だけを出す）。")
    people = [cache.person(name) for name in args.person]
    # Every text first: a missing digest, or --section words that no digest has, stop the command before
    # anything is printed (a person without one word's heading is told so in the output).
    texts = [person.digest() if args.digest else person.card() for person in people]
    for person, text in zip(people, texts):
        if text is None:
            raise CacheError(f"{person.name} にはダイジェストがありません（JP45名のみ）。--digest を外してください。")
    if args.section:
        if not all(bare_heading(word) for word in args.section):
            raise CacheError("--section には見出しの語を指定してください。")
        chosen = [digest_sections(text, args.section) for text in texts]
        if all(missing == args.section for _, missing in chosen):
            # Nothing to show: say which headings there are (those of the first person).
            raise CacheError(f"ダイジェストに見出しが見つかりません: {' / '.join(args.section)}"
                             f"（{people[0].name} の見出し: {digest_heading_names(texts[0])}）")
        texts = [text for text, _ in chosen]
    elif args.digest:
        # Written first, so that a reader whose tool cuts the long output off sees it before the cut.
        notes = [digest_note(person, text) for person, text in zip(people, texts) if len(text) > DIGEST_NOTE_CHARACTERS]
        if notes:
            sys.stderr.write("".join(notes))
            sys.stderr.flush()
    for position, (person, text) in enumerate(zip(people, texts)):
        if position:
            out("\n" + "=" * 40 + "\n")
        out(header(person))
        out()
        sys.stdout.write(text if text.endswith("\n") else text + "\n")


def pair_names(cache, people):
    """How each listed person calls each other one, from both people's tables."""
    rows = []
    tables = {person.slug: person.nicknames() for person in people}
    for speaker in people:
        for target in people:
            if speaker is target:
                continue
            own = [r for r in tables[speaker.slug]["records"] if r.get("counterpart_slug") == target.slug]
            other = [r for r in tables[target.slug]["records"] if r.get("counterpart_slug") == speaker.slug]
            rows.append({"from": speaker.name, "to": target.name,
                         "from_table": "、".join(dict.fromkeys(r["calls"] for r in own if r["calls"])),
                         "to_table": "、".join(dict.fromkeys(r["called_by"] for r in other if r["called_by"]))})
    return rows


def cmd_scene(cache, args):
    people = []
    for name in args.person:
        person = cache.person(name)
        if all(person.slug != other.slug for other in people):
            people.append(person)
    if len(people) < 2:
        raise CacheError("scene には2人以上を指定してください。")
    out(WORLD_NOTE)
    out("## 呼び方（A→B）。左=Aの呼称表の『呼び方』、右=Bの呼称表の『呼ばれ方』。空欄は記載なし。")
    for row in pair_names(cache, people):
        agree = row["from_table"] and row["from_table"] == row["to_table"]
        out(f"- {row['from']}→{row['to']}: {row['from_table'] or '—'}"
            + ("" if agree else f" ／ {row['to']}側の表: {row['to_table'] or '—'}"))
    for person in people:
        page = next((p for p in person.pages()["pages"] if p["id"] == "nicknames_page" and not p["text"]), None)
        if page is not None:
            out(f"※ {person.name} の呼称一覧ページは本文未収録（上の値は個別ページ内の表から）。"
                f"read {json.dumps(person.name, ensure_ascii=False)} nicknames_page --online で確認できる（HTTP）。")
    for person in people:
        info = person.info()
        quick = info.get("quick") or {}
        out(f"\n## {person.name}（{person.entry['region']} / {person.entry['generation']}）")
        if info.get("wiki_status"):
            out(f"- {info['wiki_status']['label']}（公式未照合。物語では会話の前提を優先）")
        if info.get("self_reference_row"):
            out(f"- 自称（呼称表の本人行）: {info['self_reference_row']}")
        for key, label in (("one_line_persona", "人物像（wiki冒頭の抜粋）"), ("speech", "話し方"), ("relationships", "関係")):
            if quick.get(key):
                out(f"- {label}: {quick[key]}")
        if not args.brief:
            out()
            card = person.card()
            sys.stdout.write(card if card.endswith("\n") else card + "\n")


STATUS_CHOICES = ("listed", "graduated", "graduated_or_ended", "ended", "staff", "not_listed", "not_active")


def cmd_status(cache, args):
    entries = [cache.resolve(name) for name in args.person] if args.person else cache.people
    rows = []
    for entry in entries:
        listing = Person(cache, entry).info().get("wiki_status")
        category = listing["category"] if listing else None
        if args.category == "not_active":
            if category not in {"graduated", "graduated_or_ended", "ended", "staff"} and not (listing or {}).get("stream_activity_ended_note"):
                continue
        elif args.category and category != args.category:
            continue
        rows.append({"name": entry["name"], "slug": entry["slug"], "region": entry["region"],
                     "generation": entry["generation"], "category": category,
                     "label": listing["label"] if listing else None,
                     "stream_activity_ended_note": bool((listing or {}).get("stream_activity_ended_note")),
                     "source": (listing or {}).get("source")})
    caveat = next((Person(cache, entry).info().get("wiki_status", {}).get("caveat") for entry in entries), None)
    if args.format == "json":
        out(json.dumps({"caveat": caveat, "world_note": WORLD_NOTE, "people": rows}, ensure_ascii=False, indent=1))
        return 0
    out("wikiトップの掲載欄（記録）。" + (caveat or "wikiトップの記録がないキャッシュです。"))
    out(WORLD_NOTE)
    for row in rows:
        source = row["source"] or {}
        where = (f"shared/{source['shared_page']}.txt {source['line']}行" if source.get("shared_page") and source.get("line")
                 else (f"{source.get('url')} {source.get('line')}行" if source.get("line") else "—"))
        out(f"{row['name']}\t{row['region']}\t{row['generation']}\t{row['label'] or '記録なし'}\t根拠: {where}")
    if not rows:
        out("該当なし。")
    return 0


def cmd_story(cache, args):
    return _module("hololive_story").run(cache, args, core=sys.modules[__name__])


def cmd_profile(cache, args):
    info = cache.person(args.person).info()
    if args.field:
        if args.field not in info:
            raise CacheError("項目がありません。候補: " + "、".join(info))
        info = info[args.field]
    out(json.dumps(info, ensure_ascii=False, indent=1))


def cmd_pages(cache, args):
    if args.person in {"shared", "共有"}:
        for page in cache.shared().pages():
            entry = page.entry
            out(f"{entry['id']}\t{entry['label']}\t{entry['line_count']}行\t{text_state(entry)}\t"
                f"最終更新={entry['last_updated']}\t{entry['title']}")
        return
    person = cache.person(args.person)
    data = person.pages()
    out(f"{person.name}: {data['text_status']}")
    for entry in data["pages"]:
        lines = entry["line_count"] if entry["line_count"] is not None else "?"
        out(f"{entry['id']}\t{entry['label']}\t{lines}行\t{text_state(entry)}\t"
            f"最終更新={entry['last_updated'] or '—'}\t{entry['title']}")
    related = data.get("related") or []
    cached = [item for item in related if item.get("shared_page")]
    if cached:
        out("関連する共有ページ（本文あり、read shared <ID>）:")
        for item in cached:
            out(f"\t{item['shared_page']}\t{item['title']}")
    if related and args.related:
        out("関連する共有記事（URLのみ）:")
        for item in related:
            if not item.get("shared_page"):
                out(f"\t{item['title']}\t{item['line_count']}行\t{item['url']}")


def text_state(entry):
    if not entry.get("text"):
        return "URLのみ"
    if entry.get("origin") == "online_snapshot":
        state = f"本文あり（{(entry.get('fetched_at') or '')[:10]} オンライン取得）"
        return state + ("・旧版あり --previous" if entry.get("previous") else "")
    return "本文あり"


def resolve_page(cache, args):
    if args.title or args.url:
        return cache.locate(title=args.title, url=args.url)
    if args.person is None:
        raise CacheError("人物名か --title / --url を指定してください。")
    if args.person in {"shared", "共有"}:
        return cache.shared().page(args.page or "")
    return cache.person(args.person).page(args.page or "main")


def find_reader(explicit=None):
    # tools/ holds the reader with its ad filter. The copy under vendor/ belongs
    # to the v1 archive (restore-v1) and is never used for reading.
    candidates = [explicit] if explicit else [
        os.path.join(ROOT, "tools", READER_NAME), os.path.join(ROOT, READER_NAME),
        os.path.join(os.getcwd(), READER_NAME), os.path.join(os.path.dirname(ROOT), READER_NAME)]
    for path in candidates:
        if path and os.path.isfile(path):
            return path
    raise CacheError("リーダー hololive_wiki_reader_v31.py が見つかりません（tools/ に同梱）。--reader で場所を指定してください。")


def _reader_run(argv, **options):
    """Run the reader. After verify_reads() its code is checked first, and Python neither reads nor
    writes bytecode for it: an empty private pycache prefix hides every __pycache__ folder."""
    import subprocess
    if _VERIFIED is None:
        return subprocess.run(argv, **options)
    import shutil
    import tempfile
    reader = argv[1]
    for path in (reader, os.path.join(os.path.dirname(reader), "hololive_adblock.py")):
        if os.path.isfile(path):
            _read_bytes(path, allow_external=True)
    prefix = tempfile.mkdtemp(prefix="hololive-wiki-reader-")
    try:
        env = dict(os.environ, PYTHONDONTWRITEBYTECODE="1", PYTHONPYCACHEPREFIX=prefix)
        return subprocess.run([argv[0], "-B"] + argv[1:], env=env, **options)
    finally:
        shutil.rmtree(prefix, ignore_errors=True)


def run_reader(args, url=None, title=None):
    argv = [sys.executable, find_reader(args.reader)] + (["--url", url] if url else ["--title", title])
    for flag in ("find", "section"):
        if getattr(args, flag) is not None:
            argv += ["--" + flag, getattr(args, flag)]
    if args.context:
        argv += ["--context", str(args.context)]
    argv += ["--start", str(args.start), "--lines", str(args.lines), "--format", args.format]
    # The wiki writes characters beyond the BMP (emoji) as pairs of UTF-16 surrogate references, which HTML
    # parsing turns into U+FFFD each; utf16 joins such pairs, as the cache and check-updates read them.
    argv += ["--surrogate-charrefs", "utf16"]
    if args.all:
        argv.append("--all")
    if args.tables:
        argv.append("--tables")
    if args.links:
        argv += ["--links", "references"]
    if args.footnotes:
        argv += ["--footnotes", "markers"]
    if args.reader_cache_dir:
        argv += ["--cache-dir", args.reader_cache_dir]
    sys.stdout.flush()
    return _reader_run(argv).returncode


def cmd_read(cache, args):
    page = resolve_page(cache, args)
    if page is None or not page.has_text:
        if args.previous:
            raise CacheError("旧版はキャッシュ未収録です。--previous では現在のwikiを取得しません。")
        if not args.online:
            where = page.url if page is not None else (args.url or args.title)
            raise CacheError(f"本文はキャッシュ未収録です: {where}。--online を付けるとリーダーで取得します（HTTP通信あり）。")
        return run_reader(args, url=page.url if page is not None else args.url,
                          title=None if page is not None or args.url else args.title)
    if args.previous:
        page = page.previous()
    selected, info = page.select(section=args.section, find=args.find, context=args.context,
                                 start=args.start, lines=args.lines, all=args.all)
    tables = page.tables(info["section"]["heading"] if "section" in info else None) if args.tables else None
    notes = {}
    if args.footnotes:
        available = page.footnotes()
        numbers = dict.fromkeys(n for _, line in selected for n in re.findall(r"\*(\d+)", line))
        notes = {n: available[n] for n in numbers if n in available}
    links = None
    if args.links:
        available = page.links()
        numbers = dict.fromkeys(n for _, line in selected for n in re.findall(r"\[(\d+)\]", line))
        links = {n: available[n] for n in numbers if n in available}
    entry = page.entry
    if args.format == "json":
        result = {"source": "person_cache", "from_cache": True, "http_requests": 0, "owner": page.owner,
                  "page_id": entry["id"], "page_title": entry["title"], "label": entry.get("label"),
                  "url": entry["url"], "last_updated": entry.get("last_updated"),
                  "fetched_at": entry.get("fetched_at"), "html_sha256": entry.get("html_sha256"),
                  "origin": page.origin, "reader_version": entry.get("reader_version"),
                  "previous_version_available": bool(entry.get("previous")),
                  "total_lines": len(page.lines), "returned_lines": len(selected), **info,
                  "lines": [{"line": i, "text": text} for i, text in selected],
                  "headings": page.headings(), "limitations": page.note()}
        if tables is not None:
            result["tables"] = tables
        if args.footnotes:
            result["footnotes"] = notes
        if links is not None:
            result["links"] = links
        out(json.dumps(result, ensure_ascii=False, indent=1))
        return 0
    out(f"# {entry['title']}（{page.owner} / {entry.get('label') or entry['id']}）")
    out(f"url: {entry['url']}")
    origin = "オンライン取得" if page.origin == "online_snapshot" else "元キャッシュ"
    out(f"source: person_cache（通信なし・{origin}） fetched_at: {entry.get('fetched_at')} "
        f"最終更新: {entry.get('last_updated')}" + ("（旧版あり: --previous）" if entry.get("previous") else ""))
    summary = (f"Article lines: {len(page.lines)}; selection lines: {info['total_selection_lines']}; "
               f"returned: {len(selected)}; more_after: {info['more_after']}")
    if "total_matches" in info:
        summary += f"; matches: {info['total_matches']}; more_matches: {info['more_matches']}"
    out(summary)
    if "section" in info:
        section = info["section"]
        out(f"section: {section['heading']}（{section['start_line']}–{section['end_line']}行）")
    for number, text in selected:
        out(f"{number}: {text}")
    if tables is not None:
        out(f"Tables ({len(tables)}):")
        out(json.dumps(tables, ensure_ascii=False))
    if notes:
        out("Footnotes for displayed lines:")
        for number, note in notes.items():
            out(f"*{number}: {note.get('display_text', note.get('text', ''))}")
    if links:
        out("Links for displayed lines:")
        for number, url in links.items():
            out(f"[{number}] {url}")
    elif args.links and not page.links():
        out("Links: このページ（元キャッシュ）にはURL対応表がありません。")
    out("NOTE: " + page.note())
    return 0


def text_sources(person):
    """(title, grep) for a person's cached pages, then card and supplement files."""
    for page in person.text_pages():
        yield page.title, page.grep
    yield "card.md", lines_grep(person.card().splitlines())
    for relative in person.entry["files"].get("supplement", []):
        data = _json(person.cache.path(relative))
        yield os.path.basename(relative), lines_grep(json.dumps(data, ensure_ascii=False, indent=2).splitlines())


def clip_line(line, width):
    """A matched line as find/search show it: cut at width characters, marked with … (read shows it whole)."""
    return line if len(line) <= width else line[:width] + "…"


def lines_grep(lines):
    return lambda term: [(n, line) for n, line in enumerate(lines, 1) if term in line.casefold()]


def cmd_find(cache, args):
    person = cache.person(args.person)
    term = args.term.casefold()
    total = 0
    for title, grep in text_sources(person):
        for number, line in grep(term):
            out(f"{title}:{number}: {clip_line(line, 450)}")
            total += 1
            if total >= args.limit:
                out(f"表示上限 {args.limit} 件。全件は --limit を増やしてください。")
                return
    out(f"表示 {total} 件")


def cmd_search(cache, args):
    term = args.term.casefold()
    total = 0

    def hits():
        for entry in cache.people:
            if args.region and entry["region"] != args.region:
                continue
            person = Person(cache, entry)
            for title, grep in text_sources(person):
                for number, line in grep(term):
                    yield person.name, title, number, line
        if not args.no_shared and not args.region:
            for page in cache.shared().pages():
                for number, line in page.grep(term):
                    yield "共有", page.title, number, line
    for name, title, number, line in hits():
        out(f"{name}\t{title}:{number}: {clip_line(line, 300)}")
        total += 1
        if total >= args.limit:
            out(f"表示上限 {args.limit} 件。--limit で増やせます。")
            return
    out(f"表示 {total} 件")


def cmd_nicknames(cache, args):
    person = cache.person(args.person)
    data = person.nicknames()
    section = person.info().get("nickname_page_section")
    query = args.query.casefold() if args.query else None
    target = None
    if args.query:
        try:
            target = cache.resolve(args.query)["slug"]
        except CacheIntegrityError:
            raise
        except CacheError:
            target = None
    out(NICKNAME_NOTE)
    shown = 0
    if args.reverse:
        out(f"他の人物の呼称表にある {person.name} の行:")
        for item in data["mentioned_by"]:
            if query and not (query in item["by"].casefold() or item["by_slug"] == target):
                continue
            out(f"{item['by']}: {item['by']}→{person.name}={item['by_calls_self'] or '—'}; "
                f"{person.name}→{item['by']}={item['self_calls_by'] or '—'}")
            shown += 1
        if not shown:
            out("該当する記録なし。")
        return
    for item in data["records"]:
        if not args.all and not (item["calls"] or item["called_by"]):
            continue
        if query and not (query in item["counterpart"].casefold() or (target and item.get("counterpart_slug") == target)):
            continue
        out(f"{item['counterpart']}: 呼び方={item['calls']}; 呼ばれ方={item['called_by']}")
        shown += 1
    if not data["records"]:
        out("呼称レコードなし。")
    elif not shown:
        out("該当する呼称記録なし。--all で未記載行も、--reverse で相手側の表も表示できます。")
    if section:
        out(f"全員分の呼称表（オンライン取得）: read shared {section['shared_page']} --section \"{section['section']}\"")


def cmd_sources(cache, args):
    person = cache.person(args.person)
    data = person.sources()
    if not any(data.get(key) for key in ("online_snapshots", "primary_sources", "snapshots", "shared_related_pages",
                                         "needs_review")):
        out(f"{person.name}: 出典の記録なし（このキャッシュには、この人物のために取得したページがありません。"
            "記事の有無は pages で確認できます）。")
        return
    if data.get("online_snapshots"):
        out("オンライン取得（リーダー、広告ブロック strict）:")
        for item in data["online_snapshots"]:
            out(f"{item['title']} | {item['fetched_at']} | {item['html_sha256']} | reader {item['reader_version']} | {item['url']}")
    if data["primary_sources"]:
        out("JP構造化アーカイブの元ソース:")
        for item in data["primary_sources"]:
            out(f"{item['title']} | {item['fetched_at']} | {item['html_sha256']} | {item['url']}")
    if data["snapshots"]:
        out("reader生JSONスナップショット（本文は未同梱）:")
        for item in data["snapshots"]:
            out(f"{item['title']} | {item['fetched_at']} | {item['html_sha256']} | {item['audit']['status']} | {item['url']}")
    if data["shared_related_pages"]:
        out("関連する共有記事:")
        for item in data["shared_related_pages"]:
            out(f"{item['title']} | {item['fetched_at']} | {item['audit']['status']} | {item['url']}")
    if data["needs_review"]:
        out("要確認: " + json.dumps(data["needs_review"], ensure_ascii=False))


def cmd_tables(cache, args):
    page = resolve_page(cache, args)
    if page is None or not page.has_text:
        raise CacheError("本文未収録のページには表がありません。")
    tables = page.tables(args.section)
    if not tables and args.section is not None:
        # A table's section is the list of its headings' full texts, so a heading that is not one of them
        # is named as missing (read finds part of a heading, tables does not), not answered with no tables.
        heads = [heading["text"] for heading in page.headings()]
        bare = bare_heading(args.section)
        if args.section not in heads and bare not in heads:
            near = [text for text in heads if (bare or args.section) in text]
            raise CacheError(f"見出しが見つかりません: {args.section}" + (
                "（tables --section は見出しの全文で指定します。候補: " + " / ".join(near[:20]) + "）" if near else ""))
    out(json.dumps(tables, ensure_ascii=False, indent=None if args.compact else 1))
    if not tables:
        sys.stderr.write("この見出しの下に表はありません。\n" if args.section is not None
                         else "表なし（一覧系ページの表は本文行に含まれます）。\n")


def cmd_footnotes(cache, args):
    page = resolve_page(cache, args)
    if page is None or not page.has_text:
        raise CacheError("本文未収録のページには脚注がありません。")
    notes = page.footnotes()
    if not notes and not args.numbers:
        out("（このページに脚注はありません）")
    for number in args.numbers or list(notes):
        note = notes.get(str(number))
        out(f"*{number}: " + (note.get("display_text", note.get("text", "")) if note else "（なし）"))


def comparable(lines, headings):
    """Lines as the cache can hold them, for update checks.

    The cache keeps each own-line heading only as its parsed text, so compare
    such lines as '#'*level + ' ' + that text on both sides. The rendered line
    also carries link numbers and spacing from the heading's markup, which
    would otherwise look like an edit. Every other line is compared verbatim.
    """
    result = list(lines)
    for heading in headings:
        number = heading.get("article_line")
        if not number or number > len(result):
            continue
        marks = re.match(r"^(#{1,6})\s", result[number - 1])
        if marks and len(marks.group(1)) == heading["level"]:
            parts = (heading.get("text") or "").splitlines()
            result[number - 1] = "#" * heading["level"] + " " + (parts[0] if parts else "")
    return result


# check-updates stops once the same failed name lookup repeats on this many pages in a row (each after the
# reader's own retries; --stop-after-dns-failures). Where names cannot be resolved at all, as in a sandbox
# without DNS, every further page would fail alike: --all would spend half an hour on it. Other network
# errors, such as timeouts, may pass and never stop the check.
DNS_FAILURE_LIMIT = 2


def _reader_failure(stderr):
    """The error object and a one-line detail of a failed reader run. The reader writes one JSON object
    to stderr; other text (another --reader, a traceback) gives {} and its last 300 characters."""
    text = stderr.decode("utf-8", "replace").strip()
    try:
        error = json.loads(text)
    except (ValueError, RecursionError):
        error = None
    if not isinstance(error, dict) or not isinstance(error.get("error_code"), str):
        return {}, text[-300:]
    detail = str(error.get("reason") or error.get("error") or "")
    if error.get("http_status"):
        detail = f"HTTP {error['http_status']} {detail}".strip()
    return error, f"{error['error_code']}: {detail}" if detail else error["error_code"]


def _name_resolution_failure(error):
    """The reason of a failed name lookup (the reader reports urllib's socket.gaierror), to compare with the
    next page's; None for any other outcome. A reader without reason_exception never stops the check."""
    if error.get("error_code") == "network_error" and error.get("reason_exception") == "gaierror":
        return str(error.get("reason") or "")
    return None


def _requests(result):
    """HTTP requests the reader reports for one page (0 from its cache); 1 when it does not say."""
    count = result.get("http_requests")
    return count if isinstance(count, int) and not isinstance(count, bool) and count >= 0 else 1


def cmd_check_updates(cache, args):
    import time
    reader = find_reader(args.reader)
    targets, found = [], set()
    people = [Person(cache, entry) for entry in (cache.people if args.all else [cache.resolve(args.person)])]
    for person in people:
        pages = person.pages()["pages"]
        # --pages takes page IDs or labels (quotes, 語録); one that names no page is an error, not "no updates".
        wanted = None
        if args.pages:
            wanted = set()
            for key in args.pages:
                entry = match_page(pages, key, prefix=person.name)
                if entry is not None:
                    wanted.add(entry["id"])
                    found.add(key)
        for page_entry in pages:
            if wanted is not None and page_entry["id"] not in wanted:
                continue
            if page_entry["text"] or args.include_url_only:
                targets.append((person, page_entry))
    unknown = [key for key in args.pages or [] if key not in found]
    if unknown:
        known = "" if args.all else "。候補: " + "、".join(f"{p['id']}（{p['label']}）" for p in people[0].pages()["pages"])
        raise CacheError("--pages のページがありません: " + "、".join(unknown) + known)
    if not targets:
        raise CacheError("確認するページがありません（本文のあるページがない。URLだけのページは --include-url-only で行数を照合できます）。")
    if args.limit is not None:
        targets = targets[:args.limit]
    results, requests, streak, last_failure, stopped = [], 0, 0, None, None
    for number, (person, entry) in enumerate(targets):
        if stopped:
            results.append({"person": person.name, "page": entry["id"], "title": entry["title"],
                            "status": "not_checked"})
            continue
        if number:
            time.sleep(args.delay)
        argv = [sys.executable, reader, "--url", entry["url"], "--all", "--surrogate-charrefs", "utf16",
                "--cache-policy", "diagnostic", "--format", "json"]
        if args.reader_cache_dir:
            argv += ["--cache-dir", args.reader_cache_dir]
        process = _reader_run(argv, capture_output=True)
        if process.returncode:
            error, detail = _reader_failure(process.stderr)
            result = {"person": person.name, "page": entry["id"], "status": "error",
                      "error_code": error.get("error_code"), "detail": detail}
            requests += _requests(error)
            failure = _name_resolution_failure(error)
            streak = streak + 1 if failure is not None and failure == last_failure else int(failure is not None)
            last_failure = failure
            if args.stop_after_dns_failures and streak >= args.stop_after_dns_failures and number + 1 < len(targets):
                stopped = (f"同じ名前解決の失敗が{streak}ページ続いたため、残り{len(targets) - number - 1}ページは確認していません。"
                           "この環境からwikiに接続できないとみられます。保存本文は通信なしで read で読めます。"
                           "止めるまでの回数は --stop-after-dns-failures で変えられます（0で止めない）。")
        else:
            streak, last_failure = 0, None
            try:
                live = json.loads(process.stdout)
                if not isinstance(live, dict) or not isinstance(live.get("lines"), list):
                    raise ValueError("no lines")
            except (ValueError, RecursionError):
                live = None
        if not process.returncode and live is None:
            # A reader named with --reader that printed something other than the reader's JSON.
            requests += 1
            result = {"person": person.name, "page": entry["id"], "status": "error", "error_code": "reader_output",
                      "detail": "reader_output: リーダーの出力がJSONではありません（--reader を確認）"}
        elif not process.returncode:
            requests += _requests(live)
            live_lines = [item["text"] for item in live["lines"]]
            live_updated = (live.get("page_metadata") or {}).get("last_updated")
            result = {"person": person.name, "page": entry["id"], "title": entry["title"],
                      "cached_last_updated": entry.get("last_updated"), "live_last_updated": live_updated,
                      "cached_lines": entry["line_count"], "live_lines": len(live_lines)}
            if entry["text"]:
                page = person.page(entry["id"])
                same = comparable(page.lines, page.headings()) == comparable(live_lines, live.get("headings", []))
                result["status"] = "same" if same else "changed"
                if same and live_updated != entry.get("last_updated"):
                    result["status"] = "same_text_new_timestamp"
            else:
                result["status"] = ("url_only_same_line_count" if entry["line_count"] == len(live_lines)
                                    else "url_only_line_count_changed")
        results.append(result)
        if args.format == "text":
            if result["status"] == "error":
                out(f"error\t{result['person']}\t{result['page']}\t{result['detail']}")
            else:
                out(f"{result['status']}\t{result['person']}\t{result['page']}\t"
                    f"{result['cached_lines']}→{result['live_lines']}行\t"
                    f"{result['cached_last_updated']} → {result['live_last_updated']}")
            if stopped:
                out("stopped\t" + stopped)
            sys.stdout.flush()
    summary = {}
    for result in results:
        summary[result["status"]] = summary.get(result["status"], 0) + 1
    if args.format == "json":
        report = {"http_requests": requests, "summary": summary, "pages": results}
        if stopped:
            report["stopped"] = stopped
        out(json.dumps(report, ensure_ascii=False, indent=1))
    else:
        out("summary: " + json.dumps(summary, ensure_ascii=False)
            + "  (same=本文一致 / changed=要再取得。見出し行は解析済み見出しテキストで比較)")
    return 1 if summary.get("error") else 0


def cmd_verify(cache, args):
    import hashlib
    from pathlib import PurePosixPath
    problems, checked, listed = [], 0, {"MANIFEST.sha256"}
    for number, raw in enumerate(_text(cache.path("MANIFEST.sha256")).splitlines(), 1):
        digest, separator, relative = raw.partition("  ")
        path = PurePosixPath(relative)
        # Only "<SHA-256>  <relative path inside the cache>": no absolute path, "..", drive or backslash.
        if (separator != "  " or not re.fullmatch(r"[0-9a-f]{64}", digest) or not relative or path.is_absolute()
                or ".." in path.parts or "\\" in relative or ":" in relative or str(path) != relative):
            problems.append(f"malformed MANIFEST.sha256 line {number}")
            continue
        listed.add(relative)
        path = cache.path(relative)
        if not os.path.isfile(path):
            problems.append("missing " + relative)
            continue
        checked += 1
        try:
            data = _read_bytes(path)
        except CacheIntegrityError:
            raise              # the skill's own copy: its wrapper unpacks it again and verifies the new one
        except CacheError:
            data = None        # --cache under the wrapper: reported like any other difference
        if data is None or hashlib.sha256(data).hexdigest() != digest:
            problems.append("changed " + relative)
    extra, bytecode = [], []
    for directory, folders, files in os.walk(cache.root):
        for name in files:
            relative = os.path.relpath(os.path.join(directory, name), cache.root).replace(os.sep, "/")
            if relative in listed:
                continue
            # Python's own bytecode caches: not part of the cache, reported apart (the skill's wrapper
            # never runs them).
            in_pycache = relative.rpartition("/")[0].rpartition("/")[2] == "__pycache__"
            (bytecode if in_pycache and re.search(r"\.pyc(\.\d+)?$", name) else extra).append(relative)
    ok = not problems and not extra
    report = {"checked": checked, "problems": problems, "unlisted_files": sorted(extra)[:50],
              "unlisted_count": len(extra), "bytecode_files": len(bytecode), "ok": ok}
    if bytecode:
        report["bytecode_note"] = ("__pycache__ のバイトコードは目録で照合できない。このフォルダーで直接実行するコマンドは"
                                   "これを使う（スキルのラッパーは使わない）。気になる場合は __pycache__ を消す。")
    out(json.dumps(report, ensure_ascii=False, indent=1))
    return 0 if ok else 1


# --- command line -------------------------------------------------------------------
# Only the requested command's parser is built: constructing all fourteen costs
# more than loading the cache itself. Without a recognizable command (or for
# --help) every parser is built.

def _page_arguments(p, selection=True):
    p.add_argument("person", nargs="?", help="人物名・別名・slug、または shared")
    p.add_argument("page", nargs="?", help="ページID・ラベル・タイトル（既定: main）")
    p.add_argument("--title", help="wiki記事タイトルで指定（リーダーの --title と同じ）")
    p.add_argument("--url", help="wiki記事URLで指定")
    if selection:
        p.add_argument("--find", help="文字列を含む行（正規表現ではない）")
        p.add_argument("--context", type=int, choices=range(0, 21), default=0)
        p.add_argument("--section", help="一意に一致する見出しの節")
        p.add_argument("--start", type=int, default=1)
        p.add_argument("--lines", type=int, default=80)
        p.add_argument("--all", action="store_true")
        p.add_argument("--format", choices=("text", "json", "md"), default="text")
        p.add_argument("--tables", action="store_true")
        p.add_argument("--footnotes", action="store_true", help="表示行の *n 脚注を添える")
        p.add_argument("--links", action="store_true", help="表示行の [n] リンクのURLを添える（オンライン取得のページ）")
        p.add_argument("--previous", action="store_true", help="オンライン取得で置き換えた旧版（元キャッシュ）を読む")
        p.add_argument("--online", action="store_true", help="本文未収録ならリーダーで取得（HTTP）")
        p.add_argument("--reader", help="hololive_wiki_reader_v31.py の場所")
        p.add_argument("--reader-cache-dir", help="リーダーの --cache-dir")


def _arguments_list(p):
    p.add_argument("--region", choices=["JP", "EN", "ID"])
    p.add_argument("--generation")


def _arguments_show(p):
    p.add_argument("person", nargs="+", help="1人以上")
    p.add_argument("--digest", action="store_true", help="JP45名の長い人物像ダイジェスト")
    p.add_argument("--section", action="append", default=[],
                   help="--digest の見出しの語。その節（小見出しを含む）だけを出す。繰り返し可（--section 性格 --section 立ち位置）")


def _arguments_scene(p):
    p.add_argument("person", nargs="+", help="2人以上")
    p.add_argument("--brief", action="store_true", help="カード本文を省き要点だけ")


def _arguments_status(p):
    p.add_argument("person", nargs="*", help="人物（省略で全員）")
    p.add_argument("--category", choices=STATUS_CHOICES,
                   help="掲載欄で絞る（not_active=卒業生・活動終了・スタッフ欄と【配信活動終了】注記）")
    p.add_argument("--format", choices=("text", "json"), default="text")


def _arguments_story(p):
    _module("hololive_story").add_arguments(p)


def _arguments_profile(p):
    p.add_argument("person")
    p.add_argument("--field")


def _arguments_pages(p):
    p.add_argument("person", help="人物名、または shared")
    p.add_argument("--related", action="store_true", help="関連する共有記事も表示")


def _arguments_find(p):
    p.add_argument("person")
    p.add_argument("term")
    p.add_argument("--limit", type=int, default=25)


def _arguments_search(p):
    p.add_argument("term")
    p.add_argument("--region", choices=["JP", "EN", "ID"])
    p.add_argument("--limit", type=int, default=40)
    p.add_argument("--no-shared", action="store_true", help="共有ページを除く")


def _arguments_nicknames(p):
    p.add_argument("person")
    p.add_argument("--query")
    p.add_argument("--all", action="store_true", help="空欄の呼称行も表示")
    p.add_argument("--reverse", action="store_true", help="他の人物の呼称表での記載を表示")


def _arguments_sources(p):
    p.add_argument("person")


def _arguments_tables(p):
    _page_arguments(p, selection=False)
    p.add_argument("--section")
    p.add_argument("--compact", action="store_true")


def _arguments_footnotes(p):
    _page_arguments(p, selection=False)
    p.add_argument("--numbers", nargs="*")


def _arguments_check_updates(p):
    p.add_argument("person", nargs="?")
    p.add_argument("--all", action="store_true", help="全人物")
    p.add_argument("--pages", nargs="*", help="ページIDかラベル（quotes、語録など。既定: 本文のある全ページ）")
    p.add_argument("--include-url-only", action="store_true", help="本文未収録ページも行数で照合")
    p.add_argument("--limit", type=int, help="確認するページ数の上限（1以上。省略すると対象の全ページ）")
    p.add_argument("--delay", type=float, default=1.0, help="要求の間隔秒（既定1.0、0.5〜60）")
    p.add_argument("--stop-after-dns-failures", type=int, default=DNS_FAILURE_LIMIT, metavar="N",
                   help="同じ名前解決の失敗がNページ続いたら残りを確認せず止める（既定2、0で止めない）。タイムアウトなどでは止めない")
    p.add_argument("--reader")
    p.add_argument("--reader-cache-dir")
    p.add_argument("--format", choices=("text", "json"), default="text")


COMMANDS = {
    "list": (cmd_list, _arguments_list, "人物一覧"),
    "show": (cmd_show, _arguments_show, "要約カード（複数人可）"),
    "scene": (cmd_scene, _arguments_scene, "複数人の相互の呼び方とカード"),
    "story": (cmd_story, _arguments_story, "物語用の資料パック（話し方・口癖・性格・反応候補・相互の呼び方・人物間の言及行）"),
    "status": (cmd_status, _arguments_status, "wikiトップの掲載欄（在籍・卒業生・活動終了）。公式未照合"),
    "profile": (cmd_profile, _arguments_profile, "person.json"),
    "pages": (cmd_pages, _arguments_pages, "ページ一覧"),
    "read": (cmd_read, _page_arguments, "ページ本文（リーダーと同じ選択規則）"),
    "find": (cmd_find, _arguments_find, "人物の資料を検索"),
    "search": (cmd_search, _arguments_search, "全人物の本文を検索"),
    "nicknames": (cmd_nicknames, _arguments_nicknames, "呼称"),
    "sources": (cmd_sources, _arguments_sources, "出典"),
    "tables": (cmd_tables, _arguments_tables, "ページの表"),
    "footnotes": (cmd_footnotes, _arguments_footnotes, "ページの脚注"),
    "check-updates": (cmd_check_updates, _arguments_check_updates, "リーダーで現在のwikiと照合（HTTP）"),
    "verify": (cmd_verify, lambda p: None, "MANIFEST.sha256 で全ファイルを検査"),
}


def build_cli(only=None):
    import argparse
    cli = argparse.ArgumentParser(prog="hololive_cache.py", description=__doc__,
                                  formatter_class=argparse.RawDescriptionHelpFormatter)
    cli.add_argument("--cache", help="v3 キャッシュのディレクトリ（既定: このファイルの場所）")
    sub = cli.add_subparsers(dest="command", required=True, metavar="COMMAND")
    for name, (_, arguments, summary) in COMMANDS.items():
        if only is None or name == only:
            arguments(sub.add_parser(name, help=summary, description=summary))
    return cli


def command_of(argv):
    """The subcommand, found without building every parser: the first word that is neither an option nor the
    value of --cache (so --cache read list runs list on the folder "read"). None lets argparse report it."""
    words = iter(argv)
    for item in words:
        if item == "--cache":
            next(words, None)
        elif not item.startswith("-"):
            return item if item in COMMANDS else None
    return None


def main(argv=None):
    for stream in (sys.stdout, sys.stderr):
        try:
            stream.reconfigure(encoding="utf-8")
        except (AttributeError, OSError, ValueError):
            pass
    argv = sys.argv[1:] if argv is None else list(argv)
    cli = build_cli(command_of(argv))
    args, extra = cli.parse_known_args(argv)
    if extra:
        if args.command == "story" and args.topic:
            cli.error("unrecognized arguments: " + " ".join(extra)
                      + "（話題を複数指定するときは --topic を繰り返してください。例: --topic 料理 --topic ホラー）")
        cli.error("unrecognized arguments: " + " ".join(extra))
    if args.command in ("find", "search") and args.limit < 1:
        cli.error("--limit は1以上にしてください")
    if args.command in ("find", "search") and not args.term.strip():
        cli.error("検索語を指定してください（空や空白だけの語では、すべての行に一致します）")
    if args.command == "check-updates":
        import math
        if not (args.all or args.person):
            cli.error("check-updates には人物名か --all が必要です")
        if args.limit is not None and args.limit < 1:
            cli.error("--limit は1以上にしてください（省略すると対象の全ページ）")
        if not (math.isfinite(args.delay) and 0.5 <= args.delay <= 60):
            cli.error("--delay は0.5〜60秒の数値にしてください")
        if args.stop_after_dns_failures < 0:
            cli.error("--stop-after-dns-failures は0以上にしてください（0で止めない）")
    if args.command == "scene" and len(args.person) < 2:
        cli.error("scene には2人以上を指定してください")
    _LAST_JSON[0] = None
    try:
        cache = Cache(args.cache)
        if _VERIFIED is not None and args.cache:
            _verify_other_cache(cache.root)
        return COMMANDS[args.command][0](cache, args) or 0
    except CacheIntegrityError:
        raise                      # only after verify_reads(): the wrapper unpacks the cache again
    except CacheError as exc:
        sys.stdout.flush()
        sys.stderr.write(json.dumps({"error": str(exc)}, ensure_ascii=False) + "\n")
        return 1
    except (TypeError, AttributeError, KeyError, IndexError, ValueError, RecursionError) as exc:
        # A cache named with --cache is checked only against its own manifest: data of another shape (a list
        # where an object belongs) is an error of that cache, not a traceback. The skill's own cache is
        # checked against the manifest it ships, so there such an exception is a fault of this code.
        if not args.cache:
            raise
        sys.stdout.flush()
        last = f"。最後に読んだファイル: {_LAST_JSON[0]}" if _LAST_JSON[0] else ""
        sys.stderr.write(json.dumps({"error": f"--cache のキャッシュを読めません（このスキルのキャッシュと形式の違うデータがあります{last}）: "
                                              f"{type(exc).__name__}: {exc}"}, ensure_ascii=False) + "\n")
        return 1


def run_cli():
    try:
        try:
            code = main()
        except CacheIntegrityError:
            raise                  # nothing is flushed: the skill's wrapper runs the command again
        except BaseException:
            sys.stdout.flush()
            raise
        sys.stdout.flush()
        return code
    except BrokenPipeError:
        with open(os.devnull, "w") as sink:
            os.dup2(sink.fileno(), sys.stdout.fileno())
        return 0


if __name__ == "__main__":
    raise SystemExit(run_cli())
