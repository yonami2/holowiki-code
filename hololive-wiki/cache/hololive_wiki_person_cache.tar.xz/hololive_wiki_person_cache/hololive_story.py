#!/usr/bin/env python3
"""Story material pack: what a writer needs about a cast, from the cached wiki, in one bounded read.

Run through the cache CLI (the archive's hololive_cache.py or the skill's wrapper):

    hololive_cache.py story 宝鐘マリン 兎田ぺこら --topic 料理
    hololive_cache.py story ラプラス・ダークネス 鷹嶺ルイ 博衣こより --detail brief --format json

For each person (JP talents with a digest use it; everyone else uses the main
page's sections and the shared EN/ID quote pages):
  identity     region, generation, listing on the wiki's top page (a wiki
               record, not checked against the official site), fan name,
               oshi mark, birthday, the person's own row of the nickname table
  speech       greetings, catchphrases from the person's 口癖 section;
               shared EN/ID glossary entries are association candidates,
               since a mark can identify a speaker, addressee or viewer
  personality  性格・癖, likes, dislikes, place within hololive, stream style;
               the first heading with readable lines, by word priority
               (an empty ##### 配信の特徴 passes to 配信内容, whose lead and
               subsections are read apart, without ##### 3Dモデルでの配信);
               without a personality heading, the lead of the detailed
               profile, named in the pack; likes and dislikes come from the
               main page, each term joined with its own definitions as the
               wiki's definition lists mark them (definition_lists.json),
               else as guessed from the lines (guessed_groups); a line outside
               the list is a note on the item before it (notes), or on the
               whole section before any item (section_notes); referenced footer
               footnotes accompany the visible item, with their original context
  reactions    keyword search candidates from catchphrases/personality,
               explicitly unverified as that person's reaction
For each pair: how each calls the other in both people's tables (struck-through
names retained separately), the combination and unit names they share,
and lines where one person's pages mention the other.
--topic adds each person's lines about the scene's subject (repeat it for several).

Extracted prose carries its source as file:line, so a statement about real events
can be checked. The pack's saved dates are those of the text it cites (each page's
own fetch time; the original cache's days for the JP45 digests and profile tables). The pack is material, not canon: a story keeps the
conversation's premise, does not present invented lines as real quotes, and
does not append source lists unless asked (the skill's rules).

Python 3.9+, standard library only. It reads only the cast's files, the
shared page list, three shared pages and definition_lists.json; nothing is fetched.
"""

from __future__ import annotations

import json
import os
import re
import sys

VERSION = "1.4.2"
SCHEMA = "hololive-story-pack/3"
HEADING = re.compile(r"^(#{1,6})\s+(.*?)\s*$")
LINK_MARK = re.compile(r"\s?\[\d+\]")
NOTE_MARK = re.compile(r"\s?[*＊]\d+")
FOOTNOTE_MARK = re.compile(r"[*＊](\d+)")
FOOTNOTE_DEFINITION = re.compile(r"^\s*[*＊](\d+)\s*[:：]\s*(.*)$")
STRUCK_WITH_NOTES = re.compile(r"~~.*?~~(?:\s*[*＊]\d+)*(?:\s*[（(][^（）()]*[）)])?(?:\s*[*＊]\d+)*")
# A struck-through item goes with the note right after it (~~炭酸飲料~~（克服済み）), and with the comma
# before it when it ends the line.
STRUCK = re.compile(r"~~.*?~~(?:\s*[（(][^（）()]*[）)])?")
STRUCK_LAST = re.compile(r"[、，,]\s*~~[^~]*~~(?:\s*[（(][^（）()]*[）)])?\s*$")
SENTENCE_END = "。！？!?"
# Likes and dislikes are definition lists on the wiki; the reader flattens each term and each value to a
# line of its own. A term either names a category (好きな食べ物, 食べ物（素材）, 苦手な物) or is a short
# noun phrase followed by a list or a sentence (人食い → 食において人間は好みではない。).
TERM_START = re.compile(r"^(?:大?好きな|嫌いな|苦手な|得意な|NG)")
# A line outside the list that comments on it: ※過去に好きだったものも含まれます。 / 注釈:… The marker is
# dropped when the note is shown (the pack labels it 注記).
NOTE_START = re.compile(r"^(?:※|注釈\s*[:：]|注\s*[:：]|[（(]注[）)])\s*")
TERM_NOUNS = frozenset("食べ物 飲み物 飲食物 お酒 酒 趣味 特技 アレルギー その他 全般 ゲーム アニメ 漫画 マンガ 音楽 色 "
                       "動物 生き物 場所 家事 科目 スポーツ 運動".split())
# A particle inside a phrase makes it a clause (教育を受けている, キーが高い, 朝に食べると), not a term.
CLAUSE = re.compile(r"を|(?<=[一-龯ァ-ヺー）)])[がにでは](?=[ぁ-ゖ一-龯])")
# A short hiragana name inside running hiragana is usually an ordinary word (甘えはじめて, おそらく):
# it counts when a particle or an honorific follows it, or no hiragana at all.
HIRAGANA_WORD = re.compile(r"^[ぁ-ゖー]{1,4}$")
NAME_FOLLOWERS = ("の", "が", "は", "を", "に", "と", "も", "へ", "や", "ね", "よ", "ら", "ー",
                  "さん", "さま", "ちゃん", "くん", "たん", "っち")
# A line that only names a collection behind a link (他メンバーによる物真似集 [584]) is not a greeting.
COLLECTION = re.compile(r"(?:集|一覧|まとめ|リスト)$")
# (label, words that name the situation in a catchphrase note or a personality line)
REACTIONS = (
    ("驚き", ("驚", "びっくり", "予想外", "意外", "仰天", "ビックリ")),
    ("喜び・興奮", ("嬉し", "喜", "テンション", "興奮", "はしゃ", "感動", "大喜び")),
    ("照れ", ("照れ", "恥ずかし", "褒められ", "赤面", "てれ")),
    ("困惑・焦り", ("焦", "困", "混乱", "戸惑", "パニック", "慌て", "動揺", "テンパ")),
    ("心配・気遣い", ("心配", "気遣", "励ま", "慰め", "労い", "気にかけ")),
    ("失敗・悔しさ", ("失敗", "ミス", "負け", "悔し", "ゲームオーバー", "非業", "やらかし", "死亡")),
    ("からかい・ツッコミ", ("からか", "いじ", "ツッコ", "煽", "罵倒", "キレ", "怒", "文句", "毒")),
    ("怖さ・緊張", ("緊張", "怖", "ホラー", "ビビ", "悲鳴", "絶叫", "叫")),
)
# (key, label, heading words in digest.md, heading words in a main page), most specific word first.
# A heading without readable lines (an empty ##### 配信の特徴) passes to the next word (#### 配信内容など).
# The digest flattens 配信内容 with its subsections, so only the main page's 配信内容 is read.
SECTIONS = (
    ("personality", "性格・癖", ("性格・癖",), ("性格や癖", "性格・癖", "性格")),
    ("likes", "好きなもの・得意なもの", ("好きなもの",), ("好きなもの",)),
    ("dislikes", "嫌いなもの・苦手なもの", ("嫌いなもの",), ("嫌いなもの",)),
    ("position", "ホロライブ内での立ち位置", ("ホロライブ内での立ち位置",), ("ホロライブ内での立ち位置",)),
    ("stream", "配信の特徴", ("配信の特徴",), ("配信の特徴", "配信内容", "配信傾向")),
)
# Pages without a personality heading (ロボ子さん, 星街すいせい, 湊あくあ) describe the character in the
# lead of the detailed profile; the pack names that heading.
FALLBACK = {"personality": (("プロフィール・特徴",), ("プロフィール、特徴", "プロフィール・特徴"))}
# A parent heading read for a section (#### 配信内容など for 配信の特徴): its lead, then each subsection
# named 【like this】, leaving out the ones about something else (##### 3Dモデルでの配信, lists).
PARENT_WORDS = frozenset({"配信内容"})
ELSEWHERE = re.compile(r"3D|一覧|お披露目")
IDENTITY_FIELDS = ("ファンの愛称", "推しマーク", "誕生日", "身長", "初配信日")
# Pages that list titles (songs, videos...): a mention there shows a collaboration, not a scene.
LIST_PAGES = re.compile(r"^(songs|videos|twitter_videos|bgm|costumes|designer_art|references|games|stream_songs|"
                        r"song_streams|member_streams|membership|own_works|drinks)")
DETAIL = {
    "brief": {"greetings": 3, "catchphrases": 8, "personality": 3, "likes": 2, "dislikes": 2, "position": 2,
              "stream": 1, "reactions": 6, "per_reaction": 1, "topic": 3, "combos": 3, "mentions": 3, "item": 110},
    "normal": {"greetings": 6, "catchphrases": 15, "personality": 6, "likes": 4, "dislikes": 4, "position": 4,
               "stream": 3, "reactions": 12, "per_reaction": 2, "topic": 6, "combos": 5, "mentions": 6, "item": 160},
    "full": {"greetings": 12, "catchphrases": 40, "personality": 12, "likes": 8, "dislikes": 8, "position": 8,
             "stream": 6, "reactions": 24, "per_reaction": 4, "topic": 12, "combos": 10, "mentions": 12, "item": 320},
}
OMITTED_LABELS = {"greetings": "あいさつ", "catchphrases": "口癖", "related_quotes": "関連語録の候補",
                  **{key: label for key, label, _, _ in SECTIONS},
                  "reactions": "反応場面の検索候補", "topic": "話題の行", "combos": "コンビ・ユニット名",
                  "mentions": "言及候補"}
RULES = ("wiki（非公式・二次資料）の抜粋。各行末の（ファイル:行）が根拠で、現実の出来事として述べる内容はそこで確かめる。"
         "物語では会話で指定された前提（例: 卒業生なしの世界）を優先し、ここにある台詞を実際の発言として引用しない。"
         "出典一覧や定型の注記は、求められない限り物語に付けない。")


# --- text helpers -----------------------------------------------------------------

SPAN_MARK = re.compile(r"\[(?:row|col)span=\d+\]\s*")
SPACES = re.compile(r"\s+")
LINK_WITH_SPACES = re.compile(r"\s*\[\d+\]\s*")
# What removing a struck-through item leaves behind: 、、 / "/ /" / "— /" / a trailing "/".
LEFTOVERS = ((re.compile(r"、(?:\s*、)+"), "、"), (re.compile(r"\s*/(?:\s*/)+"), " /"), (re.compile(r"—\s*/\s*"), "— "),
             (re.compile(r"\s*/\s*(?=—|$)"), " "))


def without_link_marks(text):
    """Drop [n] link numbers with the spaces around them (肉の脂身 [487] 、 → 肉の脂身、), keeping one
    space between two Latin words."""
    def replace(match):
        before, after = text[match.start() - 1:match.start()], text[match.end():match.end() + 1]
        latin = before.isascii() and before.isalnum() and after.isascii() and after.isalnum()
        return " " if latin else ""
    return LINK_WITH_SPACES.sub(replace, text) if "[" in text else text


def tidy(text):
    """One readable line: no link numbers, footnote marks or struck-through words; table cells joined."""
    text = without_link_marks(NOTE_MARK.sub("", str(text)))
    text = STRUCK.sub("", STRUCK_LAST.sub("", text))
    text = SPAN_MARK.sub("", text)
    if text.strip().startswith("|"):
        cells = [cell.strip() for cell in text.strip().strip("|").split("|")]
        text = " — ".join(cell for cell in cells if cell)
    text = SPACES.sub(" ", text)
    for pattern, replacement in LEFTOVERS:
        text = pattern.sub(replacement, text)
    text = text.strip(" /")
    if re.fullmatch(r"-+", text):
        return ""
    text = re.sub(r"^(?:-\s+)+", "", text)
    return text.lstrip("、，,・/／:：；; ")


def clip(text, limit):
    """Whole sentences (else whole list items) up to about limit characters; '…' marks a cut."""
    if len(text) <= limit:
        return text
    cut = text[:limit]
    end = max(cut.rfind(mark) for mark in SENTENCE_END)
    if end >= limit // 3:
        return cut[:end + 1] + "…"
    comma = cut.rfind("、")
    return (cut[:comma] if comma >= limit // 2 else cut.rstrip()) + "…"


_HEADINGS = {}          # id(lines) -> (lines, headings) of the pages read last


def headings(lines):
    """[(index, level, text)] of the markdown-style heading lines (kept for the last pages asked)."""
    cached = _HEADINGS.get(id(lines))
    if cached is not None and cached[0] is lines:
        return cached[1]
    found = []
    for index, line in enumerate(lines):
        if line.startswith("#"):
            match = HEADING.match(line)
            if match:
                found.append((index, len(match.group(1)), LINK_MARK.sub("", match.group(2)).strip()))
    if len(_HEADINGS) >= 64:
        del _HEADINGS[next(iter(_HEADINGS))]
    _HEADINGS[id(lines)] = (lines, found)
    return found


def section(lines, words, *, skip_subheadings=True):
    """[(line number, text)] under the first heading that contains one of the words."""
    marks = headings(lines)
    for position, (index, level, text) in enumerate(marks):
        if any(word in text for word in words):
            end = next((other for other, other_level, _ in marks[position + 1:] if other_level <= level), len(lines))
            body = []
            for number in range(index + 1, end):
                line = lines[number]
                if HEADING.match(line):
                    if skip_subheadings:
                        continue
                    line = "【" + HEADING.match(line).group(2) + "】"
                if line.strip():
                    body.append((number + 1, line))
            return body
    return []


def readable_section(sources, item, *, lead_only=False):
    """(heading, rows) under the first heading with readable lines. sources are (Source, words) pairs;
    each word rank is tried in the digest before the main page, every heading with the word in page order.
    lead_only stops at the first subheading; under a parent heading (PARENT_WORDS) each row names its
    subsection and subsections about something else are left out."""
    ranked = [(source, words[rank]) for rank in range(max(len(words) for _, words in sources))
              for source, words in sources if source is not None and rank < len(words)]
    marks_of = {}
    for source, word in ranked:
        marks = marks_of.setdefault(id(source), headings(source.lines))
        for position, (index, level, title) in enumerate(marks):
            if word not in title:
                continue
            end = next((other for other, other_level, _ in marks[position + 1:]
                        if other_level <= level or lead_only), len(source.lines))
            rows, subsection, elsewhere = [], None, False
            for number in range(index + 1, end):
                line = source.lines[number]
                match = HEADING.match(line)
                if match:
                    subsection = LINK_MARK.sub("", match.group(2)).strip()
                    elsewhere = word in PARENT_WORDS and bool(ELSEWHERE.search(subsection))
                    continue
                text = tidy(line)
                if elsewhere or not text or is_navigation(text) or len(text) < 4:
                    continue
                row = {"text": clip(text, item), "source": source.ref(number + 1)}
                if word in PARENT_WORDS and subsection:
                    row = {"text": clip(f"【{subsection}】{text}", item), "source": row["source"],
                           "heading": subsection}
                rows.append(row)
            if rows:
                return title, rows
    return None, []


def first_heading(lines, words):
    """(index, level, text) of the first heading that contains one of the words, or None."""
    return next((mark for mark in headings(lines) if any(word in mark[2] for word in words)), None)


def section_rows(lines, words):
    """[(line number, text, heading level or 0)] under the first heading that contains one of the words."""
    marks = headings(lines)
    for position, (index, level, text) in enumerate(marks):
        if any(word in text for word in words):
            end = next((other for other, other_level, _ in marks[position + 1:] if other_level <= level), len(lines))
            rows = []
            for number in range(index + 1, end):
                match = HEADING.match(lines[number])
                if match:
                    rows.append((number + 1, LINK_MARK.sub("", match.group(2)).strip(), len(match.group(1))))
                elif lines[number].strip():
                    rows.append((number + 1, lines[number], 0))
            return rows
    return []


def entries(lines, *, under=None):
    """[(line number, phrase, note)] for '##### phrase' headings (optionally below a heading with under)."""
    marks = headings(lines)
    start, stop = 0, len(lines)
    if under:
        chosen = next(((i, level) for i, level, text in marks if level < 5 and any(w in text for w in under)), None)
        if chosen is None:
            return []
        start = chosen[0]
        stop = next((i for i, level, _ in marks if i > start and level <= chosen[1]), len(lines))
    found = []
    for position, (index, level, text) in enumerate(marks):
        if level != 5 or not start <= index < stop:
            continue
        end = next((other for other, _, _ in marks[position + 1:]), len(lines))
        note = " ".join(tidy(line) for line in lines[index + 1:min(end, stop)] if line.strip())
        found.append((index + 1, text, note))
    return found


def profile_table(lines):
    """{item: value} from the '| item | value |' rows of a page's 公式情報 table."""
    rows = section(lines, ("公式情報",))
    found = {}
    for _, line in rows:
        cells = [tidy(cell) for cell in line.strip().strip("|").split("|")]
        if len(cells) == 2 and cells[0] and cells[1] and cells[0] != cells[1]:
            found.setdefault(re.sub(r"\[(?:row|col)span=\d+\]\s*", "", cells[0]), cells[1])
    return found


def classify(text):
    """Reaction labels named in a note, ignoring its examples (例：…), which quote other words."""
    meaning = re.split(r"\s?例[：:「『]|\s例\s", text)[0]
    return [label for label, words in REACTIONS if any(word in meaning for word in words)]


def join_values(values):
    joined = ""
    for value in values:
        joined = value if not joined else joined + (" " if joined[-1] in SENTENCE_END else "、") + value
    return joined


def footnote_context(text):
    """Keep the phrase before a marker without splitting a parenthesized list."""
    closing = {"(": ")", "（": "）", "「": "」", "『": "』", "[": "]"}
    stack, start = [], 0
    for index, char in enumerate(text):
        if char in closing:
            stack.append(closing[char])
        elif stack and char == stack[-1]:
            stack.pop()
        elif not stack and char in "、，,。；;：:":
            start = index + 1
    return text[start:].strip()


def footnote_notes(source, references, display, limit):
    """Footnotes of the visible excerpt, from the same page; removed text cannot add notes.

    Keep the original wording (apart from link marks, whitespace and an explicit excerpt cut),
    the definition's line range, and the original phrase carrying the marker. Footnotes are metadata
    on the item or section note, never new preference items.
    """
    result, seen, cursor = [], set(), 0
    shown = clip(display, limit)
    kept = len(shown) - (1 if len(display) > limit else 0)
    for number, raw in references:
        clean = tidy(raw)
        offset = display.find(clean, cursor)
        if not clean or offset < 0:
            continue
        cursor = offset + len(clean)
        removed = [match.span() for match in STRUCK_WITH_NOTES.finditer(raw)]
        for marker in FOOTNOTE_MARK.finditer(raw):
            key = marker.group(1)
            if key in seen or any(first <= marker.start() < last for first, last in removed):
                continue
            if offset + len(tidy(raw[:marker.start()])) > kept:
                continue
            note = source.footnotes().get(key)
            if note is None:
                continue
            seen.add(key)
            context = footnote_context(raw[:marker.end()])
            result.append({"text": clip(without_link_marks(SPACES.sub(" ", note["text"]).strip()), limit),
                           "source": note["source"], "footnote": "*" + key,
                           "reference": source.ref(number), "reference_text": clip(context, limit)})
    return result


def preference_items(source, words, limit, lists=None):
    """Likes or dislikes as items "term: value、value" with the lines they span (file:first-last).

    lists: {heading line: (term lines, definition lines)} of this page from definition_lists.json,
    the wiki's own definition lists aligned with the cached lines. A recorded section is grouped
    exactly as the wiki marks it: each term with its definitions, a term without definitions as an
    item of its own, other lines as items without a term. Other sections are grouped by guessed_groups.
    A note (a line after a term's definitions but outside them, or one marked ※/注釈:) goes with the
    item before it as "notes": [{"text", "source"}]; one before every item is returned first as
    {"kind": "note"}, a note on the whole section.
    """
    rows, written = [], {}
    for number, line, level in section_rows(source.lines, words):
        text = tidy(line)
        if text and not is_navigation(text):
            rows.append((number, text, level))
            written[number] = line
    heading = first_heading(source.lines, words)
    recorded = (lists or {}).get(heading[0] + 1) if heading else None
    exact = recorded is not None and recorded[0] == heading[2]
    groups = defined_groups(rows, *recorded[1:]) if exact else guessed_groups(rows)
    items = ([dict(note, label=None, kind="note") for note in
              footnote_notes(source, [(heading[0] + 1, heading[2])], tidy(heading[2]), limit)]
             if heading else [])
    for group in groups:
        first, last = group["first"], group["last"]
        notes = [{"text": clip(NOTE_START.sub("", text) or text, limit), "source": source.ref(number)}
                 for number, text in group["notes"]]
        for number, text in group["notes"]:
            raw_note = NOTE_START.sub("", written[number]) or written[number]
            notes.extend(footnote_notes(source, [(number, raw_note)], tidy(raw_note), limit))
        if group["values"]:
            value = join_values(group["values"])
            text, label = (f"{group['label']}: {value}", group["label"]) if group["label"] else (value, None)
        elif group["label"] and not group["heading"] and (exact or notes):
            text, label = group["label"], None          # a term listed without a definition (岩盤浴)
        else:
            items += [dict(note, label=None, kind="note") for note in notes]    # before every item
            continue
        item = {"text": clip(text, limit),
                "source": source.ref(first) if first == last else f"{source.relative}:{first}-{last}",
                "label": label}
        note_lines = {number for number, _ in group["notes"]}
        references = [(number, written[number]) for number, _, _ in rows
                      if first <= number <= last and number not in note_lines]
        notes.extend(footnote_notes(source, references, text, limit))
        if notes:
            item["notes"] = notes
        items.append(item)
    return items


def _group(number, label=None, heading=False):
    return {"label": label, "values": [], "notes": [], "first": number, "last": number, "heading": heading}


def _is_note(current, text):
    """Whether a line outside the list comments on the group before it: every such line after a term,
    and a marked one (※…, 注釈:…) after anything but a bare subheading, whose content it would be."""
    if current is None or current["heading"]:
        return bool(NOTE_START.match(text)) and (current is None or bool(current["values"]))
    return current["label"] is not None or bool(NOTE_START.match(text))


def _add_note(groups, number, text):
    """A note on the last group, or (before any group) on the whole section: a group of notes only."""
    if not groups:
        groups.append(_group(number))
    groups[-1]["notes"].append((number, text))


def _takes_loose_lines(group):
    """Loose lines join a subheading's group or a run of loose lines, not a group of notes only."""
    return (group["heading"] or group["label"] is None) and not (group["notes"] and not group["values"]
                                                                 and not group["heading"])


def defined_groups(rows, terms, definitions):
    """Groups as the wiki's definition list marks them. A subheading labels the loose lines under it. A
    loose line after a term (the wiki's paragraph after a definition) or one marked as a note is a note."""
    groups = []
    for number, text, level in rows:
        current = groups[-1] if groups else None
        if level or number in terms:
            groups.append(_group(number, text, bool(level)))
            continue
        loose = number not in definitions
        if loose and _is_note(current, text):
            _add_note(groups, number, text)
            continue
        attach = current is not None and (
            (not loose and current["label"] is not None and not current["heading"])
            or (loose and _takes_loose_lines(current)))
        if not attach:
            groups.append(_group(number))
        groups[-1]["values"].append(text)
        groups[-1]["last"] = number
    return groups


# Guessing a definition list (a section that definition_lists.json does not cover). Each line is a term
# (T), the first line of a definition (V), a later line of it (C) or a line outside any list (L);
# subheadings (H) are given. Line features score each role, the order of roles is constrained (a
# definition follows its term), and the best-scoring labelling wins (Viterbi). The weights were fitted
# to the recorded lists of 77 main pages: with weights fitted to one half of the people, 4.6 % and
# 5.8 % of the other half's items were grouped wrong (the rules of 1.2.1: 18 %). A line outside the
# list (L) after a term is a note on it. tools/evaluate_preferences.py --cross-validate recomputes all this.
GUESS_WEIGHTS = {
    "T": {"named": 4.0, "noun": 1.5, "list": -3.0, "sentence": -3.0, "colon": -2.5, "long": -2.5, "note": -3.0,
          "conj": -2.5, "predicate": -0.5, "clause": -0.2},
    "V": {"named": -1.0},
    # A later line of a definition is prose or a list (また…, ※…), rarely a bare short phrase.
    "C": {"bare": -2.5, "prose": -0.2, "note": 1.0},
    "L": {"base": -1.0},
}
GUESS_TRANSITIONS = {           # (previous role, role): score; missing pairs are not allowed
    (None, "T"): 0.0, (None, "L"): -0.3, (None, "H"): 0.0,
    ("H", "T"): 0.0, ("H", "L"): 0.0, ("H", "H"): 0.0,
    ("T", "V"): 0.0, ("T", "T"): -2.5, ("T", "H"): -2.0,
    ("V", "C"): -0.3, ("V", "T"): 0.0, ("V", "H"): 0.0, ("V", "L"): 0.0,
    ("C", "C"): 0.0, ("C", "T"): 0.0, ("C", "H"): 0.0, ("C", "L"): 0.0,
    ("L", "L"): -1.0, ("L", "T"): 0.0, ("L", "H"): 0.0,
}
CONTINUATION_START = ("また", "しかし", "特に", "ただし", "なお", "ちなみに", "さらに", "他にも", "但し", "曰く",
                      "本人曰く", "どちらも")
PREDICATE_END = re.compile(r"(ない|ている|てる|できる|られる|れる|する|した|だった|です|ます|だ|る|た|い|う|く|ず|ぬ)$")
PARENTHESES = re.compile(r"[（(][^（）()]*[）)]")


def line_features(text):
    """What a line looks like, read outside parentheses (好きな食べ物（調理、味付け） is a term)."""
    plain = PARENTHESES.sub("", text).strip() or text
    base = re.sub(r"\s*[（(].*$", "", text) or plain
    punctuated = bool(re.search(r"[。、，,：:！？!?]", plain))
    listed, sentence, colon = (bool(re.search(pattern, plain)) for pattern in (r"[、，,]", r"[。！？!?]", r"[：:]"))
    return {
        "named": (bool(TERM_START.match(plain)) or base.endswith(("なもの", "な物", "なこと", "なモノ")))
                 and not punctuated,
        "noun": base in TERM_NOUNS or plain in TERM_NOUNS,
        "list": listed,
        "sentence": sentence,
        "colon": colon,
        "long": len(text) > 30,
        "bare": len(text) <= 12 and not (listed or sentence or colon),
        "prose": listed or sentence or colon or len(text) > 30 or plain.startswith(CONTINUATION_START),
        "note": text.startswith(("※", "例", "注釈")),
        "conj": plain.startswith(CONTINUATION_START),
        "predicate": bool(PREDICATE_END.search(plain)) and not plain.endswith(("もの", "こと", "物")),
        "clause": bool(CLAUSE.search(plain)),
    }


def role_score(features, role):
    weights = GUESS_WEIGHTS[role]
    return weights.get("base", 0.0) + sum(weight for name, weight in weights.items() if features.get(name))


def guessed_groups(rows):
    """Groups for a section without a recorded definition list (see GUESS_WEIGHTS)."""
    if not rows:
        return []
    table = []                                   # per row: {role: (score, previous role)}
    for index, (_, text, level) in enumerate(rows):
        features = None if level else line_features(text)
        scores = {}
        for role in (("H",) if level else ("T", "V", "C", "L")):
            own = 0.0 if level else role_score(features, role)
            previous = table[index - 1] if index else {None: (0.0, None)}
            options = [(score + GUESS_TRANSITIONS[(before, role)] + own, before)
                       for before, (score, _) in previous.items() if (before, role) in GUESS_TRANSITIONS]
            if options:
                scores[role] = max(options, key=lambda option: option[0])
        table.append(scores)
    ending = {role: score - (1.5 if role == "T" else 0.0) for role, (score, _) in table[-1].items()}
    role = max(ending, key=ending.get)
    roles = [role]
    for index in range(len(rows) - 1, 0, -1):
        role = table[index][role][1]
        roles.append(role)
    groups = []
    for (number, text, _), role in zip(rows, reversed(roles)):
        current = groups[-1] if groups else None
        if role in ("H", "T"):
            groups.append(_group(number, text, role == "H"))
            continue
        if role == "L" and _is_note(current, text):
            _add_note(groups, number, text)
            continue
        if role == "L" and not (current is not None and _takes_loose_lines(current)):
            groups.append(_group(number))
        groups[-1]["values"].append(text)
        groups[-1]["last"] = number
    return groups


def definition_lists(cache, core, source):
    """{heading line: (heading, term lines, definition lines)} recorded for this main page, or {}."""
    match = re.match(r"^people/([^/]+)/pages/main\.txt$", source.relative)
    if not match:
        return {}
    pages = getattr(cache, "_story_definition_lists", None)
    if pages is None:
        path = cache.path("definition_lists.json")
        pages = {}
        if os.path.isfile(path):
            try:
                pages = core._json(path)["pages"]
            except (ValueError, KeyError, TypeError):
                pages = {}
        cache._story_definition_lists = pages
    page = pages.get(match.group(1) + "/main") or {}
    return {section["heading_line"]: (section["heading"], frozenset(section["terms"]), frozenset(section["values"]))
            for section in page.get("sections", ())}


def is_navigation(text):
    """Menus, breadcrumbs, and "see also" lines whose link the text does not keep (※こちら [146] も参照)."""
    return (text.startswith(("簡易プロフィール / 見た目 /", "詳細プロフィール / その他 /"))
            or bool(re.match(r"^Top\s*>|^※?\s*こちら\s*も参照$", text)))


def nickname_rows(lines):
    """Line numbers within nickname sections, including their empty roster rows."""
    excluded = set()
    marks = headings(lines)
    for position, (index, level, title) in enumerate(marks):
        if "呼称一覧" in title:
            end = next((i for i, depth, _ in marks[position + 1:] if depth <= level), len(lines))
            excluded.update(range(index + 1, end + 1))
    return excluded


# --- one person -------------------------------------------------------------------

class Source:
    def __init__(self, relative, lines):
        self.relative, self.lines = relative, lines

    def ref(self, number):
        return f"{self.relative}:{number}"

    def footnotes(self):
        """Cached footer definitions, including continuation lines and their exact source span."""
        if hasattr(self, "_footnotes"):
            return self._footnotes
        found, current = {}, None
        for number, line in enumerate(self.lines, 1):
            match = FOOTNOTE_DEFINITION.match(line)
            if match:
                current = {"first": number, "last": number, "parts": [match.group(2)]}
                found[match.group(1)] = current
            elif HEADING.match(line):
                current = None
            elif current is not None and line.strip():
                current["parts"].append(line)
                current["last"] = number
        self._footnotes = {
            key: {"text": "\n".join(note["parts"]).strip(),
                  "source": self.ref(note["first"]) if note["first"] == note["last"]
                  else f"{self.relative}:{note['first']}-{note['last']}"}
            for key, note in found.items() if any(part.strip() for part in note["parts"])}
        return self._footnotes


def text_page(person, page_id):
    """(Source, page) of a person's page with text, or (None, None)."""
    for entry in person.pages()["pages"]:
        if entry["id"] == page_id and entry["text"]:
            page = person.page(page_id)
            return Source(f"people/{person.slug}/pages/{entry['text']}", page.lines), page
    return None, None


def person_sources(person):
    digest_text = person.digest()
    digest = (Source(f"people/{person.slug}/digest.md", digest_text.split("\n")) if digest_text else None)
    main, _ = text_page(person, "main")
    quotes, _ = text_page(person, "quotes")
    return digest, main, quotes


def shared_source(cache, page_id, core):
    try:
        page = cache.shared().page(page_id)
    except getattr(core, "CacheIntegrityError", ()):
        raise                    # a changed file is not a missing page
    except Exception:            # an older cache without that page
        return None
    return Source(f"shared/{page.entry['text']}", page.lines)


def build_person(cache, person, detail, topics, core):
    info = person.info()
    entry = person.entry
    limits = DETAIL[detail]
    item = limits["item"]
    digest, main, quotes = person_sources(person)
    official = dict(info.get("official") or {})
    if main is not None:
        for key, value in profile_table(main.lines).items():
            official.setdefault(key, value)
    identity = {key: tidy(official[key]) for key in IDENTITY_FIELDS if official.get(key)}
    listing = info.get("wiki_status")
    result = {"name": person.name, "slug": person.slug, "region": entry["region"], "generation": entry["generation"],
              "wiki_listing": listing["label"] if listing else None,
              "identity": identity, "self_reference": info.get("self_reference_row"),
              "sections": {}, "omitted": {}, "missing": []}
    if not entry.get("pages_known"):
        result["note"] = "個人記事が未掲載の欠測記録。本文・人物像・話し方を推測で補わない。"
    elif not entry.get("pages_with_text"):
        result["note"] = "本文は未収録（URLのみ）。read --online で取得してから描写する。"

    def add(key, items, limit):
        result["sections"][key] = items[:limit]
        if len(items) > limit:
            result["omitted"][key] = len(items) - limit

    # Prefer the main table: digests can flatten the speaker/viewer subheadings.
    greeting_rows = []
    for source, words in ((main, ("あいさつ集", "あいさつ", "挨拶")), (digest, ("あいさつ",))):
        if source is None:
            continue
        role = "資料内で区別なし"
        for number, line in section(source.lines, words, skip_subheadings=False):
            if line.startswith("【"):
                role = tidy(line).strip("【】 ")
                continue
            if is_navigation(tidy(line)):
                continue
            if line.lstrip().startswith("|"):
                cells = [tidy(cell) for cell in line.strip().strip("|").split("|")]
                if len(cells) < 2 or not cells[1] or cells[1] in {"セリフ", "観客"}:
                    continue
            text = tidy(line)
            if not text or text.startswith(("場面 — セリフ", "場面 —")) or text in {"場面", "セリフ"}:
                continue
            table = line.lstrip().startswith("|")
            if not table and COLLECTION.search(re.sub(r"\s*[（(][^（）()]*[）)]$", "", text)):
                continue
            note = not table and (text.startswith("※") or not re.search(r"[「『\"]", text))
            greeting_rows.append((note, {"text": clip(text, item), "source": source.ref(number), "role": role}))
        if greeting_rows:
            break
    # Stable: table rows and quoted greetings keep their order, explanations follow them.
    greeting_rows = [row for _, row in sorted(greeting_rows, key=lambda pair: pair[0])]
    add("greetings", greeting_rows, limits["greetings"])
    if not greeting_rows:
        result["missing"].append("あいさつ")

    # Catchphrases: only the person's own 口癖 section or digest.
    phrases = []
    if quotes is not None:
        phrases = [{"phrase": tidy(phrase), "note": clip(note, item), "source": quotes.ref(number)}
                   for number, phrase, note in entries(quotes.lines, under=("口癖",))]
    if not phrases and digest is not None:
        for number, line in section(digest.lines, ("口癖",)):
            match = re.match(r"^- \*\*(.+?)\*\*\s*—\s*(.*)$", line)
            if match:
                phrases.append({"phrase": tidy(match.group(1)), "note": clip(tidy(match.group(2)), item),
                                "source": digest.ref(number)})
    add("catchphrases", phrases, limits["catchphrases"])

    # A shared glossary mark identifies an association, not necessarily a speaker.
    # E.g. Can I kill you? bears both Mumei's and the addressee Fauna's marks.
    related = []
    mark = identity.get("推しマーク")
    if mark and entry["region"] in {"EN", "ID"}:
        shared = shared_source(cache, "en_quotes" if entry["region"] == "EN" else "id_quotes", core)
        if shared is not None:
            for number, phrase, note in entries(shared.lines):
                # The unqualified paw mark is FUWAMOCO's joint mark.
                joint = mark in {"🐾🩵", "🐾🩷"} and "🐾" in phrase and not any(
                    individual in phrase for individual in ("🐾🩵", "🐾🩷"))
                if mark in phrase or joint:
                    related.append({"phrase": tidy(phrase), "note": clip(note, item),
                                    "source": shared.ref(number), "speaker_attribution": "unverified"})
    add("related_quotes", related, limits["catchphrases"])
    if not phrases:
        status = "個人資料の口癖節から抽出なし"
        if quotes is None and any(page["id"] == "quotes" for page in person.pages()["pages"]):
            name = json.dumps(person.name, ensure_ascii=False)
            status += f"（語録ページは本文未収録: read {name} 語録 --section 口癖 --all --online で取得・HTTP）"
        result["catchphrase_status"] = status + ("／関連語録は要確認" if related else "")

    # Personality and related sections: digest (JP45), else the main page.
    personality_lines = []
    for key, label, digest_words, main_words in SECTIONS:
        rows = []
        if key in {"likes", "dislikes"}:
            # The digest keeps only the first lines of a section: likes and dislikes read the main page.
            for source, words in ((main, main_words), (digest, digest_words)):
                rows = (preference_items(source, words, item, definition_lists(cache, core, source))
                        if source is not None else [])
                if rows:
                    break
            notes = [{key: value for key, value in row.items() if key not in {"kind", "label"}}
                     for row in rows if row.get("kind") == "note"]
            rows = [row for row in rows if row.get("kind") != "note"]
            if notes and rows:              # notes on the whole section: not counted as items
                result.setdefault("section_notes", {})[key] = notes
        else:
            _, rows = readable_section(((digest, digest_words), (main, main_words)), item)
            if not rows and key in FALLBACK:
                digest_fallback, main_fallback = FALLBACK[key]
                heading, rows = readable_section(((digest, digest_fallback), (main, main_fallback)), item,
                                                 lead_only=True)
                if rows:
                    result.setdefault("fallback_headings", {})[key] = heading
        add(key, rows, limits[key])
        if key == "personality":
            personality_lines = rows
        if not rows:
            result["missing"].append(label)

    # Reaction cues: catchphrases whose note names a situation, then personality lines.
    cues, used = [], {}
    for phrase in phrases:
        for label in classify(phrase["note"]):
            if used.get(label, 0) < limits["per_reaction"]:
                cues.append({"keyword_group": label, "attribution": "unverified", "text": f"「{phrase['phrase']}」— {phrase['note']}",
                             "source": phrase["source"]})
                used[label] = used.get(label, 0) + 1
                break
    for row in personality_lines:
        for label in classify(row["text"]):
            if used.get(label, 0) < limits["per_reaction"]:
                cues.append({"keyword_group": label, "attribution": "unverified", "text": row["text"], "source": row["source"]})
                used[label] = used.get(label, 0) + 1
                break
    order = {label: position for position, (label, _) in enumerate(REACTIONS)}
    cues.sort(key=lambda cue: order[cue["keyword_group"]])
    add("reactions", cues, limits["reactions"])

    # Topic lines from every text page (digest excluded: it repeats the pages).
    if topics:
        hits = []
        folded_topics = [topic.casefold() for topic in topics]
        for page in person.text_pages():
            source = Source(f"people/{person.slug}/pages/{page.entry['text']}", page.lines)
            for number, line in enumerate(page.lines, 1):
                folded_line = line.casefold()
                if not any(topic in folded_line for topic in folded_topics) or HEADING.match(line):
                    continue
                text = tidy(line)
                if len(text) >= 2 and not is_navigation(text):
                    hits.append({"text": clip(text, item), "source": source.ref(number),
                                 "page": page.entry["id"]})
        hits.sort(key=lambda hit: (bool(LIST_PAGES.match(hit["page"])), hit["page"] != "main"))
        add("topic", hits, limits["topic"])
    return result


# --- pairs --------------------------------------------------------------------------

def split_cell(cell):
    """(current names, struck-through names) of a nickname cell."""
    def names(text):
        return [part.strip() for part in re.split(r"[、,，/／]", text) if part.strip()]
    struck = [name for part in re.findall(r"~~(.*?)~~", cell or "") for name in names(tidy(part))]
    return names(STRUCK.sub("", cell or "")), struck


def calls(tables, speaker, target):
    """How speaker calls target: from the speaker's table and from the target's table."""
    own = [r for r in tables[speaker.slug]["records"] if r.get("counterpart_slug") == target.slug]
    other = [r for r in tables[target.slug]["records"] if r.get("counterpart_slug") == speaker.slug]
    result = {}
    for key, rows, field in (("speaker_table", own, "calls"), ("target_table", other, "called_by")):
        names, struck = [], []
        for row in rows:
            current, gone = split_cell(row.get(field) or "")
            names += current
            struck += gone
        result[key] = {"names": list(dict.fromkeys(names)), "struck": list(dict.fromkeys(struck))}
    return result


def terms_for(cache, names_module, target, speaker_calls):
    """Words that point at target in someone else's pages.

    A two-letter hiragana nickname (すい, にこ, ちは) is too common a syllable pair to find a person
    by; the end of the official name (ねね, そら, みこ) is kept.
    """
    entry = target.entry
    words = [entry["name"], *(entry.get("aliases") or []), *(entry.get("readings") or []), *speaker_calls]
    if entry["region"] != "JP":
        words += [part for part in entry["name"].split() if len(part) >= 4]
    generic = names_module.GENERIC
    kept = []
    for word in words:
        word = re.sub(r"[（(][^）)]*[）)]", "", word).strip()
        if len(word) == 2 and HIRAGANA_WORD.match(word) and not entry["name"].endswith(word):
            continue
        if len(word) >= 2 and names_module.fold(word) not in generic and word not in kept:
            kept.append(word)
    return sorted(kept, key=len, reverse=True)


def names_in(line, words):
    """Does the line name one of the words? A short hiragana name needs a particle, an honorific or
    no hiragana after it (NAME_FOLLOWERS); a Latin name is not inside a longer word (Gurarium), though
    it may follow another name in camel case (SameMori)."""
    for word in words:
        if word not in line:
            continue
        hiragana, latin = bool(HIRAGANA_WORD.match(word)), word.isascii()
        if not (hiragana or latin):
            return True
        start = line.find(word)
        while start >= 0:
            before, after = line[start - 1:start] if start else "", line[start + len(word):]
            if hiragana and (not after or not "ぁ" <= after[0] <= "ゖ" or after.startswith(NAME_FOLLOWERS)):
                return True
            joined = before.isascii() and before.isalpha() and not (before.islower() and word[:1].isupper())
            if latin and not joined and not (after[:1].isascii() and after[:1].islower()):
                return True                  # SameMori (two names joined) counts; Gurarium does not
            start = line.find(word, start + 1)
    return False


class PageText:
    """A page's lines as one string, so a word's lines are found by str.find instead of line by line."""

    def __init__(self, lines):
        self.text = "\n".join(lines)
        self.starts = [0]
        for line in lines[:-1]:
            self.starts.append(self.starts[-1] + len(line) + 1)

    def numbers_with(self, words):
        """Sorted 1-based numbers of the lines that contain one of the words."""
        import bisect
        found = set()
        for word in words:
            start = self.text.find(word)
            while start >= 0:
                number = bisect.bisect_right(self.starts, start)
                found.add(number)
                start = self.text.find(word, self.starts[number] if number < len(self.starts) else len(self.text))
        return sorted(found)


def build_pairs(cache, people, detail, core):
    names_module = core._module("hololive_names")
    limits = DETAIL[detail]
    item = limits["item"]
    tables = {person.slug: person.nicknames() for person in people}
    combos = shared_source(cache, "combos_units", core)
    pairs = []
    texts = {person.slug: [(Source(f"people/{person.slug}/pages/{page.entry['text']}", page.lines), page.entry["id"],
                            page.entry.get("label") or page.entry["id"], nickname_rows(page.lines), PageText(page.lines))
                           for page in person.text_pages() if page.entry["id"] != "nicknames_page"]
             for person in people}
    own_words = {person.slug: terms_for(cache, names_module, person, []) for person in people}
    for index, first in enumerate(people):
        for second in people[index + 1:]:
            pair = {"people": [first.name, second.name],
                    "calls": {f"{first.name}→{second.name}": calls(tables, first, second),
                              f"{second.name}→{first.name}": calls(tables, second, first)},
                    "combos": [], "mentions": [], "list_mentions": {}, "omitted": {}}
            if combos is not None:
                found = []
                for number, line in enumerate(combos.lines, 1):
                    if first.name in line and second.name in line and line.startswith("|"):
                        cells = [tidy(cell) for cell in line.strip().strip("|").split("|")]
                        if len(cells) >= 3 and cells[0].isdigit():
                            size = int(cells[0])
                            text = f"{cells[1]}（{size}人: {cells[2]}）" + (f" — {cells[3]}" if len(cells) > 3 and cells[3]
                                                                         and cells[3] != "編集" else "")
                            found.append((size, {"text": clip(text, item), "source": combos.ref(number)}))
                found.sort(key=lambda pair_item: pair_item[0])
                pair["combos"] = [value for _, value in found[:limits["combos"]]]
                if len(found) > limits["combos"]:
                    pair["omitted"]["combos"] = len(found) - limits["combos"]
            mentions = []
            for speaker, target in ((first, second), (second, first)):
                spoken = calls(tables, speaker, target)
                words = terms_for(cache, names_module, target, spoken["speaker_table"]["names"])
                listed = {}
                for source, page_id, label, excluded, page_text in texts[speaker.slug]:
                    for number in page_text.numbers_with(words):
                        line = source.lines[number - 1]
                        if number in excluded or HEADING.match(line) or not names_in(line, words):
                            continue
                        maybe_navigation = "プロフィール" in line or "Top" in line
                        if LIST_PAGES.match(page_id):            # only counted: no need to tidy every title
                            if not (maybe_navigation and is_navigation(tidy(line))):
                                listed[label] = listed.get(label, 0) + 1
                            continue
                        text = tidy(line)
                        if maybe_navigation and is_navigation(text):
                            continue
                        if len(text) < 12 or text in words:
                            continue
                        both = names_in(line, own_words[speaker.slug])
                        prose = not (line.lstrip().startswith("|") or re.match(r"^\d{4}/\d{1,2}/\d{1,2}", text))
                        mentions.append((0 if prose else 1, 0 if page_id == "episodes" else 1 if page_id == "main" else 2,
                                         0 if both else 1, len(text),
                                         {"text": clip(text, item), "source": source.ref(number),
                                          "about": f"{speaker.name}の資料で{target.name}に触れた行"}))
                if listed:
                    pair["list_mentions"][speaker.name] = listed
            mentions.sort(key=lambda value: value[:4])
            pair["mentions"] = [value[4] for value in mentions[:limits["mentions"]]]
            if len(mentions) > limits["mentions"]:
                pair["omitted"]["mentions"] = len(mentions) - limits["mentions"]
            pairs.append(pair)
    return pairs


# --- rendering -----------------------------------------------------------------------

def render_note(note):
    label = "注記"
    if note.get("footnote"):
        label += f"（脚注{note['footnote']}・原文「{note['reference_text']}」）"
    return f"{label}: {note['text']}（{note['source']}）"


def render_md(pack):
    out = [f"# 物語用資料パック: {' × '.join(person['name'] for person in pack['people'])}", "",
           "> " + pack["rules"], f"> 資料の時点: {pack['snapshot']}（詳細度: {pack['detail']}）", ""]
    if pack["pairs"]:
        out += ["## 相互の呼び方", ""]
        for pair in pack["pairs"]:
            for direction, value in pair["calls"].items():
                own, other = value["speaker_table"], value["target_table"]
                speaker, target = direction.split("→")
                text = "、".join(own["names"]) or "—"
                if other["names"] != own["names"]:
                    text += f"（{target}側の表: {'、'.join(other['names']) or '—'}）"
                for side, value_struck in ((speaker, own["struck"]), (target, other["struck"])):
                    if value_struck:
                        text += f"［{side}側の表で取り消し線付き（現行扱いしない）: {'、'.join(value_struck)}］"
                out.append(f"- {direction}: {text}")
        out += ["", "空欄（—）は資料に記載がないだけで、呼び方や交流が無いことを意味しない。", ""]
        out += ["## 組み合わせ・相手への言及", "", "名前の一致による候補。共演や親密さの根拠として使う前に本文を確認する。", ""]
        for pair in pack["pairs"]:
            out.append(f"### {pair['people'][0]} × {pair['people'][1]}")
            for combo in pair["combos"]:
                out.append(f"- コンビ・ユニット名: {combo['text']}（{combo['source']}）")
            for mention in pair["mentions"]:
                out.append(f"- {mention['text']}（{mention['source']}）")
            for speaker, listed in pair["list_mentions"].items():
                counts = "、".join(f"{page} {count}行" for page, count in sorted(listed.items()))
                out.append(f"- {speaker}の一覧ページで相手の名前が出る行: {counts}（名前の一致件数）")
            if not (pair["combos"] or pair["mentions"] or pair["list_mentions"]):
                out.append("- 収録ページでは本文の言及候補が見つからない（未収録ページ・他の呼び名の可能性あり）")
            if pair["omitted"]:
                out.append("- ほかに " + "、".join(f"{OMITTED_LABELS.get(key, key)} {count}件"
                                                   for key, count in pair["omitted"].items())
                           + f"（find {json.dumps(pair['people'][0], ensure_ascii=False)} "
                             f"{json.dumps(pair['people'][1], ensure_ascii=False)} で探せる）")
            out.append("")
    labels = {key: label for key, label, _, _ in SECTIONS}
    for person in pack["people"]:
        out += [f"## {person['name']}（{person['region']} / {person['generation']}）", ""]
        if person["wiki_listing"]:
            out.append(f"- {person['wiki_listing']}（公式未照合。物語では会話の前提を優先）")
        if person["identity"]:
            out.append("- " + " / ".join(f"{key}: {value}" for key, value in person["identity"].items()))
        if person.get("note"):
            out.append("- 注意: " + person["note"])
        out.append("- 一人称・自称（呼称表の本人行）: " + (person["self_reference"] or "記載なし"))
        sections = person["sections"]
        if sections.get("greetings"):
            out += ["", "### あいさつ"] + [f"- 【{row['role']}】{row['text']}（{row['source']}）" for row in sections["greetings"]]
        if sections.get("catchphrases"):
            out += ["", "### 口癖"] + [f"- {row['phrase']} — {row['note']}（{row['source']}）"
                                       for row in sections["catchphrases"]]
        if person.get("catchphrase_status"):
            out += ["", "- " + person["catchphrase_status"]]
        if sections.get("related_quotes"):
            out += ["", "### 関連語録の候補（発話者・口癖かどうかは未確認）",
                    "推しマークの一致で抽出。相手の発言や視聴者の言葉、単発の発言も含む。"]
            out += [f"- {row['phrase']} — {row['note']}（{row['source']}）" for row in sections["related_quotes"]]
        for key, _, _, _ in SECTIONS:
            if sections.get(key):
                heading = person.get("fallback_headings", {}).get(key)
                title = labels[key] + (f"（見出し「{heading}」の冒頭から）" if heading else "")
                out += ["", f"### {title}"]
                out += [f"- 注記（この節全体）: {note['text']}（{note['source']}）"
                        if not note.get("footnote") else "- この節全体の" + render_note(note)
                        for note in person.get("section_notes", {}).get(key, ())]
                for row in sections[key]:
                    out.append(f"- {row['text']}（{row['source']}）")
                    out += ["  - " + render_note(note) for note in row.get("notes", ())]
        if sections.get("reactions"):
            out += ["", "### 反応場面の検索候補（語句一致・本人の反応とは未確認）"] + [f"- 関連語「{row['keyword_group']}」: {row['text']}（{row['source']}）"
                                              for row in sections["reactions"]]
        if "topic" in sections:
            out += ["", f"### 話題「{'・'.join(pack['topics'])}」"]
            out += [f"- {row['text']}（{row['source']}）" for row in sections["topic"]] or ["- 該当する行なし"]
        notes = []
        if person["omitted"]:
            notes.append("省略: " + "、".join(f"{OMITTED_LABELS.get(key, key)} {count}件"
                                            for key, count in person["omitted"].items()))
        if person["missing"]:
            notes.append("収録資料に見当たらない: " + "、".join(person["missing"]))
        if notes:
            out += ["", "- " + " ／ ".join(notes)]
        out.append("")
    out += ["## さらに読む", ""] + [f"- `{command}`" for command in pack["next"]] + [""]
    return "\n".join(out)


CITED = re.compile(r"((?:people|shared)/[^:]+):\d+(?:-\d+)?")


def saved_dates(cache, people, pack):
    """The days the wiki text behind a pack was saved: each cited page's own fetch time, and the original
    cache's days for what it holds from there (the JP45 digests and profile tables). Empty when the pack
    cites nothing."""
    original = [stamp for stamp in cache.catalog.get("source", {}).get("snapshot_fetched_at") or [] if stamp]
    fetched = {}
    for person in people:
        for entry in person.pages()["pages"]:
            if entry.get("text"):
                fetched[f"people/{person.slug}/pages/{entry['text']}"] = [entry.get("fetched_at")]
    for entry in cache.shared().data["pages"]:
        if entry.get("text"):
            fetched[f"shared/{entry['text']}"] = [entry.get("fetched_at")]
    stamps = set()

    def walk(value):
        if isinstance(value, dict):
            for item in value.values():
                walk(item)
        elif isinstance(value, list):
            for item in value:
                walk(item)
        elif isinstance(value, str):
            match = CITED.fullmatch(value)
            if match:
                stamps.update(fetched.get(match.group(1)) or original)
    walk(pack["people"])
    walk(pack["pairs"])
    for person, built in zip(people, pack["people"]):
        if built["identity"]:
            info = person.info()
            source = info.get("official_source")
            stamps.update([source.get("fetched_at")] if source else original if info.get("official") else [])
    return sorted({stamp[:10] for stamp in stamps if stamp})


def build_pack(cache, names, *, topics=(), detail="normal", budget=None, core=None, output_format="md",
               automatic_budget=False):
    """(pack, markdown). budget limits the length of the output (JSON with its indentation), or with
    automatic_budget that of the Markdown text whatever the format; the detail level drops
    (full → normal → brief) until it fits, else CacheError."""
    measure = "md" if automatic_budget else output_format
    people = []
    for name in names:
        person = cache.person(name)
        if all(person.slug != other.slug for other in people):
            people.append(person)
    fetched = cache.catalog.get("source", {}).get("snapshot_fetched_at") or []
    online = (cache.catalog.get("online_snapshots") or {}).get("fetched_at") or []
    everything = sorted(stamp[:10] for stamp in list(fetched) + list(online) if stamp)
    order = ["full", "normal", "brief"]
    start = order.index(detail)
    for level in order[start:]:
        pack = {"schema": SCHEMA, "generator": f"hololive_story.py {VERSION}", "detail": level,
                "rules": RULES, "snapshot": None, "topics": list(topics),
                "people": [build_person(cache, person, level, list(topics), core) for person in people],
                "pairs": build_pairs(cache, people, level, core) if len(people) > 1 else [],
                "next": next_commands(people, topics)}
        # The days of the cited text; with nothing cited, the days of the whole cache.
        stamps = saved_dates(cache, people, pack) or everything
        pack["snapshot"] = (("wikiの保存日 " + (stamps[0] if stamps[0] == stamps[-1] else f"{stamps[0]}〜{stamps[-1]}"))
                            if stamps else "wikiの保存日は catalog.json を参照")
        pack["budget"] = {"limit": budget, "measured_as": measure, "automatic": automatic_budget}
        text = render_md(pack)
        pack["characters"] = len(text)
        output_size = len(text) if measure == "md" else len(json.dumps(pack, ensure_ascii=False, indent=1)) + 1
        if budget is None or output_size <= budget:
            return pack, text
        if level == "brief":
            limit = f"既定の上限 {budget:,} 字（Markdown換算）" if automatic_budget else f"--budget {budget:,}"
            raise core.CacheError(f"最小の詳細度でも {output_size:,} 字となり{limit}を超えます。"
                                  f"人数を分けるか --budget {output_size} 以上を指定してください。")
    raise AssertionError("unreachable")


def next_commands(people, topics):
    commands = []
    for person in people:
        name = json.dumps(person.name, ensure_ascii=False)
        pages = {entry["id"]: bool(entry["text"]) for entry in person.pages()["pages"]}
        if "quotes" in pages:
            commands.append(f"read {name} 語録 --section 口癖 --all" + ("" if pages["quotes"] else " --online"))
        if person.entry["files"].get("digest"):
            commands.append(f"show {name} --digest")
        if "main" in pages:
            commands.append(f"read {name} main --all" + ("" if pages["main"] else " --online"))
        else:
            commands.append(f"show {name}")
    if len(people) > 1:
        a, b = (json.dumps(person.name, ensure_ascii=False) for person in people[:2])
        commands.append(f"find {a} {b}")
        commands.append(f"nicknames {a} --query {b}")
    for topic in topics:
        commands.append(f"search {json.dumps(topic, ensure_ascii=False)} --limit 40")
    return commands


# --- command line (registered by hololive_cache_core as `story`) -------------------------

def add_arguments(parser):
    parser.add_argument("person", nargs="+", help="1人以上（物語の登場人物）")
    parser.add_argument("--topic", action="append", default=[], help="場面の話題。各人の本文から該当行を添える。複数なら --topic を繰り返す（--topic 料理 --topic ホラー）")
    parser.add_argument("--detail", choices=tuple(DETAIL), default="normal",
                        help="brief / normal（既定）/ full。人数が多いときは brief")
    parser.add_argument("--budget", type=int, default=None,
                        help="明示時は指定出力形式の実文字数が上限（JSONの整形・改行も含む）。"
                             "未指定時のみ、1人12,000字＋追加1人ごとに10,000字をMarkdown換算で適用し、"
                             "MD/JSONを同じ詳細度で出す。詳細度を下げても超える場合はエラー")
    parser.add_argument("--format", choices=("md", "json"), default="md")


def run(cache, args, *, core):
    if args.budget is not None and args.budget < 1000:
        raise core.CacheError("--budget は1000以上にしてください。")
    automatic = args.budget is None
    budget = 12000 + 10000 * (len(args.person) - 1) if automatic else args.budget
    # The automatic limit is about how much there is to read, so JSON's quoting and indentation
    # do not push a JSON pack down to a lower detail level than the same pack in Markdown.
    pack, text = build_pack(cache, args.person, topics=args.topic, detail=args.detail, budget=budget, core=core,
                            output_format=args.format, automatic_budget=automatic)
    if args.format == "json":
        core.out(json.dumps(pack, ensure_ascii=False, indent=1))
    else:
        sys.stdout.write(text if text.endswith("\n") else text + "\n")
    return 0
