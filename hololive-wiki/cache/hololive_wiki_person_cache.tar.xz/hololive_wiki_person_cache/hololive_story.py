#!/usr/bin/env python3
"""Story material pack: what a writer needs about a cast, from the cached wiki, in one bounded read.

Run through the cache CLI (the archive's hololive_cache.py or the skill's wrapper):

    hololive_cache.py story 宝鐘マリン 兎田ぺこら --topic 料理
    hololive_cache.py story ラプラス・ダークネス 鷹嶺ルイ 博衣こより --format json
    hololive_cache.py story 宝鐘マリン 兎田ぺこら --group JP --topic 運動会   (a scene with many members)
    hololive_cache.py story 名前1 … 名前15 --part 1      (then --part 2 … to the last part)
    hololive_cache.py story 名前1 … 名前15 --level       (the detail level only, not the pack)

The detail level is chosen automatically (ace > full > normal > brief > cameo; ace
gives a person's own sections whole): the most detailed step of LADDER whose
pack fits the limit (default_budget: 80,000 characters for one person, 10,000
more for each other one, at most 200,000), each person's own section kept above
the pairs' mention candidates; the room left then raises single people's
sections one level, the first names first. A long Markdown pack can be read in
parts of at most 15,000 characters (--part). --level shows only the level a
command gets (each person's and the pairs', with the size against the limit),
to check it without the pack: the pack and its level stay as without --level.

A scene that needs many members (a sports day, a festival, a live or a party with
everyone) names its central characters first and adds the others with --group
(GROUP_NAMES: JP, EN, ID, all, DEV_IS, promise, a generation or unit): the
members the wiki's top page lists as current, in the order of its member table
(--include-former adds those listed as graduated or ended, for a premise such as
卒業生はいない; --exclude leaves someone out). Any such cast fits the automatic
limit: below brief, a person can be cameo (identity, first person, a greeting, a
few catchphrases, one or two lines on the character) and the pairs names (one
line per speaker: how they call each of the others in both people's tables; and
the combination names whose members are all in the cast); the mention scan of
the pairs is skipped when the pack cannot fit with it (lower_bound). The room
left raises the first names, as for any cast.

For each person (JP talents with a digest use it; everyone else uses the main
page's sections and the shared EN/ID quote pages):
  identity     region, generation, listing on the wiki's top page (a wiki
               record, not checked against the official site), fan name,
               oshi mark, birthday, the person's own row of the nickname table
  speech       greetings, catchphrases from the person's 口癖 section;
               shared EN/ID glossary entries are association candidates,
               since a mark can identify a speaker, addressee or viewer
  personality  性格・癖, likes, dislikes, place within hololive, stream style;
               the first heading with readable lines, by word priority
               (an empty ##### 配信の特徴 passes to 配信内容, whose lead and
               subsections are read apart, without ##### 3Dモデルでの配信);
               without a personality heading, the lead of the detailed
               profile, named in the pack; likes and dislikes come from the
               main page, each term joined with its own definitions as the
               wiki's definition lists mark them (definition_lists.json),
               else as guessed from the lines (guessed_groups); a line outside
               the list is a note on the item before it (notes), or on the
               whole section before any item (section_notes); referenced footer
               footnotes accompany the visible item, with their original context
  reactions    keyword search candidates from catchphrases/personality,
               explicitly unverified as that person's reaction
For each pair: how each calls the other in both people's tables (struck-through
names retained separately), the combination and unit names they share,
and lines where one person's pages mention the other (at the names level: the
calls only, one line per speaker, and the cast's combination names).
--topic adds each person's lines about the scene's subject (repeat it for several;
a phrase with spaces that no page holds is searched word by word, see searched_topics).

Extracted prose carries its source as file:line, so a statement about real events
can be checked. The pack's saved dates are those of the text it cites (each page's
own fetch time; for a JP45 digest and profile table, the fetch times of the pages they were made from, or the
original cache's days where its files were kept). The pack is material, not canon: a story keeps the
conversation's premise, does not present invented lines as real quotes, and
does not append source lists unless asked (the skill's rules).

Python 3.9+, standard library only. It reads only the cast's files, the
shared page list, four shared pages and definition_lists.json (--group: also
the catalog's people's person.json); nothing is fetched.
"""

from __future__ import annotations

import json
import os
import re
import sys
from urllib.parse import urlsplit

VERSION = "1.8.0"
SCHEMA = "hololive-story-pack/3"
HEADING = re.compile(r"^(#{1,6})\s+(.*?)\s*$")
LINK_MARK = re.compile(r"\s?\[\d+\]")
# A line that is only a link: its text, then one link number at the end.
TRAILING_LINK = re.compile(r"^(.*\S)\s+\[(\d+)\]\s*$")
# Under a catchphrase the wiki lists the videos where it was said, one title per line, after the
# explanation. Such a line links to a video and reads as a title (【…】, #shorts, a leading date, the
# channel name); a line that describes the video in a sentence is part of the explanation and stays.
VIDEO_HOSTS = frozenset({"www.youtube.com", "youtube.com", "m.youtube.com", "youtu.be"})
VIDEO_TITLE = re.compile(r"【|#shorts|^\d{4}/\d{1,2}/\d{1,2}[：:]|\| ?hololive|/ ?hololive|ホロライブ", re.I)
TITLE_MARKS = re.compile(r"【|#shorts|^\d{4}/\d{1,2}/\d{1,2}[：:]", re.I)
LINK_NUMBER = re.compile(r"\[(\d+)\]")
ENUMERATED_LINKS = re.compile(r"[❶-❿①-⑳]|\s/\s")
# A footnote that only says where something comes from: every part of it is a link whose text is a
# URL, a site or account name, a word for a source (証言, 出典…), or the title of a video or post on a
# video or social site. A link whose text explains something (バカ殿が登場する怖い夢を見て…ため [930],
# ちなみに紫である [461]) is not a citation.
CITATION_SITE = re.compile(r"^(?:https?://\S+$|(?:YouTube|Twitter|X|X\s*[(（]Twitter[)）]|bilibili|ニコニコ|niconico|"
                           r"hololive|Reddit|Instagram|TikTok|Twitch)(?:\s|@|$)|@\w)", re.I)
CITATION_WORDS = frozenset({"証言", "ソース", "出典", "出典元", "ポスト", "公式サイト", "公式プレスリリース",
                            "タレントページ", "詳しい説明", "関連用語", "関連語"})
CITATION_LABEL = re.compile(r"^(?:出典|ソース|参考)[:：]")
MEDIA_HOSTS = ("youtube.com", "youtu.be", "x.com", "twitter.com", "bilibili.com", "b23.tv", "nicovideo.jp", "nico.ms",
               "twitch.tv", "tiktok.com", "instagram.com")
NOTE_MARK = re.compile(r"\s?[*＊]\d+")
FOOTNOTE_MARK = re.compile(r"[*＊](\d+)")
FOOTNOTE_DEFINITION = re.compile(r"^\s*[*＊](\d+)\s*[:：]\s*(.*)$")
STRUCK_WITH_NOTES = re.compile(r"~~.*?~~(?:\s*[*＊]\d+)*(?:\s*[（(][^（）()]*[）)])?(?:\s*[*＊]\d+)*")
# A struck-through item goes with the note right after it (~~炭酸飲料~~（克服済み）), and with the comma
# before it when it ends the line.
STRUCK = re.compile(r"~~.*?~~(?:\s*[（(][^（）()]*[）)])?")
STRUCK_LAST = re.compile(r"[、，,]\s*~~[^~]*~~(?:\s*[（(][^（）()]*[）)])?\s*$")
SENTENCE_END = "。！？!?"
# Likes and dislikes are definition lists on the wiki; the reader flattens each term and each value to a
# line of its own. A term either names a category (好きな食べ物, 食べ物（素材）, 苦手な物) or is a short
# noun phrase followed by a list or a sentence (人食い → 食において人間は好みではない。).
TERM_START = re.compile(r"^(?:大?好きな|嫌いな|苦手な|得意な|NG)")
# A line outside the list that comments on it: ※過去に好きだったものも含まれます。 / 注釈:… The marker is
# dropped when the note is shown (the pack labels it 注記).
NOTE_START = re.compile(r"^(?:※|注釈\s*[:：]|注\s*[:：]|[（(]注[）)])\s*")
TERM_NOUNS = frozenset("食べ物 飲み物 飲食物 お酒 酒 趣味 特技 アレルギー その他 全般 ゲーム アニメ 漫画 マンガ 音楽 色 "
                       "動物 生き物 場所 家事 科目 スポーツ 運動".split())
# A particle inside a phrase makes it a clause (教育を受けている, キーが高い, 朝に食べると), not a term.
CLAUSE = re.compile(r"を|(?<=[一-龯ァ-ヺー）)])[がにでは](?=[ぁ-ゖ一-龯])")
# A short hiragana name inside running hiragana is usually an ordinary word (甘えはじめて, おそらく):
# it counts when a particle or an honorific follows it, or no hiragana at all.
HIRAGANA_WORD = re.compile(r"^[ぁ-ゖー]{1,4}$")
NAME_FOLLOWERS = ("の", "が", "は", "を", "に", "と", "も", "へ", "や", "ね", "よ", "ら", "ー",
                  "さん", "さま", "ちゃん", "くん", "たん", "っち")
# A line that only names a collection behind a link (他メンバーによる物真似集 [584]) is not a greeting.
COLLECTION = re.compile(r"(?:集|一覧|まとめ|リスト)$")
# (label, words that name the situation in a catchphrase note or a personality line)
REACTIONS = (
    ("驚き", ("驚", "びっくり", "予想外", "意外", "仰天", "ビックリ")),
    ("喜び・興奮", ("嬉し", "喜", "テンション", "興奮", "はしゃ", "感動", "大喜び")),
    ("照れ", ("照れ", "恥ずかし", "褒められ", "赤面", "てれ")),
    ("困惑・焦り", ("焦", "困", "混乱", "戸惑", "パニック", "慌て", "動揺", "テンパ")),
    ("心配・気遣い", ("心配", "気遣", "励ま", "慰め", "労い", "気にかけ")),
    ("失敗・悔しさ", ("失敗", "ミス", "負け", "悔し", "ゲームオーバー", "非業", "やらかし", "死亡")),
    ("からかい・ツッコミ", ("からか", "いじ", "ツッコ", "煽", "罵倒", "キレ", "怒", "文句", "毒")),
    ("怖さ・緊張", ("緊張", "怖", "ホラー", "ビビ", "悲鳴", "絶叫", "叫")),
)
# (key, label, heading words in digest.md, heading words in a main page), most specific word first.
# A heading without readable lines (an empty ##### 配信の特徴) passes to the next word (#### 配信内容など).
# The digest flattens 配信内容 with its subsections, so only the main page's 配信内容 is read.
SECTIONS = (
    ("personality", "性格・癖", ("性格・癖",), ("性格や癖", "性格・癖", "性格")),
    ("likes", "好きなもの・得意なもの", ("好きなもの",), ("好きなもの",)),
    ("dislikes", "嫌いなもの・苦手なもの", ("嫌いなもの",), ("嫌いなもの",)),
    ("position", "ホロライブ内での立ち位置", ("ホロライブ内での立ち位置",), ("ホロライブ内での立ち位置",)),
    ("stream", "配信の特徴", ("配信の特徴",), ("配信の特徴", "配信内容", "配信傾向")),
)
# Pages without a personality heading (ロボ子さん, 星街すいせい, 湊あくあ) describe the character in the
# lead of the detailed profile; the pack names that heading.
FALLBACK = {"personality": (("プロフィール・特徴",), ("プロフィール、特徴", "プロフィール・特徴"))}
# A parent heading read for a section (#### 配信内容など for 配信の特徴): its lead, then each subsection
# named 【like this】, leaving out the ones about something else (##### 3Dモデルでの配信, lists).
PARENT_WORDS = frozenset({"配信内容"})
ELSEWHERE = re.compile(r"3D|一覧|お披露目")
IDENTITY_FIELDS = ("ファンの愛称", "推しマーク", "誕生日", "身長", "初配信日")
# Pages that list titles (songs, videos...): a mention there shows a collaboration, not a scene.
LIST_PAGES = re.compile(r"^(songs|videos|twitter_videos|bgm|costumes|designer_art|references|games|stream_songs|"
                        r"song_streams|member_streams|membership|own_works|drinks)")
EVERY = 10 ** 9          # no cap: every item found
DETAIL = {
    "brief": {"greetings": 3, "catchphrases": 8, "personality": 3, "likes": 2, "dislikes": 2, "position": 2,
              "stream": 1, "reactions": 6, "per_reaction": 1, "topic": 3, "combos": 3, "mentions": 3, "item": 110},
    "normal": {"greetings": 6, "catchphrases": 15, "personality": 6, "likes": 4, "dislikes": 4, "position": 4,
               "stream": 3, "reactions": 12, "per_reaction": 2, "topic": 6, "combos": 5, "mentions": 6, "item": 160},
    "full": {"greetings": 12, "catchphrases": 40, "personality": 12, "likes": 8, "dislikes": 8, "position": 8,
             "stream": 6, "reactions": 24, "per_reaction": 4, "topic": 12, "combos": 10, "mentions": 12, "item": 320},
    # ace (2026-10-06b): above full, for the room a small cast leaves. A person's own sections come whole (every
    # item found, a line clipped only past 2,000 characters; one person is at most about 53,000 characters);
    # the keyword candidates (reactions, topic lines, the pairs' mentions) only grow, since without a cap
    # they run to hundreds of lines (a topic like 歌 matches every song row; 宝鐘マリン × 兎田ぺこら, 230 mentions).
    "ace": {"greetings": EVERY, "catchphrases": EVERY, "personality": EVERY, "likes": EVERY, "dislikes": EVERY,
            "position": EVERY, "stream": EVERY, "reactions": 48, "per_reaction": 8, "topic": 30, "combos": EVERY,
            "mentions": 30, "item": 2000},
    # cameo (2026-10-09): below brief, for a large cast (a scene with many members): enough to place a person
    # in a scene and give a line or two. Pairs are never below names (PAIR_NAMES), so combos and mentions
    # are not used at this level.
    "cameo": {"greetings": 1, "catchphrases": 3, "personality": 2, "likes": 1, "dislikes": 1, "position": 1,
              "stream": 0, "reactions": 0, "per_reaction": 0, "topic": 2, "combos": 0, "mentions": 0, "item": 90},
}
DETAIL_ORDER = ("ace", "full", "normal", "brief", "cameo")      # most detailed first
# The people's levels and the pairs', a lower rank more detailed: the pairs have those of DETAIL down to brief,
# then names (how each one calls the others, without mention candidates), which goes with cameo.
LEVEL_RANK = {**{level: position for position, level in enumerate(DETAIL_ORDER)}, "names": DETAIL_ORDER.index("cameo")}
# The names level: the cast's combination names (all members in the cast), at most this many, clipped like brief.
PAIR_NAMES = {"combos": 60, "item": DETAIL["brief"]["item"]}
OMITTED_LABELS = {"greetings": "あいさつ", "catchphrases": "口癖", "related_quotes": "関連語録の候補",
                  **{key: label for key, label, _, _ in SECTIONS},
                  "reactions": "反応場面の検索候補", "topic": "話題の行", "combos": "コンビ・ユニット名",
                  "mentions": "言及候補"}
RULES = ("wiki（非公式・二次資料）の抜粋。各行末の（ファイル:行）が根拠で、現実の出来事として述べる内容はそこで確かめる。"
         "物語では会話で指定された前提（例: 卒業生なしの世界）を優先し、ここにある台詞を実際の発言として引用しない。"
         "出典一覧や定型の注記は、求められない限り物語に付けない。")


# --- text helpers -----------------------------------------------------------------

SPAN_MARK = re.compile(r"\[(?:row|col)span=\d+\]\s*")
SPACES = re.compile(r"\s+")
LINK_WITH_SPACES = re.compile(r"\s*\[\d+\]\s*")
# What removing a struck-through item leaves behind: 、、 / "/ /" / "— /" / a trailing "/".
LEFTOVERS = ((re.compile(r"、(?:\s*、)+"), "、"), (re.compile(r"\s*/(?:\s*/)+"), " /"), (re.compile(r"—\s*/\s*"), "— "),
             (re.compile(r"\s*/\s*(?=—|$)"), " "))


def without_link_marks(text):
    """Drop [n] link numbers with the spaces around them (肉の脂身 [487] 、 → 肉の脂身、), keeping one
    space between two Latin words."""
    def replace(match):
        before, after = text[match.start() - 1:match.start()], text[match.end():match.end() + 1]
        latin = before.isascii() and before.isalnum() and after.isascii() and after.isalnum()
        return " " if latin else ""
    return LINK_WITH_SPACES.sub(replace, text) if "[" in text else text


def tidy(text):
    """One readable line: no link numbers, footnote marks or struck-through words; table cells joined."""
    text = without_link_marks(NOTE_MARK.sub("", str(text)))
    text = STRUCK.sub("", STRUCK_LAST.sub("", text))
    text = SPAN_MARK.sub("", text)
    if text.strip().startswith("|"):
        cells = [cell.strip() for cell in text.strip().strip("|").split("|")]
        text = " — ".join(cell for cell in cells if cell)
    text = SPACES.sub(" ", text)
    for pattern, replacement in LEFTOVERS:
        text = pattern.sub(replacement, text)
    text = text.strip(" /")
    if re.fullmatch(r"-+", text):
        return ""
    text = re.sub(r"^(?:-\s+)+", "", text)
    return text.lstrip("、，,・/／:：；; ")


def clip(text, limit):
    """Whole sentences (else whole list items) up to about limit characters; '…' marks a cut."""
    if len(text) <= limit:
        return text
    cut = text[:limit]
    end = max(cut.rfind(mark) for mark in SENTENCE_END)
    if end >= limit // 3:
        return cut[:end + 1] + "…"
    comma = cut.rfind("、")
    return (cut[:comma] if comma >= limit // 2 else cut.rstrip()) + "…"


_HEADINGS = {}          # id(lines) -> (lines, headings) of the pages read last


def headings(lines):
    """[(index, level, text)] of the markdown-style heading lines (kept for the last pages asked)."""
    cached = _HEADINGS.get(id(lines))
    if cached is not None and cached[0] is lines:
        return cached[1]
    found = []
    for index, line in enumerate(lines):
        if line.startswith("#"):
            match = HEADING.match(line)
            if match:
                found.append((index, len(match.group(1)), LINK_MARK.sub("", match.group(2)).strip()))
    if len(_HEADINGS) >= 64:
        del _HEADINGS[next(iter(_HEADINGS))]
    _HEADINGS[id(lines)] = (lines, found)
    return found


def section(lines, words, *, skip_subheadings=True):
    """[(line number, text)] under the first heading that contains one of the words."""
    marks = headings(lines)
    for position, (index, level, text) in enumerate(marks):
        if any(word in text for word in words):
            end = next((other for other, other_level, _ in marks[position + 1:] if other_level <= level), len(lines))
            body = []
            for number in range(index + 1, end):
                line = lines[number]
                if HEADING.match(line):
                    if skip_subheadings:
                        continue
                    line = "【" + HEADING.match(line).group(2) + "】"
                if line.strip():
                    body.append((number + 1, line))
            return body
    return []


def readable_section(sources, item, *, lead_only=False):
    """(heading, rows) under the first heading with readable lines. sources are (Source, words) pairs;
    each word rank is tried in the digest before the main page, every heading with the word in page order.
    lead_only stops at the first subheading; under a parent heading (PARENT_WORDS) each row names its
    subsection and subsections about something else are left out."""
    ranked = [(source, words[rank]) for rank in range(max(len(words) for _, words in sources))
              for source, words in sources if source is not None and rank < len(words)]
    marks_of = {}
    for source, word in ranked:
        marks = marks_of.setdefault(id(source), headings(source.lines))
        for position, (index, level, title) in enumerate(marks):
            if word not in title:
                continue
            end = next((other for other, other_level, _ in marks[position + 1:]
                        if other_level <= level or lead_only), len(source.lines))
            rows, subsection, elsewhere = [], None, False
            for number in range(index + 1, end):
                line = source.lines[number]
                match = HEADING.match(line)
                if match:
                    subsection = LINK_MARK.sub("", match.group(2)).strip()
                    elsewhere = word in PARENT_WORDS and bool(ELSEWHERE.search(subsection))
                    continue
                text = tidy(line)
                if elsewhere or not text or is_navigation(text) or len(text) < 4:
                    continue
                row = {"text": clip(text, item), "source": source.ref(number + 1)}
                if word in PARENT_WORDS and subsection:
                    row = {"text": clip(f"【{subsection}】{text}", item), "source": row["source"],
                           "heading": subsection}
                rows.append(row)
            if rows:
                return title, rows
    return None, []


def first_heading(lines, words):
    """(index, level, text) of the first heading that contains one of the words, or None."""
    return next((mark for mark in headings(lines) if any(word in mark[2] for word in words)), None)


def section_rows(lines, words):
    """[(line number, text, heading level or 0)] under the first heading that contains one of the words."""
    marks = headings(lines)
    for position, (index, level, text) in enumerate(marks):
        if any(word in text for word in words):
            end = next((other for other, other_level, _ in marks[position + 1:] if other_level <= level), len(lines))
            rows = []
            for number in range(index + 1, end):
                match = HEADING.match(lines[number])
                if match:
                    rows.append((number + 1, LINK_MARK.sub("", match.group(2)).strip(), len(match.group(1))))
                elif lines[number].strip():
                    rows.append((number + 1, lines[number], 0))
            return rows
    return []


def is_video_title(line, links):
    """True for a line that is only the title of a linked video, perhaps with several time links
    (タイトル❶ [26] / ❷ [27]): every link goes to a video site, nothing follows the last one, and the
    text reads as a title (【…】, #shorts or a leading date; else the channel name and no 。)."""
    marks = list(LINK_NUMBER.finditer(line))
    if not marks or line[marks[-1].end():].strip():
        return False
    if not all(urlsplit(links.get(mark.group(1), "")).netloc.lower() in VIDEO_HOSTS for mark in marks):
        return False
    title = ENUMERATED_LINKS.sub(" ", LINK_MARK.sub("", line)).strip()
    return bool(TITLE_MARKS.search(title)) or ("。" not in title and bool(VIDEO_TITLE.search(title)))


def is_citation(text, links):
    """True for a footnote whose every part is a citation link (see CITATION_SITE)."""
    text = re.sub(r"[\s)）]+$", "", text.strip())
    for part in re.split(r"(?<=\])\s*[,，、]\s*", text):
        match = TRAILING_LINK.match(part)
        if not match or LINK_MARK.search(match.group(1)) or match.group(2) not in links:
            return False
        anchor, host = match.group(1).strip(), urlsplit(links[match.group(2)]).netloc.lower()
        if CITATION_SITE.search(anchor) or anchor in CITATION_WORDS or CITATION_LABEL.search(anchor):
            continue
        media = any(host == name or host.endswith("." + name) for name in MEDIA_HOSTS)
        if not (media and "。" not in anchor and VIDEO_TITLE.search(anchor)):
            return False
    return True


def entries(lines, *, under=None, links=None):
    """[(line number, phrase, note)] for '##### phrase' headings (optionally below a heading with under).
    With the page's links, the titles of the videos listed under an entry are counted, not joined to its
    explanation."""
    marks = headings(lines)
    start, stop = 0, len(lines)
    if under:
        chosen = next(((i, level) for i, level, text in marks if level < 5 and any(w in text for w in under)), None)
        if chosen is None:
            return []
        start = chosen[0]
        stop = next((i for i, level, _ in marks if i > start and level <= chosen[1]), len(lines))
    found = []
    for position, (index, level, text) in enumerate(marks):
        if level != 5 or not start <= index < stop:
            continue
        end = next((other for other, _, _ in marks[position + 1:]), len(lines))
        body = [line for line in lines[index + 1:min(end, stop)] if line.strip()]
        videos = sum(1 for line in body if links and is_video_title(line, links))
        note = " ".join(tidy(line) for line in body if not (links and is_video_title(line, links)))
        if videos:
            note = (note + " " if note else "") + f"（使用例の動画{videos}件のリンクあり）"
        found.append((index + 1, text, note))
    return found


def profile_table(lines):
    """{item: value} from the '| item | value |' rows of a page's 公式情報 table."""
    rows = section(lines, ("公式情報",))
    found = {}
    for _, line in rows:
        cells = [tidy(cell) for cell in line.strip().strip("|").split("|")]
        if len(cells) == 2 and cells[0] and cells[1] and cells[0] != cells[1]:
            found.setdefault(re.sub(r"\[(?:row|col)span=\d+\]\s*", "", cells[0]), cells[1])
    return found


def classify(text):
    """Reaction labels named in a note, ignoring its examples (例：…), which quote other words."""
    meaning = re.split(r"\s?例[：:「『]|\s例\s", text)[0]
    return [label for label, words in REACTIONS if any(word in meaning for word in words)]


def join_values(values):
    joined = ""
    for value in values:
        joined = value if not joined else joined + (" " if joined[-1] in SENTENCE_END else "、") + value
    return joined


def footnote_context(text):
    """Keep the phrase before a marker without splitting a parenthesized list."""
    closing = {"(": ")", "（": "）", "「": "」", "『": "』", "[": "]"}
    stack, start = [], 0
    for index, char in enumerate(text):
        if char in closing:
            stack.append(closing[char])
        elif stack and char == stack[-1]:
            stack.pop()
        elif not stack and char in "、，,。；;：:":
            start = index + 1
    return text[start:].strip()


def footnote_notes(source, references, display, limit):
    """Footnotes of the visible excerpt, from the same page; removed text cannot add notes.

    Keep the original wording (apart from link marks, whitespace and an explicit excerpt cut),
    the definition's line range, and the original phrase carrying the marker. Footnotes are metadata
    on the item or section note, never new preference items.
    """
    result, seen, cursor = [], set(), 0
    shown = clip(display, limit)
    kept = len(shown) - (1 if len(display) > limit else 0)
    for number, raw in references:
        clean = tidy(raw)
        offset = display.find(clean, cursor)
        if not clean or offset < 0:
            continue
        cursor = offset + len(clean)
        removed = [match.span() for match in STRUCK_WITH_NOTES.finditer(raw)]
        for marker in FOOTNOTE_MARK.finditer(raw):
            key = marker.group(1)
            if key in seen or any(first <= marker.start() < last for first, last in removed):
                continue
            if offset + len(tidy(raw[:marker.start()])) > kept:
                continue
            note = source.footnotes().get(key)
            if note is None:
                continue
            seen.add(key)
            context = footnote_context(raw[:marker.end()])
            result.append({"text": clip(without_link_marks(SPACES.sub(" ", note["text"]).strip()), limit),
                           "source": note["source"], "footnote": "*" + key,
                           "reference": source.ref(number), "reference_text": clip(context, limit)})
            if source.links and is_citation(note["text"], source.links):
                result[-1]["citation_only"] = True        # Markdown lists it by number only
    return result


def preference_items(source, words, limit, lists=None):
    """Likes or dislikes as items "term: value、value" with the lines they span (file:first-last).

    lists: {heading line: (term lines, definition lines)} of this page from definition_lists.json,
    the wiki's own definition lists aligned with the cached lines. A recorded section is grouped
    exactly as the wiki marks it: each term with its definitions, a term without definitions as an
    item of its own, other lines as items without a term. Other sections are grouped by guessed_groups.
    A note (a line after a term's definitions but outside them, or one marked ※/注釈:) goes with the
    item before it as "notes": [{"text", "source"}]; one before every item is returned first as
    {"kind": "note"}, a note on the whole section.
    """
    rows, written = [], {}
    for number, line, level in section_rows(source.lines, words):
        text = tidy(line)
        if text and not is_navigation(text):
            rows.append((number, text, level))
            written[number] = line
    heading = first_heading(source.lines, words)
    recorded = (lists or {}).get(heading[0] + 1) if heading else None
    exact = recorded is not None and recorded[0] == heading[2]
    groups = defined_groups(rows, *recorded[1:]) if exact else guessed_groups(rows)
    items = ([dict(note, label=None, kind="note") for note in
              footnote_notes(source, [(heading[0] + 1, heading[2])], tidy(heading[2]), limit)]
             if heading else [])
    for group in groups:
        first, last = group["first"], group["last"]
        notes = [{"text": clip(NOTE_START.sub("", text) or text, limit), "source": source.ref(number)}
                 for number, text in group["notes"]]
        for number, text in group["notes"]:
            raw_note = NOTE_START.sub("", written[number]) or written[number]
            notes.extend(footnote_notes(source, [(number, raw_note)], tidy(raw_note), limit))
        if group["values"]:
            value = join_values(group["values"])
            text, label = (f"{group['label']}: {value}", group["label"]) if group["label"] else (value, None)
        elif group["label"] and not group["heading"] and (exact or notes):
            text, label = group["label"], None          # a term listed without a definition (岩盤浴)
        else:
            items += [dict(note, label=None, kind="note") for note in notes]    # before every item
            continue
        item = {"text": clip(text, limit),
                "source": source.ref(first) if first == last else f"{source.relative}:{first}-{last}",
                "label": label}
        note_lines = {number for number, _ in group["notes"]}
        references = [(number, written[number]) for number, _, _ in rows
                      if first <= number <= last and number not in note_lines]
        notes.extend(footnote_notes(source, references, text, limit))
        if notes:
            item["notes"] = notes
        items.append(item)
    return items


def _group(number, label=None, heading=False):
    return {"label": label, "values": [], "notes": [], "first": number, "last": number, "heading": heading}


def _is_note(current, text):
    """Whether a line outside the list comments on the group before it: every such line after a term,
    and a marked one (※…, 注釈:…) after anything but a bare subheading, whose content it would be."""
    if current is None or current["heading"]:
        return bool(NOTE_START.match(text)) and (current is None or bool(current["values"]))
    return current["label"] is not None or bool(NOTE_START.match(text))


def _add_note(groups, number, text):
    """A note on the last group, or (before any group) on the whole section: a group of notes only."""
    if not groups:
        groups.append(_group(number))
    groups[-1]["notes"].append((number, text))


def _takes_loose_lines(group):
    """Loose lines join a subheading's group or a run of loose lines, not a group of notes only."""
    return (group["heading"] or group["label"] is None) and not (group["notes"] and not group["values"]
                                                                 and not group["heading"])


def defined_groups(rows, terms, definitions):
    """Groups as the wiki's definition list marks them. A subheading labels the loose lines under it. A
    loose line after a term (the wiki's paragraph after a definition) or one marked as a note is a note."""
    groups = []
    for number, text, level in rows:
        current = groups[-1] if groups else None
        if level or number in terms:
            groups.append(_group(number, text, bool(level)))
            continue
        loose = number not in definitions
        if loose and _is_note(current, text):
            _add_note(groups, number, text)
            continue
        attach = current is not None and (
            (not loose and current["label"] is not None and not current["heading"])
            or (loose and _takes_loose_lines(current)))
        if not attach:
            groups.append(_group(number))
        groups[-1]["values"].append(text)
        groups[-1]["last"] = number
    return groups


# Guessing a definition list (a section that definition_lists.json does not cover). Each line is a term
# (T), the first line of a definition (V), a later line of it (C) or a line outside any list (L);
# subheadings (H) are given. Line features score each role, the order of roles is constrained (a
# definition follows its term), and the best-scoring labelling wins (Viterbi). The weights were fitted
# to the recorded lists of 77 main pages: with weights fitted to one half of the people, 4.6 % and
# 5.8 % of the other half's items were grouped wrong (the rules of 1.2.1: 18 %). A line outside the
# list (L) after a term is a note on it. tools/evaluate_preferences.py --cross-validate recomputes all this.
GUESS_WEIGHTS = {
    "T": {"named": 4.0, "noun": 1.5, "list": -3.0, "sentence": -3.0, "colon": -2.5, "long": -2.5, "note": -3.0,
          "conj": -2.5, "predicate": -0.5, "clause": -0.2},
    "V": {"named": -1.0},
    # A later line of a definition is prose or a list (また…, ※…), rarely a bare short phrase.
    "C": {"bare": -2.5, "prose": -0.2, "note": 1.0},
    "L": {"base": -1.0},
}
GUESS_TRANSITIONS = {           # (previous role, role): score; missing pairs are not allowed
    (None, "T"): 0.0, (None, "L"): -0.3, (None, "H"): 0.0,
    ("H", "T"): 0.0, ("H", "L"): 0.0, ("H", "H"): 0.0,
    ("T", "V"): 0.0, ("T", "T"): -2.5, ("T", "H"): -2.0,
    ("V", "C"): -0.3, ("V", "T"): 0.0, ("V", "H"): 0.0, ("V", "L"): 0.0,
    ("C", "C"): 0.0, ("C", "T"): 0.0, ("C", "H"): 0.0, ("C", "L"): 0.0,
    ("L", "L"): -1.0, ("L", "T"): 0.0, ("L", "H"): 0.0,
}
CONTINUATION_START = ("また", "しかし", "特に", "ただし", "なお", "ちなみに", "さらに", "他にも", "但し", "曰く",
                      "本人曰く", "どちらも")
PREDICATE_END = re.compile(r"(ない|ている|てる|できる|られる|れる|する|した|だった|です|ます|だ|る|た|い|う|く|ず|ぬ)$")
PARENTHESES = re.compile(r"[（(][^（）()]*[）)]")


def line_features(text):
    """What a line looks like, read outside parentheses (好きな食べ物（調理、味付け） is a term)."""
    plain = PARENTHESES.sub("", text).strip() or text
    base = re.sub(r"\s*[（(].*$", "", text) or plain
    punctuated = bool(re.search(r"[。、，,：:！？!?]", plain))
    listed, sentence, colon = (bool(re.search(pattern, plain)) for pattern in (r"[、，,]", r"[。！？!?]", r"[：:]"))
    return {
        "named": (bool(TERM_START.match(plain)) or base.endswith(("なもの", "な物", "なこと", "なモノ")))
                 and not punctuated,
        "noun": base in TERM_NOUNS or plain in TERM_NOUNS,
        "list": listed,
        "sentence": sentence,
        "colon": colon,
        "long": len(text) > 30,
        "bare": len(text) <= 12 and not (listed or sentence or colon),
        "prose": listed or sentence or colon or len(text) > 30 or plain.startswith(CONTINUATION_START),
        "note": text.startswith(("※", "例", "注釈")),
        "conj": plain.startswith(CONTINUATION_START),
        "predicate": bool(PREDICATE_END.search(plain)) and not plain.endswith(("もの", "こと", "物")),
        "clause": bool(CLAUSE.search(plain)),
    }


def role_score(features, role):
    weights = GUESS_WEIGHTS[role]
    return weights.get("base", 0.0) + sum(weight for name, weight in weights.items() if features.get(name))


def guessed_groups(rows):
    """Groups for a section without a recorded definition list (see GUESS_WEIGHTS)."""
    if not rows:
        return []
    table = []                                   # per row: {role: (score, previous role)}
    for index, (_, text, level) in enumerate(rows):
        features = None if level else line_features(text)
        scores = {}
        for role in (("H",) if level else ("T", "V", "C", "L")):
            own = 0.0 if level else role_score(features, role)
            previous = table[index - 1] if index else {None: (0.0, None)}
            options = [(score + GUESS_TRANSITIONS[(before, role)] + own, before)
                       for before, (score, _) in previous.items() if (before, role) in GUESS_TRANSITIONS]
            if options:
                scores[role] = max(options, key=lambda option: option[0])
        table.append(scores)
    ending = {role: score - (1.5 if role == "T" else 0.0) for role, (score, _) in table[-1].items()}
    role = max(ending, key=ending.get)
    roles = [role]
    for index in range(len(rows) - 1, 0, -1):
        role = table[index][role][1]
        roles.append(role)
    groups = []
    for (number, text, _), role in zip(rows, reversed(roles)):
        current = groups[-1] if groups else None
        if role in ("H", "T"):
            groups.append(_group(number, text, role == "H"))
            continue
        if role == "L" and _is_note(current, text):
            _add_note(groups, number, text)
            continue
        if role == "L" and not (current is not None and _takes_loose_lines(current)):
            groups.append(_group(number))
        groups[-1]["values"].append(text)
        groups[-1]["last"] = number
    return groups


def definition_lists(cache, core, source):
    """{heading line: (heading, term lines, definition lines)} recorded for this main page, or {}."""
    match = re.match(r"^people/([^/]+)/pages/main\.txt$", source.relative)
    if not match:
        return {}
    pages = getattr(cache, "_story_definition_lists", None)
    if pages is None:
        path = cache.path("definition_lists.json")
        pages = {}
        if os.path.isfile(path):
            try:
                pages = core._json(path)["pages"]
            except (ValueError, KeyError, TypeError):
                pages = {}
        cache._story_definition_lists = pages
    page = pages.get(match.group(1) + "/main") or {}
    return {section["heading_line"]: (section["heading"], frozenset(section["terms"]), frozenset(section["values"]))
            for section in page.get("sections", ())}


def is_navigation(text):
    """Menus, breadcrumbs, and "see also" lines whose link the text does not keep (※こちら [146] も参照)."""
    return (text.startswith(("簡易プロフィール / 見た目 /", "詳細プロフィール / その他 /"))
            or bool(re.match(r"^Top\s*>|^※?\s*こちら\s*も参照$", text)))


def nickname_rows(lines):
    """Line numbers within nickname sections, including their empty roster rows."""
    excluded = set()
    marks = headings(lines)
    for position, (index, level, title) in enumerate(marks):
        if "呼称一覧" in title:
            end = next((i for i, depth, _ in marks[position + 1:] if depth <= level), len(lines))
            excluded.update(range(index + 1, end + 1))
    return excluded


# --- topics ------------------------------------------------------------------------

TOPIC_SPACES = re.compile(r"[\s\u3000]+")


def searched_topics(people, topics, core):
    """(topics as searched, notes). A topic is a phrase found in a line as it is, so "マネージャー オカン 推し"
    (several topics given as one) finds nothing: a topic with spaces that no line of the cast's pages
    holds is searched word by word, and a note says so. An empty topic would match every line: refused."""
    searched, notes = [], []
    for given in topics:
        topic = given.strip()
        if not topic:
            raise core.CacheError("空の話題（--topic）は、すべての行に一致するため使えません。話題の語を指定してください。")
        words = [word for word in TOPIC_SPACES.split(topic) if word]
        if len(words) > 1:
            folded = topic.casefold()
            if not any(folded in line.casefold() for person in people for page in person.text_pages()
                       for line in page.lines if not HEADING.match(line)):
                notes.append(f"「{topic}」はこの語句のままではどのページにも出てこないため、空白で分けた"
                             f"{len(words)}語（{'・'.join(words)}）で探した。複数の話題は --topic を語ごとに繰り返す。")
                searched.extend(words)
                continue
        searched.append(topic)
    return list(dict.fromkeys(searched)), notes


def definition_items(cache, core, source):
    """{line number: (first line, last line, "term: value、value")} over the items of the main page's
    recorded definition lists (definition_lists.json), so that a topic line that is a term (推し) or one of
    its values comes with the rest of its item."""
    items = {}
    marks = headings(source.lines)
    for heading_line, (_, terms, values) in definition_lists(cache, core, source).items():
        mark = next((mark for mark in marks if mark[0] == heading_line - 1), None)
        if mark is None:
            continue
        end = next((index for index, level, _ in marks if index > mark[0] and level <= mark[1]), len(source.lines))
        rows = []
        for number in range(mark[0] + 2, end + 1):
            line = source.lines[number - 1]
            match = HEADING.match(line)
            if match:
                rows.append((number, LINK_MARK.sub("", match.group(2)).strip(), len(match.group(1))))
            elif tidy(line) and not is_navigation(tidy(line)):
                rows.append((number, tidy(line), 0))
        for group in defined_groups(rows, terms, values):
            if group["label"] and group["values"] and not group["heading"]:
                item = (group["first"], group["last"], f"{group['label']}: {join_values(group['values'])}")
                for number in range(group["first"], group["last"] + 1):
                    items[number] = item
    return items


# --- one person -------------------------------------------------------------------

class Source:
    def __init__(self, relative, lines, links=None):
        self.relative, self.lines, self.links = relative, lines, links or {}

    def ref(self, number):
        return f"{self.relative}:{number}"

    def footnotes(self):
        """Cached footer definitions, including continuation lines and their exact source span."""
        if hasattr(self, "_footnotes"):
            return self._footnotes
        found, current = {}, None
        for number, line in enumerate(self.lines, 1):
            match = FOOTNOTE_DEFINITION.match(line)
            if match:
                current = {"first": number, "last": number, "parts": [match.group(2)]}
                found[match.group(1)] = current
            elif HEADING.match(line):
                current = None
            elif current is not None and line.strip():
                current["parts"].append(line)
                current["last"] = number
        self._footnotes = {
            key: {"text": "\n".join(note["parts"]).strip(),
                  "source": self.ref(note["first"]) if note["first"] == note["last"]
                  else f"{self.relative}:{note['first']}-{note['last']}"}
            for key, note in found.items() if any(part.strip() for part in note["parts"])}
        return self._footnotes


def text_page(person, page_id):
    """(Source, page) of a person's page with text, or (None, None)."""
    for entry in person.pages()["pages"]:
        if entry["id"] == page_id and entry["text"]:
            page = person.page(page_id)
            return Source(f"people/{person.slug}/pages/{entry['text']}", page.lines, page.links()), page
    return None, None


def person_sources(person):
    digest_text = person.digest()
    digest = (Source(f"people/{person.slug}/digest.md", digest_text.split("\n")) if digest_text else None)
    main, _ = text_page(person, "main")
    quotes, _ = text_page(person, "quotes")
    return digest, main, quotes


def shared_source(cache, page_id, core):
    try:
        page = cache.shared().page(page_id)
    except getattr(core, "CacheIntegrityError", ()):
        raise                    # a changed file is not a missing page
    except Exception:            # an older cache without that page
        return None
    return Source(f"shared/{page.entry['text']}", page.lines, page.links())


def person_memo(person):
    """What a person's sections share at every level (person.json, the pages read, the topic lines found), kept on
    the Person object, which a pack makes for itself: a large cast builds people at several levels."""
    memo = getattr(person, "_story_memo", None)
    if memo is None:
        memo = person._story_memo = {}
    return memo


def build_person(cache, person, detail, topics, core):
    memo = person_memo(person)
    if "info" not in memo:
        memo["info"] = person.info()
    info = memo["info"]
    entry = person.entry
    limits = DETAIL[detail]
    item = limits["item"]
    if "sources" not in memo:
        memo["sources"] = person_sources(person)
    digest, main, quotes = memo["sources"]
    official = dict(info.get("official") or {})
    if main is not None:
        for key, value in profile_table(main.lines).items():
            official.setdefault(key, value)
    identity = {key: tidy(official[key]) for key in IDENTITY_FIELDS if official.get(key)}
    listing = info.get("wiki_status")
    result = {"name": person.name, "slug": person.slug, "region": entry["region"], "generation": entry["generation"],
              "detail": detail, "wiki_listing": listing["label"] if listing else None,
              "identity": identity, "self_reference": info.get("self_reference_row"),
              "sections": {}, "omitted": {}, "missing": []}
    if not entry.get("pages_known"):
        result["note"] = "個人記事が未掲載の欠測記録。本文・人物像・話し方を推測で補わない。"
    elif not entry.get("pages_with_text"):
        result["note"] = "本文は未収録（URLのみ）。read --online で取得してから描写する。"

    def add(key, items, limit):
        result["sections"][key] = items[:limit]
        if len(items) > limit:
            result["omitted"][key] = len(items) - limit

    # Prefer the main table: digests can flatten the speaker/viewer subheadings.
    greeting_rows = []
    for source, words in ((main, ("あいさつ集", "あいさつ", "挨拶")), (digest, ("あいさつ",))):
        if source is None:
            continue
        role = "資料内で区別なし"
        for number, line in section(source.lines, words, skip_subheadings=False):
            if line.startswith("【"):
                role = tidy(line).strip("【】 ")
                continue
            if is_navigation(tidy(line)):
                continue
            if line.lstrip().startswith("|"):
                cells = [tidy(cell) for cell in line.strip().strip("|").split("|")]
                if len(cells) < 2 or not cells[1] or cells[1] in {"セリフ", "観客"}:
                    continue
            text = tidy(line)
            if not text or text.startswith(("場面 — セリフ", "場面 —")) or text in {"場面", "セリフ"}:
                continue
            table = line.lstrip().startswith("|")
            if not table and COLLECTION.search(re.sub(r"\s*[（(][^（）()]*[）)]$", "", text)):
                continue
            note = not table and (text.startswith("※") or not re.search(r"[「『\"]", text))
            greeting_rows.append((note, {"text": clip(text, item), "source": source.ref(number), "role": role}))
        if greeting_rows:
            break
    # Stable: table rows and quoted greetings keep their order, explanations follow them.
    greeting_rows = [row for _, row in sorted(greeting_rows, key=lambda pair: pair[0])]
    add("greetings", greeting_rows, limits["greetings"])
    if not greeting_rows:
        result["missing"].append("あいさつ")

    # Catchphrases: only the person's own 口癖 section or digest.
    phrases = []
    if quotes is not None:
        phrases = [{"phrase": tidy(phrase), "note": clip(note, item), "source": quotes.ref(number)}
                   for number, phrase, note in entries(quotes.lines, under=("口癖",), links=quotes.links)]
    if not phrases and digest is not None:
        for number, line in section(digest.lines, ("口癖",)):
            match = re.match(r"^- \*\*(.+?)\*\*\s*—\s*(.*)$", line)
            if match:
                phrases.append({"phrase": tidy(match.group(1)), "note": clip(tidy(match.group(2)), item),
                                "source": digest.ref(number)})
    add("catchphrases", phrases, limits["catchphrases"])

    # A shared glossary mark identifies an association, not necessarily a speaker.
    # E.g. Can I kill you? bears both Mumei's and the addressee Fauna's marks.
    related = []
    mark = identity.get("推しマーク")
    if mark and entry["region"] in {"EN", "ID"}:
        shared = shared_source(cache, "en_quotes" if entry["region"] == "EN" else "id_quotes", core)
        if shared is not None:
            for number, phrase, note in entries(shared.lines, links=shared.links):
                # The unqualified paw mark is FUWAMOCO's joint mark.
                joint = mark in {"🐾🩵", "🐾🩷"} and "🐾" in phrase and not any(
                    individual in phrase for individual in ("🐾🩵", "🐾🩷"))
                if mark in phrase or joint:
                    related.append({"phrase": tidy(phrase), "note": clip(note, item),
                                    "source": shared.ref(number), "speaker_attribution": "unverified"})
    add("related_quotes", related, limits["catchphrases"])
    if not phrases:
        status = "個人資料の口癖節から抽出なし"
        if quotes is None and any(page["id"] == "quotes" for page in person.pages()["pages"]):
            name = json.dumps(person.name, ensure_ascii=False)
            status += f"（語録ページは本文未収録: read {name} 語録 --section 口癖 --all --online で取得・HTTP）"
        result["catchphrase_status"] = status + ("／関連語録は要確認" if related else "")

    # Personality and related sections: digest (JP45), else the main page.
    personality_lines = []
    for key, label, digest_words, main_words in SECTIONS:
        rows = []
        if key in {"likes", "dislikes"}:
            # The digest keeps only the first lines of a section: likes and dislikes read the main page.
            for source, words in ((main, main_words), (digest, digest_words)):
                rows = (preference_items(source, words, item, definition_lists(cache, core, source))
                        if source is not None else [])
                if rows:
                    break
            notes = [{key: value for key, value in row.items() if key not in {"kind", "label"}}
                     for row in rows if row.get("kind") == "note"]
            rows = [row for row in rows if row.get("kind") != "note"]
            if notes and rows:              # notes on the whole section: not counted as items
                result.setdefault("section_notes", {})[key] = notes
        else:
            _, rows = readable_section(((digest, digest_words), (main, main_words)), item)
            if not rows and key in FALLBACK:
                digest_fallback, main_fallback = FALLBACK[key]
                heading, rows = readable_section(((digest, digest_fallback), (main, main_fallback)), item,
                                                 lead_only=True)
                if rows:
                    result.setdefault("fallback_headings", {})[key] = heading
        add(key, rows, limits[key])
        if key == "personality":
            personality_lines = rows
        if not rows:
            result["missing"].append(label)

    # Reaction cues: catchphrases whose note names a situation, then personality lines.
    cues, used = [], {}
    for phrase in phrases:
        for label in classify(phrase["note"]):
            if used.get(label, 0) < limits["per_reaction"]:
                cues.append({"keyword_group": label, "attribution": "unverified", "text": f"「{phrase['phrase']}」— {phrase['note']}",
                             "source": phrase["source"]})
                used[label] = used.get(label, 0) + 1
                break
    for row in personality_lines:
        for label in classify(row["text"]):
            if used.get(label, 0) < limits["per_reaction"]:
                cues.append({"keyword_group": label, "attribution": "unverified", "text": row["text"], "source": row["source"]})
                used[label] = used.get(label, 0) + 1
                break
    order = {label: position for position, (label, _) in enumerate(REACTIONS)}
    cues.sort(key=lambda cue: order[cue["keyword_group"]])
    add("reactions", cues, limits["reactions"])

    # Topic lines from every text page (digest excluded: it repeats the pages). A line of a definition
    # list on the main page comes as its whole item ("推し: あくたん、ねねち…", not "推し" alone).
    if topics:
        if ("topics", tuple(topics)) not in memo:
            memo["topics", tuple(topics)] = topic_lines(cache, person, topics, core)
        add("topic", [{"text": clip(text, item), "source": source, "page": page}
                      for text, source, page in memo["topics", tuple(topics)]], limits["topic"])
    return result


def topic_lines(cache, person, topics, core):
    """[(text, source, page id)] of every line of the person's text pages with one of the topics, in the
    order shown (the main page first, list pages last), not yet clipped."""
    hits = []
    folded_topics = [topic.casefold() for topic in topics]
    for page in person.text_pages():
        source = Source(f"people/{person.slug}/pages/{page.entry['text']}", page.lines)
        items = definition_items(cache, core, source) if page.entry["id"] == "main" else {}
        shown = set()
        for number, line in enumerate(page.lines, 1):
            folded_line = line.casefold()
            if not any(topic in folded_line for topic in folded_topics) or HEADING.match(line):
                continue
            if number in items:
                first, last, text = items[number]
                if first not in shown:
                    shown.add(first)
                    hits.append((text, f"{source.relative}:{first}-{last}", page.entry["id"]))
                continue
            text = tidy(line)
            if len(text) >= 2 and not is_navigation(text):
                hits.append((text, source.ref(number), page.entry["id"]))
    hits.sort(key=lambda hit: (bool(LIST_PAGES.match(hit[2])), hit[2] != "main"))
    return hits


# --- pairs --------------------------------------------------------------------------

def split_cell(cell):
    """(current names, struck-through names) of a nickname cell."""
    def names(text):
        return [part.strip() for part in re.split(r"[、,，/／]", text) if part.strip()]
    struck = [name for part in re.findall(r"~~(.*?)~~", cell or "") for name in names(tidy(part))]
    return names(STRUCK.sub("", cell or "")), struck


def calls(tables, speaker, target):
    """How speaker calls target: from the speaker's table and from the target's table."""
    own = [r for r in tables[speaker.slug]["records"] if r.get("counterpart_slug") == target.slug]
    other = [r for r in tables[target.slug]["records"] if r.get("counterpart_slug") == speaker.slug]
    result = {}
    for key, rows, field in (("speaker_table", own, "calls"), ("target_table", other, "called_by")):
        names, struck = [], []
        for row in rows:
            current, gone = split_cell(row.get(field) or "")
            names += current
            struck += gone
        result[key] = {"names": list(dict.fromkeys(names)), "struck": list(dict.fromkeys(struck))}
    return result


def terms_for(cache, names_module, target, speaker_calls):
    """Words that point at target in someone else's pages.

    A two-letter hiragana nickname (すい, にこ, ちは) is too common a syllable pair to find a person
    by; the end of the official name (ねね, そら, みこ) is kept.
    """
    entry = target.entry
    words = [entry["name"], *(entry.get("aliases") or []), *(entry.get("readings") or []), *speaker_calls]
    if entry["region"] != "JP":
        words += [part for part in entry["name"].split() if len(part) >= 4]
    generic = names_module.GENERIC
    kept = []
    for word in words:
        word = re.sub(r"[（(][^）)]*[）)]", "", word).strip()
        if len(word) == 2 and HIRAGANA_WORD.match(word) and not entry["name"].endswith(word):
            continue
        if len(word) >= 2 and names_module.fold(word) not in generic and word not in kept:
            kept.append(word)
    return sorted(kept, key=len, reverse=True)


def names_in(line, words):
    """Does the line name one of the words? A short hiragana name needs a particle, an honorific or
    no hiragana after it (NAME_FOLLOWERS); a Latin name is not inside a longer word (Gurarium), though
    it may follow another name in camel case (SameMori)."""
    for word in words:
        if word not in line:
            continue
        hiragana, latin = bool(HIRAGANA_WORD.match(word)), word.isascii()
        if not (hiragana or latin):
            return True
        start = line.find(word)
        while start >= 0:
            before, after = line[start - 1:start] if start else "", line[start + len(word):]
            if hiragana and (not after or not "ぁ" <= after[0] <= "ゖ" or after.startswith(NAME_FOLLOWERS)):
                return True
            joined = before.isascii() and before.isalpha() and not (before.islower() and word[:1].isupper())
            if latin and not joined and not (after[:1].isascii() and after[:1].islower()):
                return True                  # SameMori (two names joined) counts; Gurarium does not
            start = line.find(word, start + 1)
    return False


class PageText:
    """A page's lines as one string, so a word's lines are found by str.find instead of line by line."""

    def __init__(self, lines):
        self.text = "\n".join(lines)
        self.starts = [0]
        for line in lines[:-1]:
            self.starts.append(self.starts[-1] + len(line) + 1)

    def numbers_with(self, words):
        """Sorted 1-based numbers of the lines that contain one of the words."""
        import bisect
        found = set()
        for word in words:
            start = self.text.find(word)
            while start >= 0:
                number = bisect.bisect_right(self.starts, start)
                found.add(number)
                start = self.text.find(word, self.starts[number] if number < len(self.starts) else len(self.text))
        return sorted(found)


def combo_row(line):
    """(size, "name（size人: members） — note", cells) of a row of the combination page's tables, or None."""
    if not line.startswith("|"):
        return None
    cells = [tidy(cell) for cell in line.strip().strip("|").split("|")]
    if len(cells) < 3 or not cells[0].isdigit():
        return None
    size = int(cells[0])
    text = f"{cells[1]}（{size}人: {cells[2]}）" + (f" — {cells[3]}" if len(cells) > 3 and cells[3]
                                                 and cells[3] != "編集" else "")
    return size, text, cells


def pair_material(cache, people, core):
    """For each pair, what build_pairs shows of it at any level: the calls both ways, every combination name
    they share and every mention candidate (in the order shown, not yet clipped), and the counts of the list
    pages. The mention scan reads every text page of the cast, so a pack builds this once for all levels."""
    names_module = core._module("hololive_names")
    tables = {person.slug: person.nicknames() for person in people}
    combos = shared_source(cache, "combos_units", core)
    texts = {person.slug: [(Source(f"people/{person.slug}/pages/{page.entry['text']}", page.lines), page.entry["id"],
                            page.entry.get("label") or page.entry["id"], nickname_rows(page.lines), PageText(page.lines))
                           for page in person.text_pages() if page.entry["id"] != "nicknames_page"]
             for person in people}
    own_words = {person.slug: terms_for(cache, names_module, person, []) for person in people}
    material = []
    for index, first in enumerate(people):
        for second in people[index + 1:]:
            spoken = {(first.slug, second.slug): calls(tables, first, second),
                      (second.slug, first.slug): calls(tables, second, first)}
            pair = {"people": [first.name, second.name],
                    "calls": {f"{first.name}→{second.name}": spoken[first.slug, second.slug],
                              f"{second.name}→{first.name}": spoken[second.slug, first.slug]},
                    "combos": None, "mentions": [], "list_mentions": {}}
            if combos is not None:
                found = []
                for number, line in enumerate(combos.lines, 1):
                    if first.name in line and second.name in line:
                        row = combo_row(line)
                        if row:
                            found.append((row[0], row[1], combos.ref(number)))
                found.sort(key=lambda pair_item: pair_item[0])
                pair["combos"] = found
            mentions = []
            for speaker, target in ((first, second), (second, first)):
                words = terms_for(cache, names_module, target, spoken[speaker.slug, target.slug]["speaker_table"]["names"])
                listed = {}
                for source, page_id, label, excluded, page_text in texts[speaker.slug]:
                    for number in page_text.numbers_with(words):
                        line = source.lines[number - 1]
                        if number in excluded or HEADING.match(line) or not names_in(line, words):
                            continue
                        maybe_navigation = "プロフィール" in line or "Top" in line
                        if LIST_PAGES.match(page_id):            # only counted: no need to tidy every title
                            if not (maybe_navigation and is_navigation(tidy(line))):
                                listed[label] = listed.get(label, 0) + 1
                            continue
                        text = tidy(line)
                        if maybe_navigation and is_navigation(text):
                            continue
                        if len(text) < 12 or text in words:
                            continue
                        both = names_in(line, own_words[speaker.slug])
                        prose = not (line.lstrip().startswith("|") or re.match(r"^\d{4}/\d{1,2}/\d{1,2}", text))
                        mentions.append((0 if prose else 1, 0 if page_id == "episodes" else 1 if page_id == "main" else 2,
                                         0 if both else 1, len(text),
                                         (text, source.ref(number), f"{speaker.name}の資料で{target.name}に触れた行")))
                if listed:
                    pair["list_mentions"][speaker.name] = listed
            mentions.sort(key=lambda value: value[:4])
            pair["mentions"] = [value[4] for value in mentions]
            material.append(pair)
    return material


def build_pairs(cache, people, detail, core, material=None):
    """The pairs at a level of DETAIL (not names): pair_material, clipped and capped by the level."""
    limits = DETAIL[detail]
    item = limits["item"]
    pairs = []
    for found in material if material is not None else pair_material(cache, people, core):
        pair = {"people": found["people"], "calls": found["calls"],
                "combos": [], "mentions": [], "list_mentions": {}, "omitted": {}}
        if found["combos"] is not None:
            pair["combos"] = [{"text": clip(text, item), "source": source}
                              for _, text, source in found["combos"][:limits["combos"]]]
            if len(found["combos"]) > limits["combos"]:
                pair["omitted"]["combos"] = len(found["combos"]) - limits["combos"]
        pair["list_mentions"] = found["list_mentions"]
        pair["mentions"] = [{"text": clip(text, item), "source": source, "about": about}
                            for text, source, about in found["mentions"][:limits["mentions"]]]
        if len(found["mentions"]) > limits["mentions"]:
            pair["omitted"]["mentions"] = len(found["mentions"]) - limits["mentions"]
        pairs.append(pair)
    return pairs


def build_names(people, tables):
    """The names level's table: for each speaker, how they call each of the others ({name: [names]}, in the
    cast's order), from both people's tables (the speaker's 呼び方, then the other one's 呼ばれ方 not already
    there; struck-through names left out), and how many of the others neither table records."""
    rows = []
    for speaker in people:
        row = {"speaker": speaker.name, "calls": {}, "not_recorded": 0}
        for target in people:
            if target.slug == speaker.slug:
                continue
            value = calls(tables, speaker, target)
            names = list(dict.fromkeys(value["speaker_table"]["names"] + value["target_table"]["names"]))
            if names:
                row["calls"][target.name] = names
            else:
                row["not_recorded"] += 1
        rows.append(row)
    return rows


def member_words(entries):
    """[(word, slug)] of the catalog's names, aliases and readings (two characters or more), the longest first."""
    return sorted(((word, entry["slug"]) for entry in entries
                   for word in [entry["name"], *(entry.get("aliases") or []), *(entry.get("readings") or [])]
                   if len(word) >= 2), key=lambda pair: -len(pair[0]))


def combo_members(members, words, cast):
    """The slugs of everyone the members cell of a combination row names, or None when a part of it names nobody of
    the catalog (👓友人A) or someone not in the cast. A part is read whole: it can name two people where the wiki
    lacks a comma (👾常闇トワ🛸💜ラプラス・ダークネス). words: member_words of the whole catalog, each stretch of
    the text matched once, the longest word first (🌸さくらみこ, 💀森カリオペ)."""
    found = []
    for part in (part.strip() for part in re.split(r"[,，、]", members)):
        if not part:
            continue
        named = []
        for word, slug in words:
            if word in part:
                part = part.replace(word, "\0")
                if slug not in named:
                    named.append(slug)
        if not named or any(slug not in cast or slug in found for slug in named):
            return None
        found += named
    return found


def build_cast_combos(cache, people, named, core):
    """The names level's combination names: the rows of the combination page whose members (two or more) are all
    in the cast, as many as the row's size says (a row that lists fewer cannot show that its other members are
    there); those with more of the people named first (the central characters) first, then the larger ones, then
    in the page's order; at most PAIR_NAMES["combos"], the rest counted."""
    combos = shared_source(cache, "combos_units", core)
    if combos is None:
        return None
    central = {person.slug for person in people[:named]}
    words, cast = member_words(cache.people), {person.slug for person in people}
    found = []
    for number, line in enumerate(combos.lines, 1):
        row = combo_row(line)
        if not row:
            continue
        members = combo_members(row[2][2], words, cast)
        if not members or len(members) < 2 or len(members) != row[0]:
            continue
        found.append((-len(central.intersection(members)), -len(members), number,
                      {"text": clip(row[1], PAIR_NAMES["item"]), "source": combos.ref(number)}))
    found.sort(key=lambda value: value[:3])
    limit = PAIR_NAMES["combos"]
    return {"items": [value[3] for value in found[:limit]], "omitted": max(0, len(found) - limit)}


# --- rendering -----------------------------------------------------------------------

def render_notes(notes, indent):
    """Markdown lines for notes; the footnotes that only cite a video, a post or a site share one line."""
    citations = sorted((note["footnote"] for note in notes if note.get("citation_only")),
                       key=lambda mark: int(mark.lstrip("*")) if mark.lstrip("*").isdigit() else 0)
    lines = [indent + render_note(note) for note in notes if not note.get("citation_only")]
    if citations:
        lines.append(indent + "出典を示すだけの脚注（動画・投稿などへのリンク）: " + "、".join(citations))
    return lines


def render_note(note):
    label = "注記"
    if note.get("footnote"):
        label += f"（脚注{note['footnote']}・原文「{note['reference_text']}」）"
    return f"{label}: {note['text']}（{note['source']}）"


def detail_label(pack):
    """'normal'; 'each person full, pairs brief' when the two differ; the people above the rest by name
    ('各人 normal（うち full: A、B）・組み合わせ brief')."""
    base, pair_level = pack["detail"], pack.get("pair_detail")
    raised = {}
    for person in pack["people"]:
        if person.get("detail", base) != base:
            raised.setdefault(person["detail"], []).append(person["name"])
    if not raised and (not pair_level or pair_level == base):
        return base
    label = f"各人 {base}"
    if raised:
        label += "（うち " + "／".join(f"{level}: {'、'.join(raised[level])}" for level in DETAIL_ORDER
                                     if level in raised) + "）"
    return label + (f"・組み合わせ {pair_level}" if pair_level else "")


TITLE_NAMES = 15        # a longer cast is named in the title by its first names and a count


def cast_lines(pack):
    """The header's lines on how the cast was put together (--group), or none."""
    cast = pack.get("cast")
    if not cast:
        return []
    parts = [f"名前で指定 {cast['named']}人"] if cast["named"] else []
    parts += [f"--group {group['name']} {group['added']}人" for group in cast["groups"]]
    members = "卒業・活動終了したメンバーも含む" if cast["include_former"] else "wikiトップの在籍メンバー欄の人"
    lines = ["＋".join(parts) + f"＝計{len(pack['people'])}人（グループは{members}。名前の後に、wikiトップの"
             "メンバー一覧の順で加えた）"]
    if cast["excluded"]:
        lines.append("--exclude で除いた: " + "、".join(cast["excluded"]))
    return lines + list(cast["notes"])


def large_cast_notes(pack):
    """The header's notes on the levels below brief (what a large cast gets within the limit)."""
    notes = []
    levels = [person["detail"] for person in pack["people"]]
    if "cameo" in levels:
        who = "全員" if set(levels) == {"cameo"} else "詳細度 cameo の人"
        notes.append(f"各人: {who}の資料は短い（あいさつ・口癖・人物像の数行）。台詞の多い中心人物は、その人たちだけの "
                     "story を別に実行して詳しい資料を読む。")
    if pack.get("pair_detail") == "names":
        notes.append("組み合わせ: 呼び方の一覧と、全員がこの顔ぶれにいるコンビ・ユニット名だけ（二人の間の言及の候補は "
                     "find 名前 相手 で探せる）。")
    return notes


def render_names(pack):
    """The names level: one line per speaker, then the cast's combination names."""
    out = ["## 相互の呼び方（話し手ごと）", "",
           "各行は「話し手 → 相手: 呼び方／相手: 呼び方…」。呼び方は両者の呼称表（話し手の表の呼び方と、相手の表の"
           "呼ばれ方）を合わせたもので、取り消し線付きの呼び方は除いた。どちらの表にも記載のない相手は人数だけ示す"
           "（記載がないだけで、呼び方や交流が無いことを意味しない）。表の詳細は nicknames 話し手 --query 相手。", ""]
    for row in pack["names"]:
        text = "／".join(f"{target}: {'、'.join(names)}" for target, names in row["calls"].items()) or "—"
        if row["not_recorded"]:
            text += f"（記載なし {row['not_recorded']}人）"
        out.append(f"- {row['speaker']} → {text}")
    out.append("")
    combos = pack.get("cast_combos")
    if combos and (combos["items"] or combos["omitted"]):
        out += ["## コンビ・ユニット名（この顔ぶれの全員が入るもの）", "",
                "wikiのコンビ・ユニット名一覧のうち、メンバー全員がこの顔ぶれにいるもの。名前で指定した人を多く含むもの、"
                "人数の多いものから。共演や親密さの根拠として使う前に本文を確認する。", ""]
        out += [f"- {combo['text']}（{combo['source']}）" for combo in combos["items"]]
        if combos["omitted"]:
            out.append(f"- ほかに {combos['omitted']}件（read shared combos_units --find 名前 で探せる）")
        out.append("")
    return out


# A pair's block in render_md(skeleton=True), standing for its lines (a combination name, a mention, a list
# page's count or the line saying there is none): shorter than any of them, so the text is never longer than
# the pack's.
SKELETON_LINE = "-" * 21


def render_pairs(pairs, skeleton=False):
    """The Markdown lines of the pairs at a level of DETAIL: the calls both ways, then each pair's
    combination names and mention candidates (skeleton: each block as its heading and SKELETON_LINE)."""
    out = ["## 相互の呼び方", ""]
    for pair in pairs:
        for direction, value in pair["calls"].items():
            own, other = value["speaker_table"], value["target_table"]
            speaker, target = direction.split("→")
            text = "、".join(own["names"]) or "—"
            if other["names"] != own["names"]:
                text += f"（{target}側の表: {'、'.join(other['names']) or '—'}）"
            for side, value_struck in ((speaker, own["struck"]), (target, other["struck"])):
                if value_struck:
                    text += f"［{side}側の表で取り消し線付き（現行扱いしない）: {'、'.join(value_struck)}］"
            out.append(f"- {direction}: {text}")
    out += ["", "空欄（—）は資料に記載がないだけで、呼び方や交流が無いことを意味しない。", ""]
    out += ["## 組み合わせ・相手への言及", "", "名前の一致による候補。共演や親密さの根拠として使う前に本文を確認する。", ""]
    for pair in pairs:
        out.append(f"### {pair['people'][0]} × {pair['people'][1]}")
        if skeleton:
            out += [SKELETON_LINE, ""]
            continue
        for combo in pair["combos"]:
            out.append(f"- コンビ・ユニット名: {combo['text']}（{combo['source']}）")
        for mention in pair["mentions"]:
            out.append(f"- {mention['text']}（{mention['source']}）")
        for speaker, listed in pair["list_mentions"].items():
            counts = "、".join(f"{page} {count}行" for page, count in sorted(listed.items()))
            out.append(f"- {speaker}の一覧ページで相手の名前が出る行: {counts}（名前の一致件数）")
        if not (pair["combos"] or pair["mentions"] or pair["list_mentions"]):
            out.append("- 収録ページでは本文の言及候補が見つからない（未収録ページ・他の呼び名の可能性あり）")
        if pair["omitted"]:
            out.append("- ほかに " + "、".join(f"{OMITTED_LABELS.get(key, key)} {count}件"
                                               for key, count in pair["omitted"].items())
                       + f"（find {json.dumps(pair['people'][0], ensure_ascii=False)} "
                         f"{json.dumps(pair['people'][1], ensure_ascii=False)} で探せる）")
        out.append("")
    return out


def render_person(person, topics, mixed):
    """The Markdown lines of one person's section; mixed: the people are at different levels (each heading
    names the level)."""
    labels = {key: label for key, label, _, _ in SECTIONS}
    level = f"・詳細度 {person['detail']}" if mixed else ""
    out = [f"## {person['name']}（{person['region']} / {person['generation']}{level}）", ""]
    if person["wiki_listing"]:
        out.append(f"- {person['wiki_listing']}（公式未照合。物語では会話の前提を優先）")
    if person["identity"]:
        out.append("- " + " / ".join(f"{key}: {value}" for key, value in person["identity"].items()))
    if person.get("note"):
        out.append("- 注意: " + person["note"])
    out.append("- 一人称・自称（呼称表の本人行）: " + (person["self_reference"] or "記載なし"))
    sections = person["sections"]
    if sections.get("greetings"):
        out += ["", "### あいさつ"] + [f"- 【{row['role']}】{row['text']}（{row['source']}）" for row in sections["greetings"]]
    if sections.get("catchphrases"):
        out += ["", "### 口癖"] + [f"- {row['phrase']} — {row['note']}（{row['source']}）"
                                   for row in sections["catchphrases"]]
    if person.get("catchphrase_status"):
        out += ["", "- " + person["catchphrase_status"]]
    if sections.get("related_quotes"):
        out += ["", "### 関連語録の候補（発話者・口癖かどうかは未確認）",
                "推しマークの一致で抽出。相手の発言や視聴者の言葉、単発の発言も含む。"]
        out += [f"- {row['phrase']} — {row['note']}（{row['source']}）" for row in sections["related_quotes"]]
    for key, _, _, _ in SECTIONS:
        if sections.get(key):
            heading = person.get("fallback_headings", {}).get(key)
            title = labels[key] + (f"（見出し「{heading}」の冒頭から）" if heading else "")
            out += ["", f"### {title}"]
            section_notes = person.get("section_notes", {}).get(key, ())
            out += [f"- 注記（この節全体）: {note['text']}（{note['source']}）"
                    if not note.get("footnote") else "- この節全体の" + render_note(note)
                    for note in section_notes if not note.get("citation_only")]
            out += [line.replace("- 出典を示すだけの脚注", "- この節全体の出典を示すだけの脚注")
                    for line in render_notes([note for note in section_notes if note.get("citation_only")], "- ")]
            for row in sections[key]:
                out.append(f"- {row['text']}（{row['source']}）")
                out += render_notes(row.get("notes", ()), "  - ")
    if sections.get("reactions"):
        out += ["", "### 反応場面の検索候補（語句一致・本人の反応とは未確認）"] + [f"- 関連語「{row['keyword_group']}」: {row['text']}（{row['source']}）"
                                          for row in sections["reactions"]]
    if "topic" in sections:
        out += ["", f"### 話題「{'・'.join(topics)}」"]
        out += [f"- {row['text']}（{row['source']}）" for row in sections["topic"]] or ["- 該当する行なし"]
    notes = []
    if person["omitted"]:
        notes.append("省略: " + "、".join(f"{OMITTED_LABELS.get(key, key)} {count}件"
                                        for key, count in person["omitted"].items()))
    if person["missing"]:
        notes.append("収録資料に見当たらない: " + "、".join(person["missing"]))
    if notes:
        out += ["", "- " + " ／ ".join(notes)]
    out.append("")
    return out


def render_md(pack, skeleton=False):
    """The pack as Markdown. skeleton: each pair's block as its heading and SKELETON_LINE (lower_bound)."""
    people = [person["name"] for person in pack["people"]]
    title = " × ".join(people) if len(people) <= TITLE_NAMES else " × ".join(people[:5]) + f" ほか{len(people) - 5}人"
    out = [f"# 物語用資料パック: {title}", "",
           "> " + pack["rules"], f"> 資料の時点: {pack['snapshot']}（詳細度: {detail_label(pack)}）"]
    out += ["> 話題: " + note for note in pack.get("topic_notes", ())]
    out += ["> 顔ぶれ: " + line for line in cast_lines(pack)]
    out += ["> " + note for note in large_cast_notes(pack)] + [""]
    if pack.get("names"):
        out += render_names(pack)
    if pack["pairs"]:
        out += render_pairs(pack["pairs"], skeleton)
    mixed = len({person.get("detail") for person in pack["people"]}) > 1
    for person in pack["people"]:
        out += render_person(person, pack["topics"], mixed)
    out += ["## さらに読む", ""] + [f"- `{command}`" for command in pack["next"]]
    if pack.get("next_note"):
        out.append("- " + pack["next_note"])
    return "\n".join(out + [""])


CITED = re.compile(r"((?:people|shared)/[^:]+):\d+(?:-\d+)?")


def date_sources(cache, people):
    """What saved_dates reads beside the pack, read once for a pack: each page's fetch time; for a JP45 digest and
    profile table, the fetch times of the pages they were made from (person.json digest_source and
    official_source), or the original cache's days where its files were kept."""
    original = [stamp for stamp in cache.catalog.get("source", {}).get("snapshot_fetched_at") or [] if stamp]
    fetched, official = {}, {}
    for person in people:
        for entry in person.pages()["pages"]:
            if entry.get("text"):
                fetched[f"people/{person.slug}/pages/{entry['text']}"] = [entry.get("fetched_at")]
    for entry in cache.shared().data["pages"]:
        if entry.get("text"):
            fetched[f"shared/{entry['text']}"] = [entry.get("fetched_at")]
    for person in people:
        memo = person_memo(person)
        if "info" not in memo:
            memo["info"] = person.info()
        info = memo["info"]
        made_from = (info.get("digest_source") or {}).get("fetched_at")
        if made_from:
            fetched[f"people/{person.slug}/digest.md"] = list(made_from)
        source = info.get("official_source")
        official[person.slug] = [source.get("fetched_at")] if source else original if info.get("official") else []
    return {"original": original, "fetched": fetched, "official": official, "cited": {}}


def saved_dates(cache, people, pack, sources=None):
    """The days the wiki text behind a pack was saved: those of the pages it cites (date_sources), and those of
    the profile tables behind the identity lines it shows. Empty when the pack cites nothing. sources: from
    date_sources, kept with what each part of the pack cites (a pack is measured at many levels)."""
    sources = sources or date_sources(cache, people)
    fetched, original, cited = sources["fetched"], sources["original"], sources["cited"]

    def walk(value, stamps):
        if isinstance(value, dict):
            for item in value.values():
                walk(item, stamps)
        elif isinstance(value, list):
            for item in value:
                walk(item, stamps)
        elif isinstance(value, str):
            match = CITED.fullmatch(value)
            if match:
                stamps.update(fetched.get(match.group(1)) or original)

    def stamps_of(value):
        """The stamps one part cites, kept with the part itself (so its id is never taken by another)."""
        known = cited.get(id(value))
        if known is None or known[0] is not value:
            known = cited[id(value)] = (value, set())
            walk(value, known[1])
        return known[1]
    stamps = set()
    for part in [*pack["people"], pack["pairs"], pack.get("cast_combos")]:
        stamps.update(stamps_of(part))
    for person, built in zip(people, pack["people"]):
        if built["identity"]:
            stamps.update(sources["official"][person.slug])
    return sorted({stamp[:10] for stamp in stamps if stamp})


# The detail levels tried, most detailed first: each person's own section before the pairs' mention
# candidates (the mutual names are given in full at every level). Room left after the first step that fits
# raises single people's sections (build_pack), up to ace. The last two steps (2026-10-09) are for a large
# cast: the pairs' calls only (names), then each person at cameo; any cast of the catalog fits there.
LADDER = (("ace", "ace"), ("full", "full"), ("full", "normal"), ("full", "brief"), ("normal", "normal"),
          ("normal", "brief"), ("brief", "brief"), ("brief", "names"), ("cameo", "names"))
# What lower_bound takes off for the saved dates: a skeleton cites fewer pages than the pack, and one that cites
# nothing names the whole cache's days in its header.
BOUND_MARGIN = 64


# The automatic limit for any cast (2026-10-06): about what reading 15 people's pack takes.
MAX_BUDGET = 200000


def default_budget(count):
    """The default limit for a cast of count people, in Markdown characters: 80,000 for the first person
    and 10,000 for each other one, at most MAX_BUDGET (200,000 from 13 people on). One person at ace takes at
    most about 50,000, so one person is always ace and small casts get full or ace; large ones share 200,000."""
    return min(80000 + 10000 * (count - 1), MAX_BUDGET)


def build_pack(cache, names, *, topics=(), detail=None, budget=None, core=None, output_format="md",
               automatic_budget=False, named=None, cast=None):
    """(pack, markdown). Without detail, the most detailed step of LADDER within the budget; then, while the
    budget allows, each person's own section one level more detailed, in the order the names were given
    (everyone one level up before anyone a second). With detail, nothing above that level. budget limits
    the length of the output (JSON with its indentation), or with automatic_budget that of the Markdown
    text whatever the format; when even the briefest step does not fit, CacheError. named: how many of the
    names were named as such (the central characters; the rest came from --group), all when None; cast: how
    the cast was put together (--group), shown in the pack. A step whose output cannot fit (lower_bound) is
    passed without building its pairs, so a large cast is never scanned for mentions it has no room for."""
    measure = "md" if automatic_budget else output_format
    people, central = [], 0
    for position, name in enumerate(names):
        person = cache.person(name)
        if all(person.slug != other.slug for other in people):
            people.append(person)
            central += named is None or position < named
    topics, topic_notes = searched_topics(people, topics, core)
    fetched = cache.catalog.get("source", {}).get("snapshot_fetched_at") or []
    online = (cache.catalog.get("online_snapshots") or {}).get("fetched_at") or []
    everything = sorted(stamp[:10] for stamp in list(fetched) + list(online) if stamp)
    rank = LEVEL_RANK
    ceiling = rank[detail] if detail else 0
    steps = [step for step in LADDER if rank[step[0]] >= ceiling and rank[step[1]] >= ceiling]
    if len(people) == 1:                         # no pairs: one step for each level of the person
        steps = list({step[0]: step for step in reversed(steps)}.values())[::-1]
    built_people, built_pairs, built = {}, {}, {}    # each part is built once, whatever steps use it

    def person_at(level, index):
        if (level, index) not in built_people:
            built_people[level, index] = build_person(cache, people[index], level, list(topics), core)
        return built_people[level, index]

    def tables():
        if "tables" not in built:
            built["tables"] = {person.slug: person.nicknames() for person in people}
        return built["tables"]

    def pairs_at(level):
        """The pairs at a level of DETAIL; the mention scan (pair_material) is made once for all levels."""
        if level not in built_pairs:
            if "material" not in built:
                built["material"] = pair_material(cache, people, core)
            built_pairs[level] = build_pairs(cache, people, level, core, built["material"])
        return built_pairs[level]

    def skeleton_pairs():
        """The pairs with their calls and nothing else (no mention scan), as lower_bound measures them."""
        if "skeleton" not in built:
            built["skeleton"] = [{"people": [first.name, second.name],
                                  "calls": {f"{first.name}→{second.name}": calls(tables(), first, second),
                                            f"{second.name}→{first.name}": calls(tables(), second, first)},
                                  "combos": [], "mentions": [], "list_mentions": {}, "omitted": {}}
                                 for index, first in enumerate(people) for second in people[index + 1:]]
            pairs_only = (render_pairs(built["skeleton"], skeleton=True) if measure == "md"
                          else json.dumps(built["skeleton"], ensure_ascii=False, indent=1))
            built["pairs_floor"] = len(pairs_only) if isinstance(pairs_only, str) else len("\n".join(pairs_only))
        return built["skeleton"]

    def assemble(levels, pair_level, pairs=None):
        """(pack, markdown, output size) with each person at their own level. pairs: the skeleton pairs of
        lower_bound in place of the pairs of the level."""
        pair_level = pair_level if len(people) > 1 else None
        pack = {"schema": SCHEMA, "generator": f"hololive_story.py {VERSION}",
                "detail": max(levels, key=rank.get),           # every person has at least this
                "pair_detail": pair_level,
                "rules": RULES, "snapshot": None, "topics": list(topics)}
        if cast:
            pack["cast"] = cast
        pack["people"] = [person_at(level, index) for index, level in enumerate(levels)]
        pack["pairs"] = (pairs if pairs is not None else [] if pair_level in (None, "names")
                         else pairs_at(pair_level))
        if pair_level == "names":
            if "names" not in built:
                built["names"] = build_names(people, tables())
                built["cast_combos"] = build_cast_combos(cache, people, central, core)
            pack["names"] = built["names"]
            if built["cast_combos"] is not None:
                pack["cast_combos"] = built["cast_combos"]
        large = pair_level == "names"
        pack["next"] = next_commands(people, topics, central=central, large=large)
        if large:
            pack["next_note"] = NEXT_NOTE
        if topic_notes:
            pack["topic_notes"] = topic_notes
        # The days of the cited text; with nothing cited, the days of the whole cache.
        if "dates" not in built:
            built["dates"] = date_sources(cache, people)
        stamps = saved_dates(cache, people, pack, built["dates"]) or everything
        pack["snapshot"] = (("wikiの保存日 " + (stamps[0] if stamps[0] == stamps[-1] else f"{stamps[0]}〜{stamps[-1]}"))
                            if stamps else "wikiの保存日は catalog.json を参照")
        pack["budget"] = {"limit": budget, "measured_as": measure, "automatic": automatic_budget}
        text = render_md(pack, skeleton=pairs is not None)
        pack["characters"] = len(text)
        return pack, text, len(text) if measure == "md" else len(json.dumps(pack, ensure_ascii=False, indent=1)) + 1

    def section_size(level, index):
        """The length one person's section adds to the output of a step with everyone at one level."""
        if (level, index, measure) not in built:
            person = person_at(level, index)
            built[level, index, measure] = (len("\n".join(render_person(person, list(topics), False))) + 1
                                            if measure == "md" else len(json.dumps(person, ensure_ascii=False, indent=1)))
        return built[level, index, measure]

    def lower_bound(levels, pair_level):
        """A length under which the output of this step (everyone at one level, pairs at a level of DETAIL)
        cannot be, found without the pairs' mention scan: the pairs' sections alone, then with each person's
        section added (stopping as soon as it is over the budget, so a large cast is not built at every level),
        then the whole pack with each pair's block as its heading and SKELETON_LINE (Markdown) or with empty
        lists (JSON); less BOUND_MARGIN."""
        skeleton = skeleton_pairs()
        total = built["pairs_floor"] - BOUND_MARGIN
        for index, level in enumerate(levels):
            if total > budget:
                return total
            total += section_size(level, index)
        if total > budget:
            return total
        return assemble(levels, pair_level, pairs=skeleton)[2] - BOUND_MARGIN

    sizes, passed = [], []
    for person_level, pair_level in steps:
        levels = [person_level] * len(people)
        if budget is not None and len(people) > 1 and pair_level != "names":
            bound = lower_bound(levels, pair_level)
            if bound > budget:
                passed.append((bound, levels, pair_level))
                continue
        pack, text, output_size = assemble(levels, pair_level)
        if budget is None or output_size <= budget:
            break
        sizes.append(output_size)
    else:
        # The shortest step, for the message: a tiny cast is shorter at brief than at names (its fixed notes), and a
        # passed step can be measured only by building it (those that could be shorter than the rest).
        smallest = min(sizes)
        for bound, levels, pair_level in passed:
            if bound < smallest:
                smallest = min(smallest, assemble(levels, pair_level)[2])
        limit = f"既定の上限 {budget:,} 字（Markdown換算）" if automatic_budget else f"--budget {budget:,}"
        raise core.CacheError(f"最小の詳細度でも {smallest:,} 字となり{limit}を超えます。"
                              f"人数を分けるか --budget {smallest} 以上を指定してください。")
    # Room left in the budget goes to the people's own sections, the first names first: the people named (the
    # central characters) as far as they go, then the ones --group added, everyone of each one level up before
    # anyone a second.
    for chosen in (range(central), range(central, len(people))):
        for target in [level for level in reversed(DETAIL_ORDER) if ceiling <= rank[level] < rank[person_level]]:
            for index in chosen:
                if rank[levels[index]] == rank[target] + 1:
                    trial = levels[:index] + [target] + levels[index + 1:]
                    attempt = assemble(trial, pair_level)
                    if attempt[2] <= budget:
                        levels, (pack, text, output_size) = trial, attempt
    return pack, text


NEXT_NOTE = ("ほかの人も同じ形のコマンドで読める（read 名前 語録 --section 口癖 --all ／ show 名前 --digest ／ "
             "read 名前 main --all）。")
CENTRAL_STORY = 4       # a large cast's pack suggests a story of at most this many people named first


def next_commands(people, topics, *, central=None, large=False):
    """The commands for reading more: each person's catchphrases, digest and main page, the first two's shared
    material, the topics. For a large cast (the names level) only the first people named (at most three) and a
    story of the central characters alone (the people named, at most CENTRAL_STORY); NEXT_NOTE gives the rest."""
    commands = []
    central = len(people) if central is None else central
    for person in people[:min(3, central)] if large else people:
        name = json.dumps(person.name, ensure_ascii=False)
        pages = {entry["id"]: bool(entry["text"]) for entry in person.pages()["pages"]}
        if "quotes" in pages:
            commands.append(f"read {name} 語録 --section 口癖 --all" + ("" if pages["quotes"] else " --online"))
        if person.entry["files"].get("digest"):
            commands.append(f"show {name} --digest")
        if "main" in pages:
            commands.append(f"read {name} main --all" + ("" if pages["main"] else " --online"))
        else:
            commands.append(f"show {name}")
    if large and central and min(CENTRAL_STORY, central) < len(people):
        chosen = " ".join(json.dumps(person.name, ensure_ascii=False) for person in people[:min(CENTRAL_STORY, central)])
        commands.append(f"story {chosen}" + "".join(f" --topic {json.dumps(topic, ensure_ascii=False)}" for topic in topics))
    if len(people) > 1 and (not large or central > 1):        # a large cast: two of the people named
        a, b = (json.dumps(person.name, ensure_ascii=False) for person in people[:2])
        commands.append(f"find {a} {b}")
        commands.append(f"nicknames {a} --query {b}")
    for topic in topics:
        commands.append(f"search {json.dumps(topic, ensure_ascii=False)} --limit 40")
    return commands


# --- groups (--group) -----------------------------------------------------------------

# The generations and units in the order of the wiki top page's member table (JP up to holoX, ID, EN, then
# DEV_IS and the unit after it); a generation the catalog has and this does not comes after them.
GENERATIONS = ("0期生", "1期生", "2期生", "ゲーマーズ", "3期生", "4期生", "5期生", "holoX", "id1", "id2", "id3",
               "myth", "hope", "council", "advent", "justice", "ReGLOSS", "FLOW GLOW", "アソビ★まわり隊！")
# Groups of several generations: everyone (None), a region, or generations.
GROUPS = {"all": None, "JP": "JP", "EN": "EN", "ID": "ID", "DEV_IS": ("ReGLOSS", "FLOW GLOW"),
          "promise": ("hope", "council")}
GROUP_ALIASES = {"全員": "all", "日本": "JP", "english": "EN", "indonesia": "ID", "gamers": "ゲーマーズ",
                 "ホロライブゲーマーズ": "ゲーマーズ", "ホロライブファンタジー": "3期生", "ほろふぉーす": "4期生",
                 "holoforce": "4期生", "ねぽらぼ": "5期生", "nepolabo": "5期生", "6期生": "holoX", "秘密結社holoX": "holoX",
                 "projecthope": "hope", "area15": "id1", "holoro": "id2", "holoh3ro": "id3", "id1期生": "id1",
                 "id2期生": "id2", "id3期生": "id3"}
# The wiki's member table lists 白上フブキ under ゲーマーズ as well as under 1期生 (兼任).
ALSO_IN = {"ゲーマーズ": ("shirakami_fubuki",)}
# wiki_status of the people --group adds only with --include-former (not_listed: not in the member table).
FORMER = frozenset({"graduated", "graduated_or_ended", "ended", "not_listed"})
GROUP_NAMES = ("JP・EN・ID・all（全員）・DEV_IS（ReGLOSS と FLOW GLOW）・promise（hope と council）と、期・ユニットの名前（"
               + " ".join(GENERATIONS) + "）")


def group_key(text):
    """A group name as compared: no spaces, hyphens, underscores, ・, ★ or ！; Latin letters in one case."""
    return re.sub(r"[\s_\-・★☆！!]", "", str(text)).casefold()


def roster_order(cache, core):
    """The catalog's people in the order --group adds them: by generation (GENERATIONS), the current members of
    each before the others, then by their place in the wiki top page's member table (the line of person.json's
    wiki_status, then the name's column in it), then the catalog's order."""
    top = shared_source(cache, "wiki_top", core)
    generations = list(GENERATIONS) + [entry["generation"] for entry in cache.people
                                       if entry["generation"] not in GENERATIONS]
    keyed = []
    for position, entry in enumerate(cache.people):
        line = ((core.Person(cache, entry).info().get("wiki_status") or {}).get("line")
                if entry.get("wiki_status") else None)
        column = top.lines[line - 1].find(entry["name"]) if top is not None and line and line <= len(top.lines) else -1
        keyed.append(((generations.index(entry["generation"]), entry.get("wiki_status") in FORMER,
                       line or 10 ** 9, column, position), entry))
    return [entry for _, entry in sorted(keyed, key=lambda pair: pair[0])]


def in_group(entry, group):
    selected = GROUPS.get(group, (group,))
    if selected is None:
        return True
    if isinstance(selected, str):
        return entry["region"] == selected
    return entry["generation"] in selected or any(entry["slug"] in ALSO_IN.get(name, ()) for name in selected)


def choose_cast(cache, args, core):
    """(names, named, cast) for build_pack. Without --group, the names as given. With it, the people named, then
    each group's members in roster_order: those the wiki top page lists as current members (all with
    --include-former), never one without text (nothing to show, nothing to add to a scene), less --exclude;
    cast says how the cast was put together, with notes on who was left out and why."""
    if not args.group:
        if args.include_former or args.exclude:
            raise core.CacheError("--include-former と --exclude は --group と使います（名前で指定した人はそのまま入る）。")
        if not args.person:
            raise core.CacheError("人物名か --group を指定してください。")
        return list(args.person), None, None
    named = []
    for name in args.person:
        person = cache.person(name)
        if all(person.slug != other.slug for other in named):
            named.append(person)
    lookup = {group_key(name): name for name in (*GROUPS, *GENERATIONS, *(entry["generation"] for entry in cache.people))}
    lookup.update({group_key(alias): target for alias, target in GROUP_ALIASES.items()})
    groups = []
    for given in args.group:
        key = group_key(given)
        # ホロライブ3期生, hololive EN, 3期: the name with ホロライブ/hololive before it or without its 生.
        bare = re.sub(r"^(?:ホロライブ|hololive)", "", key)
        group = next((lookup[word] for word in (key, bare, key + "生", bare + "生") if word in lookup), None)
        if group is None:
            raise core.CacheError(f"--group「{given}」は分かりません。使える名前: {GROUP_NAMES}")
        if group not in groups:
            groups.append(group)
    excluded = {}
    for name in args.exclude:
        person = cache.person(name)
        if any(person.slug == other.slug for other in named):
            raise core.CacheError(f"{person.name} は人物名と --exclude の両方にあります（--exclude は --group で加わる人を除く）。")
        excluded[person.slug] = person.name
    taken = {person.slug for person in named}
    chosen, report, left_former, left_empty, removed = [], [], {}, {}, {}
    order = roster_order(cache, core)
    for group in groups:
        added = 0
        for entry in order:
            if not in_group(entry, group) or entry["slug"] in taken:
                continue
            if not entry.get("pages_with_text"):
                left_empty[entry["slug"]] = entry["name"]
            elif entry.get("wiki_status") in FORMER and not args.include_former:
                left_former[entry["slug"]] = entry["name"]
            elif entry["slug"] in excluded:
                removed[entry["slug"]] = entry["name"]
            else:
                taken.add(entry["slug"])
                chosen.append(entry["slug"])
                added += 1
        report.append({"name": group, "added": added})
    if not named and not chosen:
        raise core.CacheError("顔ぶれが空です（--group の人がすべて --exclude などで除かれた）。")
    notes = []
    if left_former:
        notes.append("wikiトップの在籍メンバー欄にない人（卒業・活動終了など）は加えていない: " + "、".join(left_former.values())
                     + "（会話の前提が「卒業生はいない」などなら --include-former）")
    if left_empty:
        notes.append("本文のない人は加えていない: " + "、".join(left_empty.values()) + "（名前で指定すると欠測記録として入る）")
    unused = [name for slug, name in excluded.items() if slug not in removed]
    if unused:
        notes.append("--exclude のうち、--group で加わる人にいなかった人: " + "、".join(unused))
    cast = {"named": len(named), "groups": report, "include_former": bool(args.include_former),
            "excluded": list(removed.values()), "notes": notes}
    return [person.slug for person in named] + chosen, len(named), cast


# --- command line (registered by hololive_cache_core as `story`) -------------------------

def add_arguments(parser):
    parser.add_argument("person", nargs="*",
                        help="物語の登場人物（中心になる人を先に）。人数に上限はない。大人数の場面は --group で加えられる")
    parser.add_argument("--group", action="append", default=[], metavar="GROUP",
                        help="グループのメンバーを加える（繰り返し可）。名前を挙げた人の後に、wikiトップのメンバー一覧の順で"
                             "加わる。既定は在籍メンバー欄の人だけ。使える名前: " + GROUP_NAMES)
    parser.add_argument("--include-former", action="store_true",
                        help="--group に、wikiトップで卒業・活動終了などの欄にある人も含める（会話の前提が「卒業生はいない」など"
                             "のとき）")
    parser.add_argument("--exclude", action="append", default=[], metavar="NAME",
                        help="--group で加わる人から除く（繰り返し可）")
    parser.add_argument("--topic", action="append", default=[],
                        help="場面の話題。各人の本文から該当行を添える。複数なら --topic を繰り返す（--topic 料理 --topic ホラー）。"
                             "空白を含む語句がどのページにも無ければ、空白で分けた語で探す")
    parser.add_argument("--detail", choices=tuple(DETAIL), default=None,
                        help="通常は指定しない（既定は自動: 上限に収まる最も詳しい段階。ace > full > normal > brief > cameo。"
                             "各人の節を組み合わせより優先し、余りで名前を挙げた順に各人の節を一段詳しくする）。"
                             "指定すると、その詳細度以下だけを使う")
    parser.add_argument("--budget", type=int, default=None,
                        help="明示時は指定出力形式の実文字数が上限（JSONの整形・改行も含む）。"
                             "未指定時のみ、1人80,000字＋追加1人ごとに10,000字（最大200,000字。13人以上は200,000字）を"
                             "Markdown換算で適用し、MD/JSONを同じ詳細度で出す。最も簡潔な段階でも超える場合はエラー")
    parser.add_argument("--format", choices=("md", "json"), default="md")
    parser.add_argument("--part", type=int, default=None,
                        help="長い資料パックを15,000字以内の部に分け、その部だけを出す（1から。先頭に全何部かを示す）")
    parser.add_argument("--level", action="store_true",
                        help="詳細度の判定だけを表示する（確認用）。各人と組み合わせの段階（ace／full／normal／brief／cameo、"
                             "組み合わせは names も）、字数と上限、--part の部の数を示し、資料パックの本文は出さない。"
                             "段階の選び方と資料パックの中身は、--level を付けない同じコマンドと同じ")


# A part of a long pack (--part): what one tool result can show whole.
PART_CHARACTERS = 15000


def parts_of(text, size=PART_CHARACTERS):
    """[(first line, last line, text)] of the text cut at line ends into parts of at most size characters
    (a longer line is a part of its own)."""
    lines = text.rstrip("\n").split("\n")
    parts, start, length = [], 0, 0
    for index, line in enumerate(lines):
        if index > start and length + len(line) + 1 > size:
            parts.append((start + 1, index, "\n".join(lines[start:index])))
            start, length = index, 0
        length += len(line) + 1
    parts.append((start + 1, len(lines), "\n".join(lines[start:])))
    return parts


def level_view(pack, text, output_format):
    """The --level view: the detail level of each person and of the pairs, and the size against the limit,
    without the pack itself. The pack and its level are those the same command gives without --level."""
    lines = [f"詳細度: {detail_label(pack)}", "各人:"]
    lines += [f"- {person['name']}: {person['detail']}" for person in pack["people"]]
    if pack["pair_detail"]:
        count = len(pack["people"])
        lines.append(f"組み合わせ（{count * (count - 1) // 2}組）: {pack['pair_detail']}")
    budget = pack["budget"]
    limit = f"上限 {budget['limit']:,}字（{'自動' if budget['automatic'] else '--budget'}）"
    if budget["measured_as"] == "json":                     # an explicit --budget measures the JSON output
        size = len(json.dumps(pack, ensure_ascii=False, indent=1)) + 1
        lines.append(f"字数: JSONの出力 {size:,}字／{limit}")
    else:
        lines.append(f"字数: Markdown {len(text):,}字／{limit}")
    if output_format == "md":
        count = len(parts_of(text))
        lines[-1] += f"。--part で全{count}部" if count > 1 else "。1部（--part は不要）"
    lines.append("（詳細度の確認用の表示。資料パックの本文は、--level を外した同じコマンドで出る。"
                 "詳細度は詳しい順に ace・full・normal・brief・cameo。組み合わせの names は呼び方の一覧だけ）")
    return "\n".join(lines) + "\n"


def run(cache, args, *, core):
    if args.budget is not None and args.budget < 1000:
        raise core.CacheError("--budget は1000以上にしてください。")
    if args.part is not None and args.format != "md":
        raise core.CacheError("--part は Markdown の出力（--format md）で使います。")
    automatic = args.budget is None
    names, named, cast = choose_cast(cache, args, core)
    count = len({cache.person(name).slug for name in names})        # a name given twice is one person
    budget = default_budget(count) if automatic else args.budget
    # The automatic limit is about how much there is to read, so JSON's quoting and indentation
    # do not push a JSON pack down to a lower detail level than the same pack in Markdown.
    pack, text = build_pack(cache, names, topics=args.topic, detail=args.detail, budget=budget, core=core,
                            output_format=args.format, automatic_budget=automatic, named=named, cast=cast)
    if args.level:
        # Only the level this command gets (with --part too: the pack is the same in every part).
        sys.stdout.write(level_view(pack, text, args.format))
    elif args.format == "json":
        core.out(json.dumps(pack, ensure_ascii=False, indent=1))
    elif args.part is not None:
        parts = parts_of(text)
        if not 1 <= args.part <= len(parts):
            raise core.CacheError(f"--part は1〜{len(parts)}です（この資料パックは全{len(parts)}部）。")
        first, last, part = parts[args.part - 1]
        total = len(text.rstrip("\n").split("\n"))
        then = (f"続きは同じコマンドに --part {args.part + 1}" if args.part < len(parts) else "これが最後の部")
        # The closing line shows that the part was shown to its end: a cut-off output lacks it.
        sys.stdout.write(f"（物語用資料パック 全{len(parts)}部の第{args.part}部: {first}〜{last}行目／"
                         f"全{total:,}行・{len(text):,}字。{then}）\n\n{part}\n\n"
                         f"（第{args.part}部ここまで: {last}行目。{then}）\n")
    else:
        # Written first, so that a reader whose tool cuts the long output off sees it before the cut.
        count = len(parts_of(text))
        if count > 1:
            sys.stderr.write(f"（この資料パックは{len(text):,}字。出力が途中で省略される場合は、同じコマンドに "
                             f"--part 1 から --part {count} まで付けて、{PART_CHARACTERS:,}字以内ずつ読める）\n")
            sys.stderr.flush()
        sys.stdout.write(text if text.endswith("\n") else text + "\n")
    return 0
