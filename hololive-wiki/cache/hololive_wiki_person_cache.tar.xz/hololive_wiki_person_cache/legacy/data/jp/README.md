# data/ — ホロライブJPタレント 人物像キャッシュ

`hololive_profile_cache.py` が ホロライブ非公式wiki (https://seesaawiki.jp/hololivetv/)
から構築した、JPタレント45名分の再利用キャッシュです。
2回目以降の参照ではwikiへ通信せず、ここだけを読めば人物像を把握できます。

## 読む順番

| 段階 | ファイル | 目安 | 用途 |
|---|---|---|---|
| 1 | `roster.md` | 13KB | 45名を1枚で見渡す。世代・ファンの愛称・一人称・人物像の冒頭 |
| 2 | `cards/<slug>.md` | 各5〜12KB | **まずここ。**基本情報・一人称・人物像・口癖・あいさつ・主要な呼称 |
| 3 | `digests/<slug>.md` | 各53〜771KB | 性格/配信内容/好き嫌い/語録全件/関連語/エピソード/呼称全件/年別活動/脚注 |
| 4 | `talents/<slug>.json` | 各0.2〜1.7MB | 全文レコード。個別ページ全節・表・脚注と各配下ページ |
| 5 | `titles/<slug>.json` | 各0.4〜1.4MB | 関連タイトル（実況ゲーム・歌唱楽曲・使用BGM・動画一覧） |
| 横断 | `nicknames.json` | 572KB | 3,863件の「誰が誰をどう呼ぶか」を1ファイルに平坦化 |
| 横断 | `shared/*.json` | 3.3MB | 交友関係、コンビ／ユニット名一覧、元ネタ集など |
| 索引 | `index.json` | 42KB | 名簿・収録量・どのファイルを見るかの対応表 |

`<slug>` は `index.json` の `talents[].slug`（例: `tokino_sora`, `houshou_marine`）です。

## コマンド

```bash
python hololive_profile_cache.py list                 # 一覧
python hololive_profile_cache.py show 宝鐘マリン       # 要約カード
python hololive_profile_cache.py show 宝鐘マリン --digest
python hololive_profile_cache.py full marine --field nicknames
python hololive_profile_cache.py search "こんまり"
```

## 構造のきまり

- `talents/<slug>.json` の `main_page.sections` は、見出しごとの**直下の行だけ**を持ちます。
  `preamble` + 全 `body` + 見出し行 = 元記事の全行 となり、取りこぼしがありません
  （`verify` が毎回この等式を検査します）。
- `nicknames` は `相手 / 呼び方(calls) / 呼ばれ方(called_by)` の正規化レコードです。
  個別ページ内の呼称表と `【呼称一覧】` ページを統合し、表のヘッダ行は除いています。
- `tables` は rowspan/colspan を解決した矩形（論理グリッド）です。一覧系ページでは
  本文行と重複するため表を省いています。
- `persona` のキー: `about_games`, `about_singing`, `about_study`, `appearance`, `belongings`, `discography`, `dislikes`, `environment`, `external_vtuber`, `family`, `greetings`, `hobby`, `inline_episodes`, `intro_video`, `likes`, `listener_relations`, `member_relations`, `membership`, `official_info`, `personality`, `position_hololive`, `position_production`, `profile_book`, `profile_detail`, `stamina`, `stream_style`, `stream_tendency`, `three_d`, `voice`
- 本文は絵文字のサロゲート文字参照を解決済みで、U+FFFD は含みません。

## 出典と鮮度

各レコードの `sources[]` に、ページごとの URL・wiki側の最終更新・取得時刻・
元HTMLのSHA-256を記録しています。作り直しは次の通りです。

```bash
python hololive_profile_cache.py discover && \
python hololive_profile_cache.py fetch && \
python hololive_profile_cache.py build && \
python hololive_profile_cache.py verify
```

構築日時: 2026-09-22T13:37:26Z / リーダー版: 3.8.3 / 収録 644ページ・547,237行
