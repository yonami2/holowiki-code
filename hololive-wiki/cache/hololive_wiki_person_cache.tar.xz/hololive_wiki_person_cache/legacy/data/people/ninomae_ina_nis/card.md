# Ninomae Ina'nis

地域: EN
区分: myth

## 記事の取得状況

取得記事: 12 URL
構造検査とモデル全文読了は別です。

## 呼称の向き（Wiki表の転記）

本人→相手が『呼び方』、相手→本人が『呼ばれ方』。

- (視聴者): 本人→相手『』／相手→本人『』
- AZKi: 本人→相手『』／相手→本人『』
- Airani Iofifteen: 本人→相手『』／相手→本人『』
- Anya Melfissa: 本人→相手『』／相手→本人『』
- Ayunda Risu: 本人→相手『』／相手→本人『』
- Cecilia Immergreen: 本人→相手『』／相手→本人『』
- Ceres Fauna: 本人→相手『』／相手→本人『』
- Elizabeth Rose Bloodflame: 本人→相手『』／相手→本人『』
- Fuwawa Abyssgard: 本人→相手『』／相手→本人『』
- Gawr Gura: 本人→相手『』／相手→本人『』
- Gigi Murin: 本人→相手『』／相手→本人『』
- Hakos Baelz: 本人→相手『』／相手→本人『』
- IRyS: 本人→相手『』／相手→本人『』
- Kaela Kovalskia: 本人→相手『』／相手→本人『』
- Kobo Kanaeru: 本人→相手『』／相手→本人『』
- Koseki Bijou: 本人→相手『』／相手→本人『』
- 続き 72件は nicknames.json

## 参照記事

- Ninomae Ina'nis — 568行 — https://seesaawiki.jp/hololivetv/d/Ninomae%20Ina%27nis
- Ninomae Ina'nis【Minecraft】 — 49行 — https://seesaawiki.jp/hololivetv/d/Ninomae%20Ina%27nis%A1%DAMinecraft%A1%DB
- Ninomae Ina'nis【エピソード集】 — 15行 — https://seesaawiki.jp/hololivetv/d/Ninomae%20Ina%27nis%A1%DA%A5%A8%A5%D4%A5%BD%A1%BC%A5%C9%BD%B8%A1%DB
- Ninomae Ina'nis【デザイナーによるイラスト】 — 82行 — https://seesaawiki.jp/hololivetv/d/Ninomae%20Ina%27nis%A1%DA%A5%C7%A5%B6%A5%A4%A5%CA%A1%BC%A4%CB%A4%E8%A4%EB%A5%A4%A5%E9%A5%B9%A5%C8%A1%DB
- Ninomae Ina'nis【使用BGM】 — 5行 — https://seesaawiki.jp/hololivetv/d/Ninomae%20Ina%27nis%A1%DA%BB%C8%CD%D1BGM%A1%DB
- Ninomae Ina'nis【動画一覧】 — 1064行 — https://seesaawiki.jp/hololivetv/d/Ninomae%20Ina%27nis%A1%DA%C6%B0%B2%E8%B0%EC%CD%F7%A1%DB
- Ninomae Ina'nis【参考資料】 — 327行 — https://seesaawiki.jp/hololivetv/d/Ninomae%20Ina%27nis%A1%DA%BB%B2%B9%CD%BB%F1%CE%C1%A1%DB
- Ninomae Ina'nis【呼称一覧】 — 101行 — https://seesaawiki.jp/hololivetv/d/Ninomae%20Ina%27nis%A1%DA%B8%C6%BE%CE%B0%EC%CD%F7%A1%DB
- Ninomae Ina'nis【実況ゲームタイトル一覧】 — 118行 — https://seesaawiki.jp/hololivetv/d/Ninomae%20Ina%27nis%A1%DA%BC%C2%B6%B7%A5%B2%A1%BC%A5%E0%A5%BF%A5%A4%A5%C8%A5%EB%B0%EC%CD%F7%A1%DB
- Ninomae Ina'nis【歌唱楽曲一覧】 — 4693行 — https://seesaawiki.jp/hololivetv/d/Ninomae%20Ina%27nis%A1%DA%B2%CE%BE%A7%B3%DA%B6%CA%B0%EC%CD%F7%A1%DB
- Ninomae Ina'nis【自作作品集】 — 1997行 — https://seesaawiki.jp/hololivetv/d/Ninomae%20Ina%27nis%A1%DA%BC%AB%BA%EE%BA%EE%C9%CA%BD%B8%A1%DB
- Ninomae Ina'nis【衣装一覧】 — 64行 — https://seesaawiki.jp/hololivetv/d/Ninomae%20Ina%27nis%A1%DA%B0%E1%C1%F5%B0%EC%CD%F7%A1%DB
