# 鈴鳴つづり｜アソビ★まわり隊！

初配信予定: 2026年9月25日。Wiki 収録時点は初配信前。

手紙と笑顔を届けるヤギの郵便屋。運び屋としての腕と天然な面が紹介される。公開手書き文では初配信を前に緊張と期待を記す。

話し方のうち配信由来の一人称・あいさつ・呼称・反応傾向は未確認。人物の公開メッセージは `handwritten_message_evidence` を参照。

## 元ページ

- 鈴鳴つづり（277 行）: https://seesaawiki.jp/hololivetv/d/%ce%eb%cc%c4%a4%c4%a4%c5%a4%ea
- 鈴鳴つづり【参考資料】（46 行）: https://seesaawiki.jp/hololivetv/d/%ce%eb%cc%c4%a4%c4%a4%c5%a4%ea%a1%da%bb%b2%b9%cd%bb%f1%ce%c1%a1%db
- 鈴鳴つづり【語録】（28 行）: https://seesaawiki.jp/hololivetv/d/%ce%eb%cc%c4%a4%c4%a4%c5%a4%ea%a1%da%b8%ec%cf%bf%a1%db
- 鈴鳴つづり【関連語】（30 行）: https://seesaawiki.jp/hololivetv/d/%ce%eb%cc%c4%a4%c4%a4%c5%a4%ea%a1%da%b4%d8%cf%a2%b8%ec%a1%db
- 鈴鳴つづり【動画一覧】（61 行）: https://seesaawiki.jp/hololivetv/d/%ce%eb%cc%c4%a4%c4%a4%c5%a4%ea%a1%da%c6%b0%b2%e8%b0%ec%cd%f7%a1%db
- 鈴鳴つづり【歌唱楽曲一覧】（3196 行）: https://seesaawiki.jp/hololivetv/d/%ce%eb%cc%c4%a4%c4%a4%c5%a4%ea%a1%da%b2%ce%be%a7%b3%da%b6%ca%b0%ec%cd%f7%a1%db
- 鈴鳴つづり【自作作品集】（89 行）: https://seesaawiki.jp/hololivetv/d/%ce%eb%cc%c4%a4%c4%a4%c5%a4%ea%a1%da%bc%ab%ba%ee%ba%ee%c9%ca%bd%b8%a1%db
- 鈴鳴つづり【エピソード集】（5 行）: https://seesaawiki.jp/hololivetv/d/%ce%eb%cc%c4%a4%c4%a4%c5%a4%ea%a1%da%a5%a8%a5%d4%a5%bd%a1%bc%a5%c9%bd%b8%a1%db
- 鈴鳴つづり【衣装一覧】（13 行）: https://seesaawiki.jp/hololivetv/d/%ce%eb%cc%c4%a4%c4%a4%c5%a4%ea%a1%da%b0%e1%c1%f5%b0%ec%cd%f7%a1%db

JSON全文: `profiles/suzuna_tsuzuri.json` ／ 元の Reader JSON と元 HTML は `main/`, `subpages/`, `raw/`。
