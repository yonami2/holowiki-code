# 鈴鳴つづり

地域: JP
区分: アソビ★まわり隊！

## 記事の取得状況

取得記事: 9 URL
構造検査とモデル全文読了は別です。

## 呼称の向き（Wiki表の転記）

本人→相手が『呼び方』、相手→本人が『呼ばれ方』。

- (視聴者): 本人→相手『』／相手→本人『』
- AZKi: 本人→相手『』／相手→本人『』
- Airani Iofifteen: 本人→相手『』／相手→本人『』
- Anya Melfissa: 本人→相手『』／相手→本人『』
- Ayunda Risu: 本人→相手『』／相手→本人『』
- Cecilia Immergreen: 本人→相手『』／相手→本人『』
- Ceres Fauna: 本人→相手『』／相手→本人『』
- Elizabeth Rose Bloodflame: 本人→相手『』／相手→本人『』
- Fuwawa Abyssgard: 本人→相手『』／相手→本人『』
- Gawr Gura: 本人→相手『』／相手→本人『』
- Gigi Murin: 本人→相手『』／相手→本人『』
- Hakos Baelz: 本人→相手『』／相手→本人『』
- IRyS: 本人→相手『』／相手→本人『』
- Kaela Kovalskia: 本人→相手『』／相手→本人『』
- Kobo Kanaeru: 本人→相手『』／相手→本人『』
- Koseki Bijou: 本人→相手『』／相手→本人『』
- 続き 72件は nicknames.json

## 参照記事

- 鈴鳴つづり — 277行 — https://seesaawiki.jp/hololivetv/d/%ce%eb%cc%c4%a4%c4%a4%c5%a4%ea
- 鈴鳴つづり【エピソード集】 — 5行 — https://seesaawiki.jp/hololivetv/d/%ce%eb%cc%c4%a4%c4%a4%c5%a4%ea%a1%da%a5%a8%a5%d4%a5%bd%a1%bc%a5%c9%bd%b8%a1%db
- 鈴鳴つづり【動画一覧】 — 61行 — https://seesaawiki.jp/hololivetv/d/%ce%eb%cc%c4%a4%c4%a4%c5%a4%ea%a1%da%c6%b0%b2%e8%b0%ec%cd%f7%a1%db
- 鈴鳴つづり【参考資料】 — 46行 — https://seesaawiki.jp/hololivetv/d/%ce%eb%cc%c4%a4%c4%a4%c5%a4%ea%a1%da%bb%b2%b9%cd%bb%f1%ce%c1%a1%db
- 鈴鳴つづり【歌唱楽曲一覧】 — 3196行 — https://seesaawiki.jp/hololivetv/d/%ce%eb%cc%c4%a4%c4%a4%c5%a4%ea%a1%da%b2%ce%be%a7%b3%da%b6%ca%b0%ec%cd%f7%a1%db
- 鈴鳴つづり【自作作品集】 — 89行 — https://seesaawiki.jp/hololivetv/d/%ce%eb%cc%c4%a4%c4%a4%c5%a4%ea%a1%da%bc%ab%ba%ee%ba%ee%c9%ca%bd%b8%a1%db
- 鈴鳴つづり【衣装一覧】 — 13行 — https://seesaawiki.jp/hololivetv/d/%ce%eb%cc%c4%a4%c4%a4%c5%a4%ea%a1%da%b0%e1%c1%f5%b0%ec%cd%f7%a1%db
- 鈴鳴つづり【語録】 — 28行 — https://seesaawiki.jp/hololivetv/d/%ce%eb%cc%c4%a4%c4%a4%c5%a4%ea%a1%da%b8%ec%cf%bf%a1%db
- 鈴鳴つづり【関連語】 — 30行 — https://seesaawiki.jp/hololivetv/d/%ce%eb%cc%c4%a4%c4%a4%c5%a4%ea%a1%da%b4%d8%cf%a2%b8%ec%a1%db
