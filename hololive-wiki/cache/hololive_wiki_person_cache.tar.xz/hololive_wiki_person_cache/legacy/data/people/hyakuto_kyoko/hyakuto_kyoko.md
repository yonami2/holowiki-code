# 百灯キョーコ｜アソビ★まわり隊！

初配信予定: 2026年9月25日。Wiki 収録時点は初配信前。

拡声器を携えるヒーローポリス。考えるより先に人助けへ走り、声が大きいという公式紹介。公開手書き文では早く皆に会いたいと綴る。

話し方のうち配信由来の一人称・あいさつ・呼称・反応傾向は未確認。人物の公開メッセージは `handwritten_message_evidence` を参照。

## 元ページ

- 百灯キョーコ（278 行）: https://seesaawiki.jp/hololivetv/d/%c9%b4%c5%f4%a5%ad%a5%e7%a1%bc%a5%b3
- 百灯キョーコ【語録】（28 行）: https://seesaawiki.jp/hololivetv/d/%c9%b4%c5%f4%a5%ad%a5%e7%a1%bc%a5%b3%a1%da%b8%ec%cf%bf%a1%db
- 百灯キョーコ【関連語】（30 行）: https://seesaawiki.jp/hololivetv/d/%c9%b4%c5%f4%a5%ad%a5%e7%a1%bc%a5%b3%a1%da%b4%d8%cf%a2%b8%ec%a1%db
- 百灯キョーコ【参考資料】（46 行）: https://seesaawiki.jp/hololivetv/d/%c9%b4%c5%f4%a5%ad%a5%e7%a1%bc%a5%b3%a1%da%bb%b2%b9%cd%bb%f1%ce%c1%a1%db
- 百灯キョーコ【エピソード集】（5 行）: https://seesaawiki.jp/hololivetv/d/%c9%b4%c5%f4%a5%ad%a5%e7%a1%bc%a5%b3%a1%da%a5%a8%a5%d4%a5%bd%a1%bc%a5%c9%bd%b8%a1%db
- 百灯キョーコ【動画一覧】（61 行）: https://seesaawiki.jp/hololivetv/d/%c9%b4%c5%f4%a5%ad%a5%e7%a1%bc%a5%b3%a1%da%c6%b0%b2%e8%b0%ec%cd%f7%a1%db
- 百灯キョーコ【歌唱楽曲一覧】（3196 行）: https://seesaawiki.jp/hololivetv/d/%c9%b4%c5%f4%a5%ad%a5%e7%a1%bc%a5%b3%a1%da%b2%ce%be%a7%b3%da%b6%ca%b0%ec%cd%f7%a1%db
- 百灯キョーコ【自作作品集】（49 行）: https://seesaawiki.jp/hololivetv/d/%c9%b4%c5%f4%a5%ad%a5%e7%a1%bc%a5%b3%a1%da%bc%ab%ba%ee%ba%ee%c9%ca%bd%b8%a1%db
- 百灯キョーコ【衣装一覧】（13 行）: https://seesaawiki.jp/hololivetv/d/%c9%b4%c5%f4%a5%ad%a5%e7%a1%bc%a5%b3%a1%da%b0%e1%c1%f5%b0%ec%cd%f7%a1%db

JSON全文: `profiles/hyakuto_kyoko.json` ／ 元の Reader JSON と元 HTML は `main/`, `subpages/`, `raw/`。
