# 宙科そぴあ｜アソビ★まわり隊！

初配信予定: 2026年9月24日。Wiki 収録時点は初配信前。

科学好きの宇宙飛行士。共同探究の仲間を求める設定。公開手書き文では世界の面白さを一緒に探したいと記す。

話し方のうち配信由来の一人称・あいさつ・呼称・反応傾向は未確認。人物の公開メッセージは `handwritten_message_evidence` を参照。

## 元ページ

- 宙科そぴあ（278 行）: https://seesaawiki.jp/hololivetv/d/%c3%e8%b2%ca%a4%bd%a4%d4%a4%a2
- 宙科そぴあ【参考資料】（46 行）: https://seesaawiki.jp/hololivetv/d/%c3%e8%b2%ca%a4%bd%a4%d4%a4%a2%a1%da%bb%b2%b9%cd%bb%f1%ce%c1%a1%db
- 宙科そぴあ【関連語】（30 行）: https://seesaawiki.jp/hololivetv/d/%c3%e8%b2%ca%a4%bd%a4%d4%a4%a2%a1%da%b4%d8%cf%a2%b8%ec%a1%db
- 宙科そぴあ【動画一覧】（61 行）: https://seesaawiki.jp/hololivetv/d/%c3%e8%b2%ca%a4%bd%a4%d4%a4%a2%a1%da%c6%b0%b2%e8%b0%ec%cd%f7%a1%db
- 宙科そぴあ【語録】（28 行）: https://seesaawiki.jp/hololivetv/d/%c3%e8%b2%ca%a4%bd%a4%d4%a4%a2%a1%da%b8%ec%cf%bf%a1%db
- 宙科そぴあ【自作作品集】（77 行）: https://seesaawiki.jp/hololivetv/d/%c3%e8%b2%ca%a4%bd%a4%d4%a4%a2%a1%da%bc%ab%ba%ee%ba%ee%c9%ca%bd%b8%a1%db
- 宙科そぴあ【エピソード集】（5 行）: https://seesaawiki.jp/hololivetv/d/%c3%e8%b2%ca%a4%bd%a4%d4%a4%a2%a1%da%a5%a8%a5%d4%a5%bd%a1%bc%a5%c9%bd%b8%a1%db
- 宙科そぴあ【歌唱楽曲一覧】（3196 行）: https://seesaawiki.jp/hololivetv/d/%c3%e8%b2%ca%a4%bd%a4%d4%a4%a2%a1%da%b2%ce%be%a7%b3%da%b6%ca%b0%ec%cd%f7%a1%db
- 宙科そぴあ【衣装一覧】（13 行）: https://seesaawiki.jp/hololivetv/d/%c3%e8%b2%ca%a4%bd%a4%d4%a4%a2%a1%da%b0%e1%c1%f5%b0%ec%cd%f7%a1%db

JSON全文: `profiles/sorashina_sopia.json` ／ 元の Reader JSON と元 HTML は `main/`, `subpages/`, `raw/`。
