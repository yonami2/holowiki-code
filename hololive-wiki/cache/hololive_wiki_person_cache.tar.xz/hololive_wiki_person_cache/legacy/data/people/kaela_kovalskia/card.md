# Kaela Kovalskia｜ID3

出典: https://seesaawiki.jp/hololivetv/d/Kaela%20Kovalskia
資料: 14ページ、本文7,569行。全文機械確認: True。
モデルによる全ページ全文読了: 未達。メインの人物描写と個別エピソード、共通語録を優先して確認済み。

本人行の呼称: 未記載。一人称は断定しない。

- 話し方: 落ち着いた低い声とサイレント笑いが特徴。褒め言葉を相手へ返し、「かわいい」は否定するやりとりがある。（Kaela Kovalskia 432–450行、Kaela Kovalskia 511–520行）
- 性格: 粘り強くゲームを掘り下げ、頼まれた人には資材や作業を惜しまず提供する。（Kaela Kovalskia 439–445行、Kaela Kovalskia 453–468行）
- 特徴: 鍛冶職人で長時間配信とMinecraftの建築に強い。ホラーにも動じにくい。（Kaela Kovalskia 58–63行、Kaela Kovalskia 432–445行）
- 関係: みこやわため、クロニーを好み、ぺこら・みこなどをMinecraftで支えた。（Kaela Kovalskia 229–235行、Kaela Kovalskia 453–469行）
- 反応傾向: 突然の恐怖には比較的冷静で、善意が届かないと落胆する。褒められると照れて否定する。（Kaela Kovalskia 433–435行、Kaela Kovalskia 504–520行、Kaela Kovalskia【エピソード集】 24–44行）

## 読取状態

本文・表・脚注は生JSONと原HTMLを保存し機械照合済み。未読の一覧本文は、このカードだけで全文読了と扱わない。
