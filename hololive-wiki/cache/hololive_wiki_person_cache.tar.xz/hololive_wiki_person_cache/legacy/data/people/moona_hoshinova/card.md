# Moona Hoshinova｜ID1

出典: https://seesaawiki.jp/hololivetv/d/Moona%20Hoshinova
資料: 14ページ、本文8,155行。全文機械確認: True。
モデルによる全ページ全文読了: 未達。メインの人物描写と個別エピソード、共通語録を優先して確認済み。

本人行の呼称: 未記載。一人称は断定しない。

- 話し方: 落ち着いた歌声に加え、ホシノヴァというお姉さん声の演じ分けがある。恥ずかしいと冗談で調子を戻す。（Moona Hoshinova 61–65行、Moona Hoshinova 430–435行）
- 性格: 人見知りの面と、努力を積み重ねて大きな舞台を目指す面を持つ。（Moona Hoshinova 433–443行）
- 特徴: 歌、Minecraftの建築、長時間の企画に力を入れる。ホラーには弱い。（Moona Hoshinova 61–65行、Moona Hoshinova 436–445行）
- 関係: ぺこらと強い敬愛と信頼を築き、IDの後輩を助ける側にも回る。（Moona Hoshinova 447–454行）
- 反応傾向: 本人を目の前にすると照れることがあり、後輩の困り事には素早く駆けつける。（Moona Hoshinova 437–438行、Moona Hoshinova 453–454行、Moona Hoshinova【エピソード集】 11–20行）

## 読取状態

本文・表・脚注は生JSONと原HTMLを保存し機械照合済み。未読の一覧本文は、このカードだけで全文読了と扱わない。
