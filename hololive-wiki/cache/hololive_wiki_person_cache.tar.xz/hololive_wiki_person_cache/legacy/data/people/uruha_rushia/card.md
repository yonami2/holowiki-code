# 潤羽るしあ

JP 3期生。一人称：るしあ／る／私。

魔界学校の見習いネクロマンサー。穏やかな丁寧語と小さくかわいらしい声が基本で、ゲーム中は気分に応じて力強い絶叫や早口にも変わる。人との交流に不安を感じながらも自ら歩み寄り、親しい相手やファンには甘い面もある。ホラー作品やゲームを好む。

## 使える呼称・声

あいさつ：こんるし〜／おつるし〜。

- 「こんるし〜」〔潤羽るしあ:205行〕
- 「おつるし〜」〔潤羽るしあ:207行〕
- 「アンデッドにしてやります」〔潤羽るしあ【語録】:23行〕

## 関係の手がかり

- 兎田ぺこら：3期生の先行組として付き合いがあり、互いに人見知りの時期を経た。〔潤羽るしあ:370〜371行〕
- 宝鐘マリン：掛け合いのある3期生同期。単に甘える一辺倒と決めつけない。〔潤羽るしあ:373〜373行〕
- ラプラス・ダークネス：呼称一覧に『ラプちゃん、山田、吾輩、キッズ』を記録。〔潤羽るしあ【呼称一覧】:41〜41行〕
- EN/ID：キアラとの『るしキア』、カリオペ・オリーとの『holodeath』がwikiユニット表にある。〔潤羽るしあ:377〜380行〕

## 解釈の境界

怪異を見て必ず怖がるとは言えない。ホラーを好み、実際に目撃した場合は甘い声と大声が行き来する、という創作上の可能性まで。

## 根拠

- basic disposition：潤羽るしあ 53〜60行（https://seesaawiki.jp/hololivetv/d/%bd%e1%b1%a9%a4%eb%a4%b7%a4%a2）
- likes horror：潤羽るしあ 171〜175行（https://seesaawiki.jp/hololivetv/d/%bd%e1%b1%a9%a4%eb%a4%b7%a4%a2）
- voice and mannerisms：潤羽るしあ 320〜331行（https://seesaawiki.jp/hololivetv/d/%bd%e1%b1%a9%a4%eb%a4%b7%a4%a2）
- group ties and care for fans：潤羽るしあ 335〜354行（https://seesaawiki.jp/hololivetv/d/%bd%e1%b1%a9%a4%eb%a4%b7%a4%a2）
- nicknames：潤羽るしあ【呼称一覧】 7〜69行（https://seesaawiki.jp/hololivetv/d/%bd%e1%b1%a9%a4%eb%a4%b7%a4%a2%a1%da%b8%c6%be%ce%b0%ec%cd%f7%a1%db）
- source sayings：潤羽るしあ【語録】 16〜93行（https://seesaawiki.jp/hololivetv/d/%bd%e1%b1%a9%a4%eb%a4%b7%a4%a2%a1%da%b8%ec%cf%bf%a1%db）
- episodes：潤羽るしあ【エピソード集】 1〜56行（https://seesaawiki.jp/hololivetv/d/%bd%e1%b1%a9%a4%eb%a4%b7%a4%a2%a1%da%a5%a8%a5%d4%a5%bd%a1%bc%a5%c9%bd%b8%a1%db）

歴史的な卒業・契約に関するWiki本文は現実世界の履歴として保持する。『卒業生はいない』という依頼の架空世界へは適用しない。
