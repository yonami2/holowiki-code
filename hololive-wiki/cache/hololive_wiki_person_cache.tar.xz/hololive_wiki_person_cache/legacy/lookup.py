#!/usr/bin/env python3
"""Offline lookup into the combined hololive Wiki cache."""

from __future__ import annotations

import argparse
import gzip
import json
from pathlib import Path

DATA = Path(__file__).resolve().parent / "data"


def load(path: Path):
    if str(path).endswith(".gz"):
        with gzip.open(path, "rt", encoding="utf-8") as file:
            return json.load(file)
    return json.loads(path.read_text(encoding="utf-8"))


def load_optional_snapshot(ref):
    relative = ref.get("relative_path")
    if not relative or not (DATA / relative).is_file():
        return None
    return load(DATA / relative)


def index():
    return load(DATA / "index.json")


def resolve(name: str, archive: dict):
    exact = [p for p in archive["people"] if name in
             (p["name"], p["slug"], *p.get("aliases", []))]
    if len(exact) == 1:
        return exact[0]
    if len(exact) > 1:
        raise ValueError("Ambiguous name; use a full name or slug: " +
                         ", ".join(p["name"] for p in exact))
    candidates = [p for p in archive["people"]
                  if name.casefold() in p["name"].casefold() or name.casefold() in p["slug"]]
    if len(candidates) == 1:
        return candidates[0]
    if candidates:
        raise ValueError("Ambiguous name; use a full name or slug: " +
                         ", ".join(p["name"] for p in candidates))
    raise ValueError("No matching person: " + name)


def text_pages(person: dict):
    if person["primary_cache"]:
        p = load(DATA / person["primary_cache"]["talent_file"])
        t = load(DATA / person["primary_cache"]["titles_file"])
        own_urls = set()
        for rec in (p, t):
            for obj in rec.values():
                if isinstance(obj, dict) and "sections" in obj and "url" in obj:
                    own_urls.add(obj["url"])
                    yield obj, "jp_compact"
        # Preserve additional event and project pages from earlier research.
        for page in newest_snapshots(person["pages"]):
            if page["url"] not in own_urls:
                raw = load_optional_snapshot(page)
                if raw is not None:
                    yield raw, "reader_raw"
    else:
        for page in newest_snapshots(person["pages"]):
            raw = load_optional_snapshot(page)
            if raw is not None:
                yield raw, "reader_raw"
    for page in newest_snapshots(person.get("shared_related_pages", [])):
        raw = load_optional_snapshot(page)
        if raw is not None:
            yield raw, "reader_raw"


def newest_snapshots(pages):
    newest = {}
    for p in pages:
        key = p["url_key"]
        quality = (p["audit"]["status"] == "structure_checked",
                   p.get("fetched_at") or "", p.get("parsed_at") or "")
        incumbent = newest.get(key)
        incumbent_quality = ((incumbent["audit"]["status"] == "structure_checked",
                              incumbent.get("fetched_at") or "", incumbent.get("parsed_at") or "")
                             if incumbent else None)
        if incumbent is None or quality > incumbent_quality:
            newest[key] = p
    return sorted(newest.values(), key=lambda p:p["title"])


def lines_of(page, kind):
    if kind == "reader_raw":
        for item in page["lines"]:
            yield item.get("line"), item.get("text", "")
    else:
        n = 0
        for line in page.get("preamble", []):
            n += 1
            yield n, line
        for section in page.get("sections", []):
            n += 1
            yield n, "#" * section["level"] + " " + section["heading"]
            for line in section.get("body", []):
                n += 1
                yield n, line


def main_lines(person):
    pages = ((page, kind) for page, kind in text_pages(person)
             if page.get("title", page.get("article_title")) == person["name"])
    return next(pages, None)


def show(person):
    print(f"{person['name']} | {person['region']} | {person['generation']}")
    print("世界設定: 卒業生はいない。Wikiの現実の活動区分は物語へ適用しない。")
    print(f"cache={person['collection_status']} pages={person['cached_page_count']} "
          f"machine={person['structural_audit']} model_full_read={person['model_full_read']}")
    if person.get("coverage_note"):
        print("資料注記: " + person["coverage_note"])
    if not (DATA / "raw_pages").is_dir():
        print("原記事の全文は添付せず、出典と監査記録を索引に保存しています。")
    card = person.get("primary_cache", {}).get("card_file") or person.get("card_file")
    if card:
        print("\n" + (DATA/card).read_text(encoding="utf-8"))
    else:
        print("人物記事がありません。")


def search(person, term, limit):
    total = 0
    for page, kind in text_pages(person):
        title = page.get("title", page.get("article_title", ""))
        for n, line in lines_of(page, kind):
            if term.casefold() in line.casefold():
                print(f"{title}:{n}: {line[:450]}")
                total += 1
                if total >= limit:
                    print(f"表示上限 {limit} 件。全件は --limit を増やしてください。")
                    return
    # Compact distribution bundles carry cited summaries/cards but omit newly
    # downloaded full-article JSON. Their author-provided JP archive stays intact.
    for field in ("card_file", "supplement_file", "card_json_file"):
        relative = person.get(field) or person.get("primary_cache", {}).get(field)
        if not relative or not (DATA / relative).is_file():
            continue
        path = DATA / relative
        if path.suffix == ".md":
            lines = path.read_text(encoding="utf-8").splitlines()
        else:
            lines = json.dumps(load(path), ensure_ascii=False, indent=2).splitlines()
        for n, line in enumerate(lines, 1):
            if term.casefold() in line.casefold():
                print(f"{path.name}:{n}: {line[:450]}")
                total += 1
                if total >= limit:
                    print(f"表示上限 {limit} 件。全件は --limit を増やしてください。")
                    return
    print(f"表示 {total} 件")


def names(person, query, include_empty=False):
    if person.get("nickname_file"):
        records = load(DATA / person["nickname_file"])["records"]
    elif person["region"] == "JP" and person["primary_cache"]:
        records = load(DATA / person["primary_cache"]["talent_file"]).get("nicknames", [])
    else:
        records = []
    print("calls=本人→相手、called_by=相手→本人。空欄は資料に記載なし。")
    shown = 0
    for n in records:
        if not include_empty and not (n.get("calls") or n.get("called_by")):
            continue
        if not query or query.casefold() in n.get("counterpart", "").casefold():
            print(f"{n.get('counterpart', '')}: 呼び方={n.get('calls', '')}; "
                  f"呼ばれ方={n.get('called_by', '')}")
            shown += 1
    if not records:
        print("呼称レコードなし。")
    elif shown == 0:
        print("該当する呼称記録なし。--all で未記載行も表示できます。")


def sources(person):
    if person.get("primary_sources"):
        print("JP構造化アーカイブの元ソース:")
        for s in person["primary_sources"]:
            print(f"{s['title']} | {s['fetched_at']} | {s['html_sha256']} | {s['url']}")
    if person["pages"]:
        print("reader生JSONスナップショット:")
        for p in person["pages"]:
            print(f"{p['title']} | {p['fetched_at']} | {p['html_sha256']} | "
                  f"{p['audit']['status']} | {p['url']}")
    if person.get("shared_related_pages"):
        print("関連する共有記事:")
        for p in person["shared_related_pages"]:
            print(f"{p['title']} | {p['fetched_at']} | {p['audit']['status']} | {p['url']}")


if __name__ == "__main__":
    ap = argparse.ArgumentParser(description=__doc__)
    subs = ap.add_subparsers(dest="cmd", required=True)
    ls = subs.add_parser("list", help="People and acquisition state")
    ls.add_argument("--region", choices=["JP", "EN", "ID"])
    for name in ("show", "find", "nicknames", "sources"):
        p = subs.add_parser(name)
        p.add_argument("person")
        if name == "find":
            p.add_argument("term")
            p.add_argument("--limit", type=int, default=25)
        if name == "nicknames":
            p.add_argument("--query")
            p.add_argument("--all", action="store_true", help="空欄の呼称行も表示")
    args = ap.parse_args()
    archive = index()
    if args.cmd == "list":
        for p in archive["people"]:
            if not args.region or args.region == p["region"]:
                print(f"{p['region']}\t{p['name']}\t{p['cached_page_count']}\t{p['collection_status']}")
    else:
        person = resolve(args.person, archive)
        if args.cmd == "show":
            show(person)
        elif args.cmd == "find":
            search(person, args.term, args.limit)
        elif args.cmd == "nicknames":
            names(person, args.query, args.all)
        elif args.cmd == "sources":
            sources(person)
