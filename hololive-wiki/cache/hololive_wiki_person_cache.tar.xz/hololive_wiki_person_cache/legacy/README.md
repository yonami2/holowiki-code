# ホロライブ人物別Wikiキャッシュ（JP / EN / ID）

Seesaaの[ホロライブ非公式Wiki](https://seesaawiki.jp/hololivetv/)から取得した人物記事を、同じ人物が再登場した際に名前からすぐ開けるようにしたオフライン資料です。2026年9月22日に取得した複数のスナップショットを保存しています。キャッシュは公開資料の複製であり、今回の架空世界では**卒業生が一人もいない**という会話内設定で解釈します。Wikiの現実世界での活動区分は、人物を名簿から除外する根拠にしません。

## 使い方

```bash
python3 lookup.py list                    # 名前と取得状態
python3 lookup.py list --region EN        # 地域別
python3 lookup.py show 紫咲シオン           # 人物カードと資料一覧
python3 lookup.py show Gawr_Gura          # 英名は slug または本名
python3 lookup.py find 宝鐘マリン シオン --limit 20
python3 lookup.py nicknames Gawr_Gura --query Murasaki
python3 lookup.py sources 熱千めら          # URL、取得時刻、元HTMLハッシュ
```

JPの先行45名は `data/jp/index.json` を入口に、`data/jp/cards` → `digests` → `talents/*.json` と `titles/*.json` へ進めます。共通関係・衣装・呼称は `data/jp/shared/` と `data/jp/nicknames.json` にあります。EN/IDと追加JPには `data/people/<slug>/card.md`、`profile.json`、`nicknames.json` がある範囲で保存されています。新規取得したWiki全文の生JSON・HTMLは配布アーカイブに含めません。`lookup.py find` はJP45の元キャッシュ本文または他の人物の根拠つきカード・要約JSONをオフライン検索します。元Wiki記事のURL・行数・元HTMLハッシュは `lookup.py sources` で参照できます。

呼称レコードは **`calls` が本人→相手、`called_by` が相手→本人** です。空欄から呼称や交流の不存在を推論しません。双方向に呼称があるだけで「親密」とも断定しません。資料へ書かれた用例の相手・時点・取り消し線・脚注を必要に応じて原文で確認してください。

## 範囲と確認の段階

`data/index.json` の `people[]` はJP・EN・ID人物を名前で引き、`main_article_coverage` は個人記事の有無を示します。もとのJP45名に加えて、JPの追加7名（旧記事3名、発表済みで初配信前のアソビ★まわり隊！4名）、EN20名、ID9名を対象とし、人見クリスは名簿上の**個人記事未掲載スタブ**として記録します。Wikiの1期生ページ脚注に個人記事作成禁止との記載があり、記事があると装って人物像を創作しません。

ユーザー提供のJP45名アーカイブは人物別637記事と共通7記事の計644記事を収録しています。新規・以前取得した全地域のraw索引には別スナップショットも含まれ、同一URLがJPの644記事と重なります。このため双方の件数を足した値は一意の記事数ではありません。raw索引は記事の出典と監査段階を残し、配布版にはその全文を収録しません。

| 段階 | この資料で示せること |
| --- | --- |
| 記事取得 | URLと取得時刻・元HTMLハッシュを持つページを保存したこと |
| 機械監査 | 行数・表数・置換文字・閉じタグなどをプログラムで検査したこと |
| モデル全文読了 | 各ページ末尾まで本文・表・脚注を実際に理解し、個別に読了した証跡があること |

最初の2段階だけから「モデル全文読了」とは推定しません。全資料を読んだ前提の質問では、該当人物の全文レコードと必要な共通ページを実際に読み、`model_full_read` の状態を別途記録します。カードは検索入口であり、全文の代用品ではありません。JPの原HTMLは添付アーカイブに含まれませんが、同梱構造化記事には本文行・表の矩形・脚注・各ページの出典が収録されています。

重複するURLは取得時刻と元HTMLのSHA-256を残した別版として扱います。共通表を読み込む記事はページ側の最終更新時刻が同じでも表示本文が変わり得るため、版を照合する際は本文・HTMLのハッシュを優先します。`source_inputs` は元の入力群における相対パスで、配布版では全文の `relative_path` をnullにしてあります。ユーザー世界と実際のSeesaaの所属表記が違う場合でも、出典の原文は書き換えません。

## 確認が必要な箇所

- 発表済みのアソビ★まわり隊！4名は初配信前です。各人の約3,196行の歌唱ページはホロライブ全体表を流用しており、本人が歌唱した実績とはみなしません。
- 赤井はあと、戌神ころねの【動画一覧】には、現行Wiki元HTMLの `&#65533;` に由来するU+FFFDが各2字あります。該当する動画タイトルを推測で修復しないでください。
- フォルダの存在だけで対象人物のすべてのユニット・年別・関連ページを網羅したとは主張しません。追加ページは `raw_snapshots[]` に出典を残し、関係性を扱う際は共有ページも参照します。JP45名の元カード／ダイジェストには現実の活動終了・卒業等の文言が残る箇所があり、この架空世界の所属へ転写しません。

## 再構築

`build_cache.py` はユーザー添付のJP45名データと、ローカルのリーダー出力JSON群から再生成します。元の研究ディレクトリが手元にあるときの例です。生成済みのパッケージを使うだけなら再実行は不要です。

```bash
python3 build_cache.py \
  --research-path /path/to/old/research \
  --research-path /path/to/new/en_profiles/people \
  --research-path /path/to/new/en_profiles/related \
  --research-path /path/to/new/id_profiles \
  --research-path /path/to/new/jp_archive \
  --roster-extra roster_extra.json \
  --supplement-index /path/to/new/en_profiles/index.json \
  --supplement-index /path/to/new/id_profiles/index.json \
  --supplement-index /path/to/new/jp_archive/asobi/index.json
```

`MANIFEST.sha256` は最終構築後に全配布ファイルから計算します。添付された元アーカイブとこの統合成果物のハッシュは異なります。

`vendor/jp_reader/` に、ユーザーから提供されたJP45名キャッシュのリーダーと元のテストコードを保管しています。`vendor/jp_reader/data` は配布内の `data/jp` への相対リンクで、データ本体は一度だけ入っています。`hololive_profile_cache.py show 宝鐘マリン` はオフラインで使えます。元アーカイブに作業用 `.work/inventory.json` が含まれていないため、元の `verify` コマンドはこの配布ファイルだけでは再実行できません。`UPLOADED_MANIFEST.txt` は元の198ファイルの検査記録であり、この再構成パッケージ用の `MANIFEST.sha256` と対象が違います。

`data/audits/` には取得時のページ監査、人物別読了台帳、出典行照合結果を保存します。`scripts/evidence_refs_check.py` は元の記事JSONがある作業環境で再実行する検査コードであり、この軽量配布版には今回新規取得した記事全文を同梱していません。
