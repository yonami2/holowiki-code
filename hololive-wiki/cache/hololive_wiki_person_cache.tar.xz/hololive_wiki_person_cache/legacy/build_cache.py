#!/usr/bin/env python3
"""Build a portable, provenance-aware JP/EN/ID page cache from local extracts.

The source article records are kept verbatim inside gzip containers.  The generated
index is an access aid: it never certifies that a model has read an article.
"""

from __future__ import annotations

import argparse
from collections import defaultdict
import gzip
import hashlib
import json
from pathlib import Path
import shutil
from urllib.parse import unquote_to_bytes, urlsplit

HERE = Path(__file__).resolve().parent
DATA = HERE / "data"
JP_SRC = HERE.parent / "cache_reconcile" / "upload_jp" / "data"

EN_ROSTER = (
    ("Mori Calliope", "myth"),
    ("Takanashi Kiara", "myth"),
    ("Ninomae Ina'nis", "myth"),
    ("Gawr Gura", "myth"),
    ("Watson Amelia", "myth"),
    ("IRyS", "hope"),
    ("Ceres Fauna", "council"),
    ("Ouro Kronii", "council"),
    ("Nanashi Mumei", "council"),
    ("Hakos Baelz", "council"),
    ("Tsukumo Sana", "council"),
    ("Shiori Novella", "advent"),
    ("Koseki Bijou", "advent"),
    ("Nerissa Ravencroft", "advent"),
    ("Fuwawa Abyssgard", "advent"),
    ("Mococo Abyssgard", "advent"),
    ("Elizabeth Rose Bloodflame", "justice"),
    ("Gigi Murin", "justice"),
    ("Cecilia Immergreen", "justice"),
    ("Raora Panthera", "justice"),
)

ID_ROSTER = (
    ("Ayunda Risu", "id1"),
    ("Moona Hoshinova", "id1"),
    ("Airani Iofifteen", "id1"),
    ("Kureiji Ollie", "id2"),
    ("Anya Melfissa", "id2"),
    ("Pavolia Reine", "id2"),
    ("Vestia Zeta", "id3"),
    ("Kaela Kovalskia", "id3"),
    ("Kobo Kanaeru", "id3"),
)


def slug_for(name: str) -> str:
    import re
    if name == "Ninomae Ina'nis":
        return "ninomae_inanis"
    return re.sub(r"[^a-z0-9]+", "_", name.lower()).strip("_")


def url_key(url: str) -> str:
    parts = urlsplit(url)
    rawpath = unquote_to_bytes(parts.path).lower()
    return f"{parts.netloc.lower()}:{rawpath.hex()}"


def page_owner(title: str, names: dict[str, str]) -> str | None:
    for name in sorted(names, key=len, reverse=True):
        if (title == name or title.startswith(name + "【") or
                title.startswith(name + "の歩み") or
                (title.startswith(name + " ") and " / " not in title)):
            return names[name]
    return None


def shared_owners(title: str, people: dict[str, dict]) -> list[str]:
    """Link explicitly shared documents without pretending to assign sole authorship."""
    if title.startswith("FUWAMOCO"):
        return [slug for slug in ("fuwawa_abyssgard", "mococo_abyssgard") if slug in people]
    if title == "Takanashi Kiara / Ninomae Ina'nis 1st Concert \"Drawn to Dawn\"":
        return [slug for slug in ("takanashi_kiara", "ninomae_inanis") if slug in people]
    if title in ("Myth", "Council", "Promise", "Advent", "Justice"):
        cohorts = {"Myth": {"myth"}, "Council": {"council"},
                   "Promise": {"council", "hope"}, "Advent": {"advent"},
                   "Justice": {"justice"}}
        return [slug for slug,p in people.items() if p["region"] == "EN" and
                p["generation"] in cohorts[title]]
    if title in ("ホロライブEnglish", "ホロライブEN【関連語】"):
        return [slug for slug,p in people.items() if p["region"] == "EN"]
    if title == "hololive English 1st Concert - Connect the World -":
        return [slug for slug,p in people.items() if p["region"] == "EN" and
                (p["generation"] in ("myth", "hope") or
                 (p["generation"] == "council" and p["name"] != "Tsukumo Sana"))]
    if title == "アソビ★まわり隊！":
        return [slug for slug,p in people.items() if p["generation"] == "アソビ★まわり隊！"]
    if title.startswith(("ホロライブインドネシア", "hololive Indonesia", "ホロライブID")):
        return [slug for slug,p in people.items() if p["region"] == "ID"]
    for prefix, generation in (("ID1期生", "id1"), ("ID2期生", "id2"), ("ID3期生", "id3")):
        if title.startswith(prefix):
            return [slug for slug,p in people.items() if p["region"] == "ID" and p["generation"] == generation]
    return []


def audit_raw(doc: dict) -> dict:
    line_total = doc.get("total_lines")
    table_total = doc.get("total_tables")
    reasons = []
    if line_total is None or line_total != doc.get("returned_lines"):
        reasons.append("incomplete_lines")
    if table_total is None or table_total != doc.get("returned_tables"):
        reasons.append("incomplete_tables")
    if doc.get("decode_lossy"):
        reasons.append("lossy_decode")
    if doc.get("article_replacement_characters"):
        reasons.append("article_replacement")
    if doc.get("structured_replacement_characters"):
        reasons.append("structured_replacement")
    if doc.get("article_state") != "content":
        reasons.append("article_state")
    if not (doc.get("article_integrity") or {}).get("closing_tag_observed"):
        reasons.append("article_container_unclosed")
    return {"status": "structure_checked" if not reasons else "needs_review",
            "reasons": reasons,
            "lines": line_total, "tables": table_total,
            "footnotes": len(doc.get("footnotes") or []),
            "model_full_read": "undocumented"}


def load_extras(path: Path | None) -> list[dict]:
    if not path:
        return []
    data = json.loads(path.read_text(encoding="utf-8"))
    assert isinstance(data, list)
    for p in data:
        if not all(k in p for k in ("name", "region", "slug")):
            raise ValueError(f"extra roster record missing name/region/slug: {p}")
    return data


def import_supplements(paths: list[Path], people: dict[str, dict]) -> list[dict]:
    """Copy colleague-authored person cards/profiles without changing raw records."""
    imported = []
    for index_path in paths:
        manifest = json.loads(index_path.read_text(encoding="utf-8"))
        entries = (manifest.get("talents") or manifest.get("persons") or
                   manifest.get("people") or manifest.get("roster") or [])
        if not entries and "person_summaries" in manifest:
            entries = [{"slug": slug, "profile_file": f"cards/{slug}.json",
                        "card_file": f"cards/{slug}.md"}
                       for slug in manifest["person_summaries"]]
        for entry in entries:
            slug = entry.get("slug")
            if slug not in people:
                imported.append({"slug": slug, "status": "no_named_roster_entry"})
                continue
            person = people[slug]
            supplement = entry.get("profile_file") or entry.get("card") or entry.get("profile_json")
            card_md = (entry.get("card_file") or entry.get("markdown_card") or
                       (f"cards/{slug}.md" if (index_path.parent / "cards" / f"{slug}.md").exists()
                        else None))
            card_json = (entry.get("card") or entry.get("card_json") or
                         (f"cards/{slug}.json" if (index_path.parent / "cards" / f"{slug}.json").exists()
                          else None))
            pairs = ((supplement,
                      "supplement_file", "profile.json"),
                     (card_md, "card_file", "card.md"),
                     (card_json, "card_json_file", "card.json"))
            for source_rel, dst_key, dst_name in pairs:
                if not source_rel:
                    continue
                source = index_path.parent / source_rel
                if not source.exists():
                    imported.append({"slug": slug, "status": "missing_file", "path": str(source)})
                    continue
                dst = DATA / "people" / slug / dst_name
                dst.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(source, dst)
                person[dst_key] = str(dst.relative_to(DATA))
            imported.append({"slug": slug, "status": "imported", "source_index": str(index_path)})
    return imported


def import_audits(paths: list[Path]) -> list[dict]:
    """Keep the provenance and model-reading ledger beside the portable index."""
    manifest = []
    target_dir = DATA / "audits"
    target_dir.mkdir(parents=True, exist_ok=True)
    for source in paths:
        if not source.exists() or not source.is_file():
            manifest.append({"source": str(source), "status": "not_available_at_build"})
            continue
        try:
            label = str(source.resolve().relative_to(HERE.parent.parent)).replace("/", "__")
        except ValueError:
            label = source.name
        dst = target_dir / label
        shutil.copy2(source, dst)
        manifest.append({"source_label": label,
                         "sha256": hashlib.sha256(dst.read_bytes()).hexdigest(),
                         "relative_path": str(dst.relative_to(DATA)), "status": "copied"})
    return manifest


def import_vendor() -> dict:
    """Include the reader and profile-cache source from the user-supplied archive."""
    src = HERE.parent / "cache_reconcile" / "upload_jp"
    dst = HERE / "vendor" / "jp_reader"
    if not src.exists() and dst.exists():
        return {"source": "packaged_original_vendor", "reader_version": "3.8.3",
                "files": [str(p.relative_to(HERE)) for p in dst.glob("*.py")],
                "data_link": str((dst/"data").relative_to(HERE))}
    dst.mkdir(parents=True, exist_ok=True)
    copied = []
    for file in ("hololive_profile_cache.py", "hololive_wiki_reader_v31.py", "README.md"):
        shutil.copy2(src / file, dst / file)
        copied.append(str((dst/file).relative_to(HERE)))
    shutil.copytree(src / "tests", dst / "tests", dirs_exist_ok=True)
    copied.extend(str(p.relative_to(HERE)) for p in (dst/"tests").glob("*.py"))
    attached_manifest = HERE.parent.parent / "upload" / "MANIFEST.txt"
    if attached_manifest.exists():
        shutil.copy2(attached_manifest, dst/"UPLOADED_MANIFEST.txt")
        copied.append(str((dst/"UPLOADED_MANIFEST.txt").relative_to(HERE)))
    link = dst / "data"
    if not link.exists() and not link.is_symlink():
        link.symlink_to("../../data/jp", target_is_directory=True)
    return {"source": "user_supplied_git_archive_9297d2f", "reader_version": "3.8.3",
            "files": copied, "data_link": str(link.relative_to(HERE)),
            "note": "Source build/verify needs the archive's omitted .work input; show is offline-ready."}


def build(args: argparse.Namespace) -> dict:
    if not (JP_SRC / "index.json").exists() and not (DATA / "jp" / "index.json").exists():
        raise FileNotFoundError("The verified JP data archive must be extracted first")
    if not (DATA / "jp" / "index.json").exists():
        shutil.copytree(JP_SRC, DATA / "jp", dirs_exist_ok=True)
    jp_index = json.loads((DATA / "jp" / "index.json").read_text(encoding="utf-8"))
    people: dict[str, dict] = {}
    for person in jp_index["talents"]:
        people[person["slug"]] = {
            "slug": person["slug"], "name": person["name"], "region": "JP",
            "generation": person["generation"], "aliases": person["aliases"],
            "primary_cache": {k: "jp/" + person[k] for k in
                              ("card_file", "digest_file", "talent_file", "titles_file")},
            "cached_page_count": person["pages"],
            "cached_article_lines": person["lines"],
            "structural_audit": "independently_checked_from_compacted_records",
            "model_full_read": "undocumented",
            "pages": [], "shared_related_pages": [], "needs_review": [],
        }
    for region, roster in (("EN", EN_ROSTER), ("ID", ID_ROSTER)):
        for name, cohort in roster:
            slug = slug_for(name)
            if slug in people:
                raise ValueError(f"slug collision: {slug}")
            people[slug] = {
                "slug": slug, "name": name, "region": region, "generation": cohort,
                "aliases": [], "primary_cache": {}, "cached_page_count": 0,
                "cached_article_lines": 0, "structural_audit": "pending",
                "model_full_read": "undocumented", "pages": [],
                "shared_related_pages": [], "needs_review": [],
            }
    for p in load_extras(args.roster_extra):
        if p["slug"] in people:
            raise ValueError(f"extra roster slug collision: {p['slug']}")
        people[p["slug"]] = {
            "slug": p["slug"], "name": p["name"], "region": p["region"],
            "generation": p.get("generation", "unknown"),
            "aliases": p.get("aliases", []), "primary_cache": {},
            "cached_page_count": 0, "cached_article_lines": 0,
            "structural_audit": "pending", "model_full_read": "undocumented",
            "pages": [], "shared_related_pages": [], "needs_review": [],
            "coverage_note": p.get("coverage_note"),
            "record_type": p.get("record_type", "article_expected"),
        }
    name_to_slug = {entry["name"]: slug for slug, entry in people.items()}
    if len(name_to_slug) != len(people):
        raise ValueError("Duplicate exact talent name in roster")

    candidates: dict[tuple[str, str], dict] = {}
    parse_errors = []
    for root in args.research_path:
        root = root.resolve()
        if not root.is_dir():
            parse_errors.append({"root": str(root), "reason": "missing_directory"})
            continue
        for path in root.rglob("*.json"):
            # Raw reader output has the full text, structural totals, and a source URL.
            if not {"pages", "asobi", "legacy", "related", "repairs", "raw", "wiki", "refetched_titles"}.intersection(path.parts):
                continue
            try:
                doc = json.loads(path.read_text(encoding="utf-8"))
            except (UnicodeError, ValueError, OSError) as exc:
                if "pages" in path.parts:
                    parse_errors.append({"path": str(path), "reason": str(exc)[:180]})
                continue
            if not isinstance(doc, dict) or not all(k in doc for k in
                                                    ("url", "article_title", "lines", "html_sha256")):
                continue
            variant = hashlib.sha256(json.dumps(
                (doc.get("lines"), doc.get("tables"), doc.get("footnotes")),
                ensure_ascii=False, separators=(",", ":")).encode("utf-8")).hexdigest()
            key = (url_key(doc["url"]), doc["html_sha256"], variant)
            try:
                root_label = str(root.relative_to(HERE.parent.parent))
            except ValueError:
                root_label = root.name
            src = {"collection": root_label,
                   "category": "prior_research" if root_label == "research" else "new_research",
                   "path_within_collection": str(path.relative_to(root))}
            if key in candidates:
                candidates[key]["source_inputs"].append(src)
                continue
            # Retaining hundreds of full articles here would use gigabytes as
            # the late-added index/list pages can each be several megabytes.
            candidates[key] = {"path": path, "source_inputs": [src]}

    rawdir = DATA / "raw_pages"
    rawdir.mkdir(parents=True, exist_ok=True)
    snapshots = []
    nickname_records: dict[str, dict[tuple[str, str, str], dict]] = defaultdict(dict)
    for (canonical, html_sha, variant), value in sorted(candidates.items()):
        doc = json.loads(value["path"].read_text(encoding="utf-8"))
        full_id = hashlib.sha256((canonical + "\x00" + html_sha + "\x00" + variant).encode()).hexdigest()
        subdir = rawdir / full_id[:2]
        path = subdir / f"{full_id}.json.gz"
        if args.keep_full_raw and not path.exists():
            subdir.mkdir(parents=True, exist_ok=True)
            payload = json.dumps(doc, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
            with path.open("wb") as out:
                with gzip.GzipFile(fileobj=out, mode="wb", filename="", compresslevel=6, mtime=0) as z:
                    z.write(payload)
        audit = audit_raw(doc)
        owner = page_owner(doc["article_title"], name_to_slug)
        shared = shared_owners(doc["article_title"], people) if owner is None else []
        ref = {
            "title": doc["article_title"], "url": doc["url"],
            "url_key": canonical, "html_sha256": html_sha,
            "parse_variant_sha256": variant,
            "fetched_at": doc.get("fetched_at"), "parsed_at": doc.get("parsed_at"),
            "source": doc.get("source"), "source_inputs": value["source_inputs"],
            "relative_path": str(path.relative_to(DATA)) if args.keep_full_raw else None,
            "audit": audit,
            "owner_slug": owner, "shared_with_slugs": shared,
        }
        snapshots.append(ref)
        for slug in shared:
            people[slug]["shared_related_pages"].append(ref)
        if owner is not None:
            people[owner]["pages"].append(ref)
            if audit["status"] != "structure_checked":
                people[owner]["needs_review"].append({"title": doc["article_title"],
                                                       "reasons": audit["reasons"]})
            for record in doc.get("nicknames") or []:
                if not isinstance(record, dict):
                    continue
                triple = tuple(str(record.get(k) or "") for k in
                               ("counterpart", "calls", "called_by"))
                if not any(triple) or ("呼び方" in triple[1] and "→" in triple[1]):
                    continue
                if "呼ばれ方" in triple[2] and "←" in triple[2]:
                    continue
                nickname_records[owner].setdefault(triple, {
                    "counterpart": triple[0], "calls": triple[1],
                    "called_by": triple[2], "source_title": doc["article_title"],
                    "source_url": doc["url"],
                    "direction": "calls=本人→相手; called_by=相手→本人",
                })

    # The JP archive contains 637 independent source records and seven shared pages.
    jp_missing = []
    jp_bad = []
    for person in jp_index["talents"]:
        slug = person["slug"]
        record = json.loads((DATA / "jp" / person["talent_file"]).read_text(encoding="utf-8"))
        titles = json.loads((DATA / "jp" / person["titles_file"]).read_text(encoding="utf-8"))
        sources = record.get("sources") or []
        if len(sources) != person["pages"]:
            jp_missing.append({"slug": slug, "index_pages": person["pages"], "source_pages": len(sources)})
        if '\ufffd' in json.dumps(record, ensure_ascii=False):
            jp_bad.append({"slug": slug, "file": person["talent_file"], "reason": "U+FFFD"})
        if '\ufffd' in json.dumps(titles, ensure_ascii=False):
            jp_bad.append({"slug": slug, "file": person["titles_file"], "reason": "U+FFFD"})
        people[slug]["primary_sources"] = sources
        people[slug]["needs_review"].extend(x for x in jp_bad if x["slug"] == slug)

    for person in people.values():
        person["pages"].sort(key=lambda r: (r["title"], r["fetched_at"] or ""))
        if person["region"] != "JP" or not person["primary_cache"]:
            cached = list(nickname_records[person["slug"]].values())
            cached.sort(key=lambda r: (r["counterpart"], r["calls"], r["called_by"]))
            card_dir = DATA / "people" / person["slug"]
            card_dir.mkdir(parents=True, exist_ok=True)
            (card_dir / "nicknames.json").write_text(json.dumps({
                "name": person["name"], "count": len(cached),
                "direction": "calls=本人→相手; called_by=相手→本人",
                "records": cached,
            }, ensure_ascii=False, indent=2), encoding="utf-8")
            person["nickname_file"] = str((card_dir / "nicknames.json").relative_to(DATA))
            person["nickname_record_count"] = len(cached)
            card = [f"# {person['name']}", "", f"地域: {person['region']}",
                    f"区分: {person['generation']}",
                    "", "## 記事の取得状況", "",
                    f"取得記事: {len({p['url_key'] for p in person['pages']})} URL",
                    "構造検査とモデル全文読了は別です。", "",
                    "## 呼称の向き（Wiki表の転記）", "",
                    "本人→相手が『呼び方』、相手→本人が『呼ばれ方』。", ""]
            written = [n for n in cached if n["calls"] or n["called_by"]]
            for nick in written[:16]:
                card.append(f"- {nick['counterpart']}: 本人→相手『{nick['calls']}』／相手→本人『{nick['called_by']}』")
            if len(written)>16:
                card.append(f"- 続き {len(written)-16}件は nicknames.json（未記載行も保存）")
            card.extend(["", "## 参照記事", ""])
            for p in person["pages"]:
                card.append(f"- {p['title']} — {p['audit']['lines']}行 — {p['url']}")
            (card_dir / "card.md").write_text("\n".join(card)+"\n", encoding="utf-8")
            person["card_file"] = str((card_dir / "card.md").relative_to(DATA))
        if person["region"] != "JP" or not person["primary_cache"]:
            chosen = {}
            for page in person["pages"]:
                old = chosen.get(page["url_key"])
                rank = (page["audit"]["status"] == "structure_checked",
                        page.get("fetched_at") or "", page.get("parsed_at") or "")
                old_rank = ((old["audit"]["status"] == "structure_checked",
                             old.get("fetched_at") or "", old.get("parsed_at") or "")
                            if old else None)
                if old is None or rank > old_rank:
                    chosen[page["url_key"]] = page
            person["cached_page_count"] = len(chosen)
            person["cached_article_lines"] = sum(p["audit"]["lines"] or 0
                                                  for p in chosen.values())
            person["structural_audit"] = (
                "structure_checked" if person["pages"] and not person["needs_review"] else
                "needs_review" if person["pages"] else "not_acquired")
        if person["region"] == "JP":
            person["collection_status"] = ("structured_cached" if person["primary_cache"] else
                                           "raw_cached" if any(p["title"] == person["name"]
                                                               for p in person["pages"])
                                           else "unpublished_person_article" if person.get("record_type") == "no_person_article"
                                           else "missing_main_page")
        else:
            person["collection_status"] = (
                "raw_cached" if any(p["title"] == person["name"] for p in person["pages"])
                else "missing_main_page")

    imported_supplements = import_supplements(args.supplement_index, people)
    imported_audits = import_audits(args.audit_file)
    vendor_reference = import_vendor()
    jp_keys = {url_key(s["url"]) for p in people.values() if p.get("primary_sources")
               for s in p["primary_sources"]}
    for shared in jp_index.get("shared", []):
        shared_obj = json.loads((DATA / "jp" / shared["file"]).read_text(encoding="utf-8"))
        jp_keys.add(url_key(shared_obj["url"]))
    raw_keys = {p["url_key"] for p in snapshots}
    missing_mains = [p["name"] for p in people.values()
                     if p.get("record_type") != "no_person_article" and
                     p["collection_status"] in ("missing_main_page", "unpublished_person_article")]
    index = {
        "schema": "hololive-research-archive/1", "source_site": "https://seesaawiki.jp/hololivetv/",
        "scope": "JP/EN/ID named roster; further published or archived names require explicit coverage entries",
        "fictional_world": {"no_graduates": True,
                            "wiki_real_world_activity_status_is_not_fictional_canon": True},
        "tiers": {"article_acquired": "source pages cached with article metadata",
                  "machine_audited": "line/table/encoding/container fields checked",
                  "model_full_read": "not inferred from acquisition or mechanical checks"},
        "baseline_roster_counts": {"JP": 45, "EN": 20, "ID": 9},
        "coverage_candidates": [
            {"group": "アソビ★まわり隊！", "names": ["熱千めら", "宙科そぴあ", "鈴鳴つづり", "百灯キョーコ"],
             "status": "published before first stream: personal facts only; generic song listings are not talent achievements"},
            {"group": "JP historical names outside uploaded 45",
             "names": ["潤羽るしあ", "桐生ココ", "魔乃アロエ", "人見クリス"],
             "status": "first three have person pages; Hitomi Chris requires no-person-article stub"}],
        "talent_count": len(people), "people": sorted(people.values(),
                                               key=lambda x: (x["region"], x["generation"], x["name"])),
        "main_article_coverage": {"expected": len(people)-1, "missing": missing_mains,
                                  "no_person_article_stub": [p["name"] for p in people.values()
                                                              if p.get("record_type") == "no_person_article"]},
        "raw_snapshots": snapshots,
        "shared_page_refs": [ref for ref in snapshots if ref["owner_slug"] is None],
        "raw_snapshots_count": len(snapshots),
        "raw_unique_urls": len(raw_keys),
        "wiki_article_url_coverage": {
            "uploaded_jp_distinct_urls": len(jp_keys),
            "raw_distinct_urls": len(raw_keys),
            "overlap_urls": len(jp_keys & raw_keys),
            "combined_distinct_urls": len(jp_keys | raw_keys),
            "note": "URL counts identify articles; multiple fetched/parsed snapshots do not create extra article URLs.",
        },
        "parse_errors": parse_errors,
        "jp_source_index_inconsistencies": jp_missing,
        "jp_replacement_alerts": jp_bad,
        "supplement_imports": imported_supplements,
        "audit_files": imported_audits,
        "vendor_reader": vendor_reference,
    }
    (DATA / "index.json").write_text(json.dumps(index, ensure_ascii=False, indent=2), encoding="utf-8")
    return index


if __name__ == "__main__":
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--research-path", type=Path, action="append", required=True,
                    help="One or more roots containing full reader JSON; repeat this option")
    ap.add_argument("--roster-extra", type=Path, help="JSON list of additional named roster entries")
    ap.add_argument("--supplement-index", type=Path, action="append", default=[],
                    help="Index containing talents[].slug/profile_file/card_file")
    ap.add_argument("--audit-file", type=Path, action="append", default=[],
                    help="Read-only audit ledger/report to include within this package")
    ap.add_argument("--keep-full-raw", action="store_true",
                    help="For internal diagnostics only; portable distribution always omits new full articles")
    a = ap.parse_args()
    report = build(a)
    print(json.dumps({k: report[k] for k in ("talent_count", "raw_snapshots_count",
                                               "raw_unique_urls", "baseline_roster_counts",
                                               "main_article_coverage", "wiki_article_url_coverage",
                                               "jp_source_index_inconsistencies", "jp_replacement_alerts")},
                     ensure_ascii=False, indent=2))
