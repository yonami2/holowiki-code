# リーダーの不具合の修正（2026-10-01）

利用者から、リーダー（3.9.0+skill.4）を調べて再現できた4系統の不具合の報告があった。前回（2026-09-30b）の「確認済みバグ0件」という判定は誤りだった。4件をすべて再現して直し、同じ種類の不具合がほかにないかを調べて、見つかった分も直した。記事本文・索引・資料パック・名前の索引・v1復元用データは変えていない。リーダーは 3.9.0+skill.5、ビルダーは 3.3.2 になった。

調べるのに使ったスクリプトは `*.py.txt`（拡張子 `.txt` を付けて保存）、直す前（skill.4）と直した後（skill.5）の出力は `results.txt` にある。

## 報告された4件（すべて再現し、直した）

1. **キャッシュの検査が、利用者の設定を無視していた**
   - 症状：`--ad-filter report` や `off`、`--max-grid-cells` を付けて保存したページが、次の実行で「無効なキャッシュ」として捨てられ、同じページを取り直していた（`PageCache.load()` が検査のためのパースを既定の設定で行っていた）。直す前は、2回目の実行も通信し（取得2回）、`from_cache` は偽だった。
   - 修正：`PageCache.load()` と `rebuild_title_index()` が `ad_filter` と `max_grid_cells` を受け取り、読み取りと同じ設定で検査する。`main()` が指定を渡す。直した後は2回目の実行は通信せず（取得1回）、キャッシュを使う。設定を渡さない呼び出しの既定は、これまでと同じ strict。
2. **`--max-bytes 9223372036854775807` で `OverflowError` のトレースバック**
   - 原因：保存したHTMLの読み取りが `stream.read(max_bytes + 1)` だった。`read(n)` は先に n バイトを確保するため、Cの添字の上限を超えると `OverflowError`、1TiB では `MemoryError` になる。
   - 修正：1MiBずつ読む `read_up_to()` に替えた。同じ読み方をしていた、gzip の解凍後の読み取り、deflate の `decompress(raw, limit + 1)`（`Py_ssize_t` を超えると `OverflowError`）、キャッシュ記録の読み取りも直した。上限そのものの判定（`page_too_large`）は変わらない。
3. **UTF-16・UTF-32のモバイル版HTMLを見分けられなかった**
   - 原因：`is_mobile_response()` が生のバイト列でASCIIの文字列（`/css/wiki/lite/`、`<link`、`&`）を探していたため、UTF-16・UTF-32では一致せず、デスクトップ版の再取得に進まなかった（EUC-JP・UTF-8では動いていた）。
   - 修正：バイト順マーク、先頭のNULバイト、またはContent-Typeの文字コードでASCIIが変わる応答は、デコードした文字列で同じ判定をする（`wide_text()`）。Content-Typeのない応答に必要な「HTMLらしい開始要素」の確認も同じ方法にした（UTF-16のBOM付きHTMLをContent-Typeなしで受けると拒否していた）。
4. **`retry_deferred` のエラーに `http_requests`・`retry_history` がなかった**
   - 症状：リダイレクト1回のあとのHTTP 429（`Retry-After: 300`）は2回の要求だが、エラーには要求回数がなく、`check-updates` は1回として数えていた。
   - 修正：`retry_deferred` に `http_requests` と `retry_history` を付けた。直した後は2回と数える（`check-updates` 側のコードは変えていない。リーダーのエラーの `http_requests` を足す作りのため）。

## 同じ種類の不具合を探して、見つけて直したもの

5. **`time_budget_exceeded` にも要求回数がなかった**（再試行の途中で通信の予算が尽きた場合）。`mobile_layout`（デスクトップ版も不完全だった場合は2回）と、取得のあとに起きる誤り（本文が空など）も、要求回数を報告しない場合があった。どれも `http_requests` を付けた。あわせて、予算が尽きていて送らなかった要求を回数に数えていた点を直した。
6. **巨大な `--timeout`・`--time-budget`**（1e10、1e300秒など）が、ソケットの設定または期限の計算で `OverflowError` になっていた。上限を10^6秒（約11.6日）にそろえた。この値は、Windowsのソケットが受け付ける上限（2^31ミリ秒＝約2.1×10^6秒。Linuxは約9×10^9秒）より小さい。最初に決めた10^8秒は、WindowsのPython（Wine上）で `OverflowError` になり、新しいテストが見つけた。
7. **桁の多い `Retry-After`**（400桁）が `Infinity` になり、エラーのJSONが不正な形式（`Infinity` はJSONにない）になっていた。同じ上限で丸めた。
8. **`<meta http-equiv>`（値のない属性）で `AttributeError` のトレースバック**：`MetaCharset` が、値のない属性を空文字列として扱っていた（HTMLParserは `None` を返す）。ファジングで見つけた。`<meta http-equiv content>` なども同様。直した。
9. **`is_mobile_response()` の正規表現が2乗の時間**：`<link a=&` のような閉じていないタグが2万個続くページで64秒かかっていた。最後の `>` より後ろには始まるタグがないので、そこまでで探索を止めるようにした（0.00秒）。20万個でも同じ。
10. **`ArticleParser._close_optional()` が2乗の時間**：`<ul><li>` を終了タグなしで2万段重ねたページで45.5秒かかっていた。見る段数を512までにした（1.4秒）。実際のページは数段しか入れ子にならない。512段より深く、終了タグのない `<p>` などを閉じる場合だけ、結果が変わりうる。
11. **`--rebuild-index` が `--ad-filter` と `--max-grid-cells` を無視していた**：1の仲間。`report` で保存したページが、`--ad-filter report` を付けた再構築で「無効な記録」とされていた。直した。
12. **長すぎる `--cache-dir`・`--index-file`**（名前が255バイトを超える）：Python 3.14より前では `Path.exists()` が `OSError` を出し、トレースバックになっていた。存在しない場合と同じに扱う（`path_exists()`）。
13. **パスの引数にNULや孤立サロゲートがある場合**（`main()` を直接呼ぶ場合。POSIXのシェルからは作れない）：`resolve()` の `ValueError`・`UnicodeEncodeError` がトレースバックになっていた。引数の誤り（終了コード2）にした。

## どう探したか

- **再現**：報告の4件を、通信を使わずに再現するスクリプト（`repro_reported.py`）にした。直す前は4件とも再現し、直した後はすべて直った。
- **同系統の探索**（`siblings.py`、`rebuild_probe.py`、`probe_one.py`）：5〜7、9〜11の再現と、処理時間の測定。時間の測定は、1つの入力ごとに別のプロセスで、時間制限をかけて行った。直す前は、20万個の `<link` で120秒の制限を超えた。
- **ミューテーション・ファジング**（`fuzz_reader.py`）：保存した実ページ81件（EUC-JP、wikiが返したまま）を切り貼りし、壊し、`<meta http-equiv>` のような値のない属性や、属性値の削除を混ぜて、ランダムなオプションで `main()` に読ませた。`main()` が決められたJSONの誤りにしない例外か、20秒を超える処理を「発見」とした。
  - 直す前（skill.4）：約89,000回で発見1件（8の `AttributeError`）。
  - 直した後（skill.5）：約102,000回（値のない属性を加えたもの。うち約38,000回は最終版）で発見0件。
- **キャッシュ記録の型を変える試験**（`cache_fuzz.py`）：記録とメタデータの全項目を、`None`・真偽値・巨大な整数・`NaN`・サロゲート・リスト・辞書などに置き換え、項目を消して、`PageCache.load` と `rebuild_title_index` に読ませた（1,058回）。例外は0件（直す前も同じ）。
- **数値オプションの極端な値**（`cli_extremes.py`）：`--start`・`--lines`・`--context`・`--timeout`・`--time-budget`・`--retries`・`--max-bytes`・`--max-grid-cells`・`--ttl` に、0・負数・2^63・10^400・`nan`・`inf` などを与えた（756回）。直す前は1件（2の `OverflowError`）、直した後は0件。
- **文字列の引数と壊れた索引**（`arg_fuzz.py`）：`--url`・`--title`・`--find`・`--section`・`--search`・`--wiki`・`--index-file`・`--output`・`--cache-dir` などに、NUL・孤立サロゲート・長い文字列・不正なURL・正規表現の記号を与え、切り詰めたり型を変えたりした索引ファイルも読ませた（1,030回）。直す前は3件（12と13）、直した後は0件。
- **通信の応答**（`net_probe.py`）：リダイレクト先、HTTPステータス、Content-Length、Content-Encoding、Content-Type、444通りの文字コード名を、擬似の応答で試した。次の5件は、直していない。
  - `Location` に孤立サロゲートを入れた擬似ヘッダー：実際のHTTP応答の見出しはISO-8859-1で読まれるため、この値にはならない。
  - 読み取り中の `ValueError`・`MemoryError`、`opener.open` の `ValueError`・`UnicodeError`：擬似の応答が直接出す例外で、`http.client` が通常出す例外（`IncompleteRead`・`OSError` など）は処理されている。実在する入力では、`--user-agent` にHTTPの見出しへ書けない文字（改行、Latin-1外の文字）を与えると `opener.open` が `ValueError` を出すが、これは `main()` が `processing_error` のJSONにして終了コード1で終わる（トレースバックにはならない。文言は例外のもの）。

## 直さなかったもの・確認できていないこと

- **実際のwikiでの確認はしていない**。今回の試験は通信を使わない（擬似の応答と、保存した実ページ）。報告者も、実際のwikiやWindowsでの確認はしていない。上の5〜13は、通常のwikiの応答では起きにくい入力（極端な値、壊れたHTML、悪意のある入力）に対する堅牢化であり、実際に起きた事例の報告はない。1・3・4は、`--ad-filter report`・`off` の利用、UTF-16の応答、再試行を伴う `check-updates` で、起こりうる。
- **Windows**：Wine上のWindows版Python（3.9.13・3.13.15）で、新しいテストとリーダー関連のテスト81件、上の探索スクリプトのすべてを実行した（`results.txt` の末尾）。この実行で、タイムアウトの上限（6）が大きすぎる誤りが見つかった。GitHub ActionsのWindowsのジョブでの確認は、キャッシュ案内の「検証」に記す。実機のWindowsでの確認はしていない。
- 512段を超える入れ子（10）と、10^6秒（約11.6日）を超える待ち時間（6・7）は、上限で打ち切る。通常の使い方には影響しない。

## 追加したテスト

`tests/test_reader_settings_and_limits.py`（29件）。直す前のコードでは、このうち23件が失敗または例外になり（残りの6件は、拒否や終了タグの省略など今までの動作が変わらないことを確かめるもの）、直した後はすべて通る。内容は次のとおり。

- キャッシュの検査の設定（`report`・`off`・`--max-grid-cells`、`--rebuild-index`、既定は strict のまま）
- 巨大な上限（`--max-bytes` 2^31〜2^63−1、gzip・deflate、キャッシュ記録、タイムアウト、`Retry-After`）と、上限を超えた場合の拒否が変わらないこと
- 8種類の文字コード（UTF-16・UTF-32を含む）のモバイル判定とデスクトップ版の再取得、Content-Typeなしの広い文字コード、HTMLでない応答の拒否
- 失敗した読み取りの要求回数（リダイレクトと429、再試行のあと、予算切れ、2回のモバイル、取得のあとの誤り、取得のない誤り）
- 値のない `http-equiv`・`charset`、入れ子の `<ul><li>` と `<link` の処理時間、終了タグの省略が今までどおり働くこと
