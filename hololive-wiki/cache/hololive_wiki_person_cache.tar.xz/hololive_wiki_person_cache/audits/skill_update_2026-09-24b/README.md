# スキル版の更新（2026-09-24b）

評価で見つかった不具合の修正と、物語用の機能追加の記録。記事本文（`pages/*.txt`）は変更していない。
数値の詳細は `verification.json` にある。

## 修正した問題

| 問題 | 修正 |
|---|---|
| Windows: 空白を含む引数が分割される（"Gawr Gura" など） | ラッパーが os.execv を使わず同じプロセスで実行する |
| Windows: Pythonが C:\Program Files にあると起動できない | 同上 |
| Windows: 一時フォルダーのパスに空白があると起動できない | 同上 |
| Windows: エラーでも終了コードが0になる | 同上（終了コードをそのまま返す） |
| Windows: 出力がコマンド終了後に届く | 同上 |
| 一時フォルダーの一部が消えると以後起動できない | 目録の全ファイルの存在を毎回確認し、欠けていれば退避して再展開 |
| 共有 /tmp で他ユーザーが置いたフォルダーのコードを実行し得る | 所有者と権限を確認し、使えなければ ~/.cache/hololive-wiki（0700）へ切り替え |
| ユーザー名を取得できない環境で起動時に停止 | UID を代わりに使う |
| lookup の出力が Windows のパイプで停止・文字化け | 標準出力・標準エラーを UTF-8 に切り替え |
| 名前の引き当てが本体と lookup で食い違う | 共通モジュール hololive_names.py と names.json に統一 |
| Xアカウント・愛称・カタカナ表記で引けない | 公式情報表の全アカウント、呼称表で1人だけを指す呼び名、かな・幅の正規化を追加 |
| START_HERE の例（Gawr Gura の語録）が存在しないページを指す | 同梱ビルダーで作り直し（episodes の例） |
| 説明文が v2 のまま | v3 に修正 |
| companion JSON の先頭に注記なしの fictional_world_no_graduates | 適用範囲つきの fictional_world_note に置換 |
| 引数なしでも展開してからエラー | 展開せずに使い方を表示 |
| 旧版の展開物（111MB）が残り続ける | 1日以上前の旧版と作業フォルダーを片付ける |
| 展開時に gzip を2回解凍 | 1回の走査で検査しながら展開 |
| カードの口癖説明が60字で途切れる・参照番号 [n] が残る | 語録ページから文末まで復元し [n] を除去 |
| 「関係が濃い相手」が親密さを過大に示す | 「呼称が双方向に記録されている相手（親密さの指標ではない）」に改名 |
| 活動状態がカードにない | wikiトップの掲載欄を status・カード・PROFILE・INDEX に表示（wikiの記録と明記） |
| 物語用途で必須の読了範囲が満たせない | story コマンド（hololive_story.py）と references/story.md の物語用読了範囲 |

## 検証

- Linux Python 3.9.23: アーカイブ内 Ran 89 tests in 1.532s OK (skipped=6) ／ スキル側 Ran 13 tests in 19.269s OK
- Linux Python 3.10.20: アーカイブ内 Ran 89 tests in 1.621s OK (skipped=6) ／ スキル側 Ran 13 tests in 20.973s OK
- Linux Python 3.11.15: アーカイブ内 Ran 89 tests in 1.548s OK (skipped=6) ／ スキル側 Ran 13 tests in 20.805s OK
- Linux Python 3.12.3: アーカイブ内 Ran 89 tests in 1.647s OK (skipped=6) ／ スキル側 Ran 13 tests in 20.808s OK
- Linux Python 3.13.12: アーカイブ内 Ran 89 tests in 1.793s OK (skipped=6) ／ スキル側 Ran 13 tests in 20.838s OK
- v1 の完全復元: 379 ファイルの SHA-256 一致（実データの往復変換テスト: Ran 1 test in 7.168s OK）
- Wine 9.0 + Python313: 15/15 項目成功
  - skill tests: Ran 13 tests in 94.727s OK (skipped=1)
  - archive tests: Ran 89 tests in 11.430s OK (skipped=1)
  - archive selftest.cmd: Ran 89 tests in 11.559s OK (skipped=1)
- Wine 9.0 + Python39: 14/14 項目成功
  - skill tests: Ran 13 tests in 81.214s OK (skipped=1)
  - archive tests: Ran 89 tests in 10.425s OK (skipped=1)
  - archive selftest.cmd: Ran 89 tests in 11.099s OK (skipped=1)

## 速さ（Linux、Python 3.13.12、4 CPU (this container)）

- 初回（検証と展開を含む）: 1.4, 1.6, 1.8 秒
- show 宝鐘マリン: 中央値 60.0 ms（出力 4,150 字）
- scene 2人: 中央値 64.8 ms（出力 9,847 字）
- story 2人: 中央値 126.4 ms（出力 15,328 字）
- story holoX 5人 --detail brief: 中央値 262.7 ms（出力 23,775 字）
- status (82名): 中央値 57.8 ms（出力 7,019 字）
- show フブちゃん（呼び名）: 中央値 61.5 ms（出力 3,206 字）
- search Ahoy: 中央値 129.1 ms（出力 2,461 字）
- verify: 中央値 189.0 ms（出力 74 字）
- lookup ししろん --summary（展開なし）: 中央値 35.9 ms

Windows 実機の結果はこのアーカイブの外（リポジトリの GitHub Actions）に記録する。
