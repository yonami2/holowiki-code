# ホロライブWiki人物キャッシュ監査

## 使用方法

```bash
python work/reader_audit/audit_corpus.py \
  --data work/reader_audit/archive/data \
  --raw-dir research \
  --raw-dir work/en_profiles/pages \
  --raw-dir work/en_profiles/extra_data/pages \
  --raw-dir work/id_profiles/pages \
  --raw-dir work/jp_archive/asobi \
  --raw-dir work/jp_archive/legacy/pages \
  --raw-dir work/jp_archive/repairs \
  --raw-dir work/jp_archive/refetched_titles/json \
  --html-dir research \
  --html-dir work/en_profiles/html \
  --html-dir work/en_profiles/extra_data/html \
  --html-dir work/id_profiles/html \
  --html-dir work/jp_archive/asobi/raw \
  --html-dir work/jp_archive/legacy/html \
  --html-dir work/jp_archive/repairs \
  --html-dir work/jp_archive/refetched_titles/html \
  --out work/reader_audit/audit_report.json
```

`--raw-dir` を再実行すると、指定した場所に保存されている解析結果JSONを
再列挙します。取得作業中に追加されたファイルも次回の実行に含まれます。
同一記事の複数スナップショットは `raw_duplicate_article_groups` に残し、
`canonical_article_issues` には警告数が最も少ない保存版だけを掲げます。
この選択は「最新」「正しい原本」の判定ではありません。
原本アーカイブ `upload/hololive_wiki_reader_v31_FULL.tar.gz` のファイルは
`upload/MANIFEST.txt` と照合しました。`sha256sum -c` は198/198件成功です。

出力の `talents[].pages[].chunks[]` は、記事の先頭から末尾までの行範囲、
本文のSHA-256、照合状態を表す目次です。`read_status` は常に
`unreviewed_by_model` です。機械的な取得・検査と、人間またはモデルの
**全文読了は異なります**。手で実際に確認した記録は別途作ってください。

## 検査すること

- JP45名の人物ページ・関連タイトルの保存レコードと`data/index.json`の対応。
- 節の `preamble`、見出し、本文行を記録上の行番号に配置し、欠落・重複・飛びを検査。
- 見出しの親子関係、URL、取得元SHA-256の書式、保存された表の矩形性。
- 脚注の本文空欄と定義の一致状況、U+FFFDと単独サロゲート。
- 既存の生解析JSONについて本文全行、全表、表の元セル参照、脚注診断。
- 保存HTMLのバイト列を独立にSHA-256で計算し、生解析JSONの記録値と比較。
- `#page-body-inner` 内だけを対象に折りたたみを数え、HTML内の14字以上の
  単一テキスト断片が抽出本文中に現れるかを点検。

## 添付アーカイブの制限

アーカイブは `git archive` 由来で、構築時の `.cache/`、`.pages/`、`.work/`
が同梱されていません。従って付属スクリプトの `verify` を同じ元データで
再実行できず、アーカイブ内 `sources[].html_sha256` を元HTMLから
独立に確認することもできません。既存 `research/` と添付側は別々のHTTP応答を
保存したものです。**HTMLのハッシュ不一致だけでは記事本文の違いを示しません**。
実際、既存の `ID2期生`、`Myth`、`秘密結社holoX Live 2026「First MISSION」`
には、HTMLハッシュが異なりながら抽出した全本文が一致する応答がありました。
逆に `0期生` と共通呼称一覧には本文差分もあります。添付人物JSONの内容が
同じかどうかは、ページごとに本文を直接比べる必要があります。

タイトル一覧系の183ページは表を本文の文字行として保持していますが、
構造化された表グリッドを人物別JSONには保存していません。一般の人物ページの
表も、行列表示は保存されるものの元セルの行・列番号などの来歴は含みません。
この差は `tables` と `table_state` に記録します。

元の `data/README.md` はU+FFFDが本文にないと説明していますが、
`赤井はあと【動画一覧】`1216行と`戌神ころね【動画一覧】`471行の
それぞれにU+FFFDが2字あります。元の `stage_verify()` は人物JSONだけを
文字置換検査し、タイトル一覧JSONを検査していませんでした。2ページを
独立に取り直して調べると、現行の元HTML自体に数値文字参照 `&#65533;`
が入っていました。読取時のバイト置換は0、`decode_lossy=false` です。
したがって添付アーカイブの作成時に復号で壊した文字ではなく、公開元の
数値文字参照の時点で失われている字です。元の文字を推測で補わず、
当該行を引用する場合は出典側に欠損があると示してください。

アーカイブ側の索引は人物ページの表6,621件を集計しています。共有7ページの
表1,472件も含めて検査すると、総数は8,093件です。21,470行の共有ページは
索引の全行数547,237に含まれています。

## 折りたたみの判定

隠し要素を数える際は記事外の共通ナビやサイドバーを除きます。
長い原文断片が見つかるのは抽出できた箇所の証拠です。見つからない場合も、
表の短いセル、短い画像説明、参照番号の挿入などがあるため直ちに欠落とは
判定しません。画像・動画の実内容もHTML文字抽出では確認できません。
例えば紫咲シオンの衣装表の折りたたみは各HTMLテキスト要素が14字未満ですが、
「通常衣装」「チャイナ風衣装」「正月衣装」は実際に抽出本文へあります。

ページ探索の対象は元スクリプトの限定サフィックスと観測されたタイトルに依存します。
目録にない未発見ページが存在しないことは、この監査から証明できません。
