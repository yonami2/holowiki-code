# ホロライブ EN Wiki 人物別キャッシュと監査記録

資料源：非公式 [ホロライブ Wiki](https://seesaawiki.jp/hololivetv/) の人物・関連記事。本文は著作権への配慮からこの説明書では再掲せず、記事 URL、位置、原文を保持した JSON を対応付けています。この創作世界では卒業した人はおらず、元 Wiki にある現実世界の活動区分を人物カードや作中時系列へ採用しません。

## 取得対象と保存先

Myth：Mori Calliope、Takanashi Kiara、Ninomae Ina'nis、Gawr Gura、Watson Amelia。

Project:HOPE / Council：IRyS、Tsukumo Sana、Ceres Fauna、Ouro Kronii、Nanashi Mumei、Hakos Baelz。

Advent：Shiori Novella、Koseki Bijou、Nerissa Ravencroft、Fuwawa Abyssgard、Mococo Abyssgard。

Justice：Elizabeth Rose Bloodflame、Gigi Murin、Cecilia Immergreen、Raora Panthera。計 **20人**。`index.json` が名前と slug の対応表です。

| ファイル | 使い方 |
|---|---|
| `cards/<slug>.md` / `.json` | 再登場時に最初に読む短い人物カード。口調、自己呼称の根拠、関係性、出典の本文行、反応の推定を区別。 |
| `people/<slug>/profile.json` | 個別 12 区分のページ名・URL・JSON・元 HTML・脚注／表検査・呼称の向きをまとめた索引。さらに観測リンクをたどって取得した個別追加記事も掲載。 |
| `people/<slug>/raw/*.json` | 原文の全抽出行 `lines`、各セルと結合セルの論理格子を含む `tables`、`footnotes`、`headings`、`nicknames` 等。 |
| `related/*.json` / `related_index.json` | 世代、EN の共通呼称、EN ライブ、FUWAMOCO の共通記事を含む共有・関係資料 17 件。 |
| `master_audit.json` | **元記事単位**の SHA-256、全文行数、全表セル、脚注、折り畳みの照合結果、例外台帳。 |
| `html_audit.json` | 全 290 原文 HTML の SHA と折り畳み内の各実質文字片の突き合わせ。 |
| `frontier_audit.json` | 292 ファイル中の観測リンクを走査。個人名で始まる記事および `FUWAMOCO【…】` のリンク先 238 題名に未取得 0。 |
| `html/`、`extra_data/html/`、`related/*.html`、`source_html_recovered/` | 保存された Wiki 原文 HTML。後者の 124 ファイルは旧研究データから原 SHA が完全一致したものを回収。 |

二度目の参照では、`index.json` から slug を得て、人物カード→`profile.json`→必要な `raw/*.json` の行・表・脚注の順に読めます。例：

```bash
python3 - <<'PY'
import json
from pathlib import Path
base = Path('work/en_profiles')
card = json.loads((base/'cards'/'fuwawa_abyssgard.json').read_text())
profile = json.loads((base/'people/fuwawa_abyssgard/profile.json').read_text())
source = json.loads((base/'people/fuwawa_abyssgard/raw/main.json').read_text())
print(card)
print(profile['related_files'])
print(source['url'])
print(source['lines'][242])  # 行番号 243 の原文と位置
PY
```

## 範囲と検査結果

本人ごとの基本 12 分類は 20 × 12 = **240 参照**。本文内のリンクから追加発見した歌唱データ・年別動画・会員データは **35 記事**。世代、共通呼称、単独ライブ、双子の共有記事などは **17 記事**。計 292 ファイル参照、共有記事の複写 2 件を除く **290 種類の原記事**を保持しています。FUWAMOCO の個別人物ページは二人それぞれ存在し、個人名の動画一覧 URL 二つは元 Wiki 上で 404 だったため、観測リンクのある共通 `FUWAMOCO【動画一覧】` を両方の動画区分に紐付けました。これは二人の声や一人称が同じという推定ではありません。

| 元記事 290 件の検査値 | 数 |
|---|---:|
| 抽出本文行（先頭から最終行までの連番を照合） | 149,984 |
| 表／物理セル／結合セルを展開した論理格子セル | 2,196／547,370／594,336 |
| 脚注定義（番号・本文・表示箇所を照合） | 1,079 |
| 元 HTML の SHA-256 と読取器の SHA 一致 | 290／290 |
| 記事領域内の折り畳み／文字を含む折り畳み | 1,023／1,002 |
| 折り畳みの実質文字片（文字列部分照合／記号だけ／不一致） | 29,508／7／0 |
| 読取器が修復した UTF-16 代理ペア参照／確認済 EUC 拡張字形単位 | 1,525／145 |
| 欠落本文・表格子参照誤り・未閉鎖記事・脚注定義欠落・復号置換 | **0** |

折り畳みの原 HTML と `lines` の照合では、Python の HTML パーサが絵文字の代理ペア参照を置換し、専用読取器は結合して保持するため、照合時に両側の記号字形だけを除外しました。照合は空白を除いた 8 文字以上の元 HTML テキスト片について行い、7 個は記号しか残らず照合対象外です。`html_audit.json` には各記事の内訳を保存しました。折り畳み部分の元の絵文字は生 HTML と JSON に残ります。

脚注には **出典 Wiki 自体の未参照定義 4 個**（`Watson Amelia【動画一覧】` の 4・5 番、`Watson Amelia【動画一覧】_2020データ` の 1・2 番）があります。欠落や書き換えをせず、原文どおり残しました。警告 329 件は主に明示的 UTF-16 代理ペア結合の通知と EUC-JIS-2004 拡張文字の診断を含みます。元記事 HTML、抽出 JSON、例外は `master_audit.json` で一記事ずつ確認できます。

## 「全文読了」の進捗の正確な区別

1. **原文取得・保存：完了。** 対象 290 記事はすべて対応する元 HTML バイト列と JSON を保持し、原 SHA を検証しました。収集したページ内リンクのうち、対象本人名または `FUWAMOCO【…】` を持つ未取得のリンク先は 0 です。
2. **機械的な全文・表・脚注・折り畳みの検査：完了。** 全行と全表セルの件数・ダイジェストを生成し、全脚注、行番号、結合表格子、原 HTML の SHA、折り畳みの主要文字片を確認。例外は上記の元 Wiki 未参照脚注だけです。
3. **モデルが 149,984 行を最後まで意味解釈して読了：未完了。** 個々の `model_full_read` は `false` と記録しています。カードは人物ページの根拠を抜粋して記述しており、記事すべてを読了したという表示ではありません。今後人物が再登場するときは当該カードから関連原文へ進み、本文の節・脚注・呼称方向を必要箇所で確認します。

元 Wiki は更新されます。`fetched_at` は各 JSON に記録してあり、創作上の 2023 年の出来事を扱う際には取得時点の後年の実績を当時の事実として逆流させないようにします。

再生成用：`fetch_en.py` と `fetch_related.py` が取得、`assemble_en.py` と `build_cards.py` が索引・カード作成、`recover_html.py`、`audit_html.py`、`audit_related.py`、`audit_all.py`、`audit_frontier.py` がソース照合を担当します。個人の `raw/` が正規保管先で、`pages/` は新規取得時の重複した作業コピーです。
