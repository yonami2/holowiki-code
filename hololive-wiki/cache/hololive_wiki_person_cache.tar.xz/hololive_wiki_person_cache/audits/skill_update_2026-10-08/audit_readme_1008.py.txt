"""audit_readme_1008.py FETCH_DIR COMPARE.json OUTDIR [FETCH2_DIR COMPARE2.json]: audits/online_2026-10-08/
(README.md, report.json, compare.json, targets.json) from the 2026-10-08 crawl of every cached page; with the second
crawl of the same day (every page read again, compared with the cache built from the first), also
report_second_pass.json and compare_second_pass.json."""
import collections, json, os, subprocess, sys
fetch, compare_path, out = sys.argv[1:4]
fetch2, compare2_path = (sys.argv[4:6] + [None, None])[:2]
here = os.path.dirname(os.path.abspath(__file__))
os.makedirs(out, exist_ok=True)
report = json.load(open(os.path.join(fetch, "report.json"), encoding="utf-8"))
targets = json.load(open(os.path.join(fetch, "targets.json"), encoding="utf-8"))
json.dump({"schema": "hololive-ad-audit-targets/1",
           "note": ("2026-10-08 の巡回対象：キャッシュに本文のある全1,149ページ（pages.jsonl から）。"
                    "cached_last_updated・cached_fetched_at は、巡回の前にキャッシュが持っていた版の値。"),
           "targets": targets["targets"]}, open(os.path.join(out, "targets.json"), "w", encoding="utf-8"),
          ensure_ascii=False, indent=1)
compact = next(path for path in (os.path.join(here, "compact_report.py"), os.path.join(here, "fetch28", "compact_report.py"))
               if os.path.isfile(path))
subprocess.run([sys.executable, "-B", compact,
                os.path.join(out, "report.json"), os.path.join(fetch, "report.json")], check=True)
compare = json.load(open(compare_path, encoding="utf-8"))
json.dump({"schema": "hololive-refresh-compare/2",
           "note": ("2026-10-08に取得した各ページを、それまでのキャッシュの版と比べた結果。class: updated＝wikiの最終更新の"
                    "表示が違う（編集された）、same_date_changed＝最終更新は同じで、本文の行か、保存する構造（見出し・表・脚注・"
                    "リンク・呼称の行・題名・URL）が違う（ほかのページの表を読み込むページなど）、same＝最終更新も本文も構造も同じ。"
                    "updated と same_date_changed のページを取り直した版に入れ替え、same のページは保存していた版のまま。"
                    "added・removed はリンク番号・脚注番号を除いた本文の行数、lines_changed は番号を含めた行数、differs は違った項目。"),
           **compare}, open(os.path.join(out, "compare.json"), "w", encoding="utf-8"), ensure_ascii=False, indent=1)
pages = report["pages"]
ok = [p for p in pages if p["status"] == "ok"]
s = report["summary"]
c = collections.Counter(row["class"] for row in compare["pages"])
rows = compare["pages"]
changed = [r for r in rows if r["class"] in ("updated", "same_date_changed")]
added = sum(r.get("added", 0) for r in changed)
removed = sum(r.get("removed", 0) for r in changed)
numbering = sum(1 for r in changed if r.get("numbering_only"))
structure_only = sum(1 for r in changed if "lines" not in r["differs"])
updated_text = [r for r in rows if r["class"] == "updated" and "lines" not in r.get("differs", [])]
updated_same = [r for r in updated_text if not r.get("differs")]
LABELS = {"main": "個別ページ", "quotes": "語録", "glossary": "関連語", "nicknames_page": "呼称一覧", "episodes": "エピソード集",
          "history_page": "歩み", "minecraft": "Minecraft", "own_works": "自作作品集", "drinks": "呑んだお酒",
          "costumes": "衣装一覧", "designer_art": "デザイナーによるイラスト", "games": "実況ゲームタイトル一覧",
          "songs": "歌唱楽曲一覧", "bgm": "使用BGM", "videos": "動画一覧", "twitter_videos": "Twitter限定動画一覧",
          "references": "参考資料"}
fffd = [f"{r['owner']}/{r['page']}（{r['fffd']}字）" for r in rows if r.get("fffd")]
by_kind = collections.Counter(LABELS.get(r["page"], r["page"]) if r["owner"] != "shared" else "共有ページ" for r in changed)
started, finished = report["started_at"], report["finished_at"]
text = f"""# 全ページの照合と取り直し — seesaawiki.jp/hololivetv を{len(pages):,}ページ巡回（2026-10-08）

キャッシュに本文のある全ページをリーダーで取得し、保存していた版と比べた記録です。wikiの最終更新の表示が違うページと、
最終更新は同じでも本文や構造が違うページを、取得した版（リーダーの `--all` のJSON）に入れ替えて、2026-10-08版のキャッシュを
作りました（`build_fast_cache.py build --snapshots … --checked-on 2026-10-08`）。ほかのページは、保存していた版と同じ内容でした。
古い版は保存していません。

## 結論

| 確認項目 | 結果 |
|---|---|
| 読み取れたページ | **{len(ok):,} / {len(pages):,}**（エラー{len(s['errors'])}件、記事の閉じタグを確認できなかったページ{len(s['pages_with_unclosed_article'])}件） |
| 接続先 | {', '.join(s['http_destinations'])} のみ（wiki以外への接続 {len(s['non_wiki_destinations'])}、広告配信サーバーへの接続 {len(s['ad_destinations'])}） |
| ページのHTMLにあった広告要素 | 合計 {s['ad_elements_in_markup']:,}個。そのうち記事本文（`.user-area`・脚注欄）の中は **{s['ad_elements_inside_article']}個** |
| リーダーが記事コンテナ内で読み飛ばした要素 | 広告枠 {s['ad_slots_skipped_by_reader']:,}、ページ部品 {s['chrome_skipped_by_reader']:,} |
| 出力に残った広告URL | 本文・リンク・画像で **{s['ad_urls_in_article_links_images']}件**、本文の文字で {s['ad_urls_in_article_text']}件 |
| 広告フィルタによる本文の変化 | {'なし' if not s['pages_where_filter_changed_article'] else ', '.join(s['pages_where_filter_changed_article'])}（`strict` と `off` で記事の各項目が一致） |
| 取得したHTML | {s['html_bytes'] / 1e6:,.1f}MB、ダウンロード合計 {s['seconds']['download'] / 60:,.1f}分 |

## 保存していた版との比較（`compare.json`）

| 結果 | ページ | 扱い |
|---|---:|---|
| wikiの最終更新の表示が違う（編集された） | {c['updated']} | 取り直した版に入れ替えた |
| 最終更新は同じで、本文か構造が違う | {c['same_date_changed']} | 取り直した版に入れ替えた（整合のため） |
| 最終更新も本文も構造も同じ | {c['same']} | 保存していた版のまま |

入れ替えた{len(changed)}ページの本文の差は、追加{added:,}行・削除{removed:,}行です（リンク番号 `[n]`・脚注番号 `*n` のずれは数えない）。
そのうち{numbering}ページは番号のずれだけ、{structure_only}ページは本文の行が同じでリンク先などの構造だけが違いました。
最終更新の表示が違っても本文の行が同じだったページは{len(updated_text)}件で、そのうち{len(updated_same)}件は保存する構造も同じでした
（最終更新が違うため、取り直した版に入れ替えています）。

最終更新が同じで本文が違うのは、wikiがほかのページの表を読み込んで表示するページ（各人の歌唱楽曲一覧に載る全員共通の曲の表、
動画一覧のメンバー限定配信の表、衣装・3Dの表など）、埋め込まれたXの投稿が投稿者の現在の表示名で表示されるページ、
画像の差し替え（リンク先だけの違い）などです。

入れ替えたページの種類: {'、'.join(f'{kind} {count}' for kind, count in by_kind.most_common())}。

置換文字「�」を含むページは {', '.join(fffd) if fffd else 'ありません'}（wikiのHTMLに `&#65533;` と書かれているもので、リーダーの誤りではありません）。

## 方法

- 実行: `python3 tools/audit_ads_online.py --targets targets.json --out report.json --pages-dir pages --raw-dir raw`
- 比較: 取得した各ページを `build_fast_cache.py` の取り込みと同じ形（本文の行と、見出し・表・脚注・リンク・呼称の行）にして、
  保存していた版と比べた（`audits/skill_update_2026-10-08/compare_1008.py.txt`）。
- リーダー {report['reader_version']}（`--all --all-links --tables --nicknames --images --surrogate-charrefs utf16`、`--ad-filter strict`）、広告ブロック {report['adblock_version']}、Python {report['python']}（{report['platform']}）。1ページずつ1秒以上の間隔で取得しました。
- 期間: {started[:19].replace('T', ' ')} 〜 {finished[:19].replace('T', ' ')}（UTC）
- `report.json` は、ツールの報告を取り込みの確認に必要な項目だけに縮めたものです（1ページごとのHTTP状態・取得時刻・HTMLのSHA-256・広告の検査結果）。元HTMLは広告コードを含むため、アーカイブには入れていません。
"""
if fetch2:
    report2 = json.load(open(os.path.join(fetch2, "report.json"), encoding="utf-8"))
    subprocess.run([sys.executable, "-B", compact,
                    os.path.join(out, "report_second_pass.json"), os.path.join(fetch2, "report.json")], check=True)
    compare2 = json.load(open(compare2_path, encoding="utf-8"))
    json.dump({"schema": "hololive-refresh-compare/2",
               "note": ("2026-10-08の2回目の取得（全ページ）を、1回目の取得から作ったキャッシュの版と比べた結果。class は "
                        "compare.json と同じ。updated と same_date_changed のページを2回目の版に入れ替え、same のページは"
                        "1回目の結果のまま。"),
               **compare2}, open(os.path.join(out, "compare_second_pass.json"), "w", encoding="utf-8"),
              ensure_ascii=False, indent=1)
    pages2, s2 = report2["pages"], report2["summary"]
    ok2 = [page for page in pages2 if page["status"] == "ok"]
    rows2 = compare2["pages"]
    c2 = collections.Counter(row["class"] for row in rows2)
    changed2 = [r for r in rows2 if r["class"] in ("updated", "same_date_changed")]
    both = {(r["owner"], r["page"]) for r in changed} | {(r["owner"], r["page"]) for r in changed2}

    def difference(row):
        if "lines" in row.get("differs", []):
            return f"追加{row.get('added', 0)}・削除{row.get('removed', 0)}行"
        return "本文の行は同じ（" + "・".join(row.get("differs", [])) + "）" if row.get("differs") else "本文も構造も同じ"
    listed = "\n".join(
        f"| {r['title']} | {'最終更新が違う' if r['class'] == 'updated' else '最終更新は同じで本文か構造が違う'} | "
        f"{r['cached_last_updated'] or '—'} → {r['fetched_last_updated'] or '—'} | {difference(r)} |"
        for r in changed2)
    text = text.replace("## 結論\n", "## 結論（1回目の取得）\n", 1).replace(
        "## 保存していた版との比較（`compare.json`）", "## 保存していた版との比較（1回目、`compare.json`）", 1)
    text = text.replace("古い版は保存していません。\n", "同じ日に全ページをもう一度取得し、1回目の取得の途中とその後に編集されたページも"
                        "入れ替えました（下の「2回目の取得」）。\n古い版は保存していません。\n", 1)
    text += f"""
## 2回目の取得（取得の途中とその後の編集）

1回目の取得から作ったキャッシュを `check-updates` で現在のwikiと照合したところ、そのページを取得した後に編集されたページが
ありました（さくらみこ【語録】。wikiの表示で 2026年10月08日(木) 21:53:03、日本時間）。全ページの取得には1時間以上かかるため、
ほかにも同じようなページがあり得ます。そこで、同じ方法で全ページをもう一度取得し、1回目の結果から作ったキャッシュと比べて、
違うページを2回目の版に入れ替えました（`report_second_pass.json`・`compare_second_pass.json`）。

- 期間: {report2['started_at'][:19].replace('T', ' ')} 〜 {report2['finished_at'][:19].replace('T', ' ')}（UTC）。読み取れたページ **{len(ok2):,} / {len(pages2):,}**（エラー{len(s2['errors'])}件）。接続先は {', '.join(s2['http_destinations'])} のみ、記事本文の中の広告要素 {s2['ad_elements_inside_article']}個、出力に残った広告URLは本文・リンク・画像で{s2['ad_urls_in_article_links_images']}件・本文の文字で{s2['ad_urls_in_article_text']}件。
- 比較: 最終更新が違う **{c2['updated']}** ページと、最終更新は同じで本文か構造が違う **{c2['same_date_changed']}** ページを、2回目の版に入れ替えました。{c2['same']:,}ページは同じでした。

| ページ | 違い | 最終更新（1回目 → 2回目） | 本文の差（番号を除く） |
|---|---|---|---|
{listed}

2回の取得を合わせて、取り直した版に入れ替えたページは **{len(both)}** ページ（両方で入れ替えたページは1回と数える）、
保存していた版のままのページは **{len(pages) - len(both):,}** ページです。
"""
open(os.path.join(out, "README.md"), "w", encoding="utf-8").write(text)
print(text)
