@echo off
rem Checks every file against MANIFEST.sha256, then runs the offline tests.
setlocal
set PYTHONUTF8=1
set "PYEXE=python"
where py >nul 2>nul && set "PYEXE=py -3"
cd /d "%~dp0"
%PYEXE% hololive_cache.py verify || exit /b 1
%PYEXE% -m unittest discover -s tests -v
exit /b %errorlevel%
