"""Cache provenance must never make valid article output unencodable. No HTTP."""
import base64
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import tempfile
import time
import unittest
from unittest.mock import patch

ROOT=Path(__file__).resolve().parents[1]
# The repository keeps the reader at its root; the person cache archive under tools/.
DEFAULT=next((p for p in (ROOT/'hololive_wiki_reader_v31.py',ROOT/'tools'/'hololive_wiki_reader_v31.py') if p.is_file()),ROOT/'hololive_wiki_reader_v31.py')
SCRIPT=Path(os.environ.get('READER_UNDER_TEST',str(DEFAULT)))
SPEC=importlib.util.spec_from_file_location('cache_metadata_reader',SCRIPT)
reader=importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(reader)
URL='https://seesaawiki.jp/hololivetv/d/Source'
RAW=b'<html><div id="page-body-inner"><div class="user-area">Retained</div></div></html>'

def snapshot(cache, changes):
 metadata={'requested_url':URL,'url':URL,'http_status':200,'content_type':'text/html; charset=utf-8','fetched_at':'2026-09-20T00:00:00Z','http_requests':1}
 metadata.update(changes)
 record={'schema':1,'reader_version':reader.VERSION,'stored_at':time.time(),'requested_url':URL,'requested_user_agent':reader.DEFAULT_UA,'metadata':metadata,'sha256':hashlib.sha256(RAW).hexdigest(),'html_base64':base64.b64encode(RAW).decode()}
 path=cache.path(URL,reader.DEFAULT_UA)
 path.write_text(json.dumps(record),encoding='utf-8')
 return path

class CacheMetadataUnicodeTests(unittest.TestCase):
 def test_kept_metadata_surrogates_are_rejected_before_reuse(self):
  cases=[{'fetched_at':'\ud800'}, {'fetch_warnings':['\udfff']}, {'redirects':[{'from':'\ud800'}]}, {'retry_history':[{'detail':'\ud800'}]}, {'layout_fallback':{'reason':'\ud800'}}]
  for changes in cases:
   with self.subTest(changes=repr(changes)), tempfile.TemporaryDirectory() as td:
    cache=reader.PageCache(td)
    path=snapshot(cache,changes)
    with self.assertRaises(UnicodeEncodeError):cache.read_snapshot(path)
    self.assertIsNone(cache.load(URL,reader.DEFAULT_UA))
    self.assertTrue(any('invalid cache record' in warning for warning in cache.warnings))
 def test_unknown_or_invocation_only_bad_fields_are_discarded(self):
  with tempfile.TemporaryDirectory() as td:
   cache=reader.PageCache(td)
   snapshot(cache,{'unused_extension':{'bad':'\ud800'},'search_results':'\ud800','requested_title':'\ud800'})
   loaded=cache.load(URL,reader.DEFAULT_UA)
   self.assertIsNotNone(loaded)
   raw,metadata=loaded
   self.assertEqual(raw,RAW)
   self.assertFalse({'unused_extension','search_results','requested_title'} & metadata.keys())
   args=reader.build_cli().parse_args(['--url',URL])
   reader.render_result(reader.make_result(raw,metadata,args),args).encode('utf-8')
 def test_valid_astral_character_metadata_remains_supported(self):
  with tempfile.TemporaryDirectory() as td:
   cache=reader.PageCache(td)
   snapshot(cache,{'fetch_warnings':['emoji: \U0001f600']})
   loaded=cache.load(URL,reader.DEFAULT_UA)
   self.assertIsNotNone(loaded)
   self.assertEqual(loaded[1]['fetch_warnings'],['emoji: \U0001f600'])
 def test_rebuild_skips_bad_metadata_and_keeps_other_records(self):
  with tempfile.TemporaryDirectory() as td:
   cache=reader.PageCache(td)
   good=snapshot(cache,{})
   retained=good.read_bytes()
   bad=snapshot(cache,{'fetch_warnings':['\ud800']})
   bad.rename(Path(td)/('0'*64+'.json'))
   good.write_bytes(retained)
   index=reader.TitleIndex(Path(td)/'titles.json')
   with patch.object(reader,'fetch_page',side_effect=AssertionError('HTTP forbidden')):
    result=reader.rebuild_title_index(cache,index)
   self.assertEqual((result['pages_reindexed'],result['invalid_records'],result['http_requests']),(1,1,0))
class IndexProvenanceUnicodeTests(unittest.TestCase):
 def test_invalid_observed_on_is_ignored_and_index_can_recover(self):
  for provenance in ("\ud800", None, [], {}, 17):
   with self.subTest(provenance=repr(provenance)), tempfile.TemporaryDirectory() as td:
    path=Path(td)/'titles.json'
    index=reader.TitleIndex(path)
    index.harvest('<a href="/hololivetv/d/Old">Old</a>',URL)
    original=json.loads(path.read_text())
    original['entries'][0]['observed_on']=provenance
    path.write_text(json.dumps(original))
    loaded=reader.TitleIndex(path)
    self.assertEqual(loaded.entries,{})
    self.assertTrue(loaded.warnings)
    loaded.harvest('<a href="/hololivetv/d/Current">Current</a>',URL)
    self.assertEqual(len(reader.TitleIndex(path).entries),1)
    self.assertEqual(reader.TitleIndex(path).exact('Current')[0]['observed_on'],URL)
 def test_missing_provenance_uses_existing_base_default_and_unknown_is_ignored(self):
  with tempfile.TemporaryDirectory() as td:
   path=Path(td)/'titles.json'
   index=reader.TitleIndex(path)
   index.harvest('<a href="/hololivetv/d/Old">Old</a>',URL)
   original=json.loads(path.read_text())
   del original['entries'][0]['observed_on']
   original['entries'][0]['unused_extension']='\ud800'
   path.write_text(json.dumps(original))
   loaded=reader.TitleIndex(path)
   self.assertEqual(loaded.exact('Old')[0]['observed_on'],reader.wiki_base())
   self.assertFalse(loaded.warnings)
   self.assertTrue(loaded.save())
   self.assertNotIn('unused_extension',loaded.exact('Old')[0])

if __name__=='__main__':unittest.main()
