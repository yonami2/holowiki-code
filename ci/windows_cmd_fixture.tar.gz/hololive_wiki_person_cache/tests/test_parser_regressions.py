"""Focused, offline regression checks; READER_UNDER_TEST selects a candidate."""
import importlib.util
import itertools
import os
from pathlib import Path
import random
import unittest

_ROOT = Path(__file__).resolve().parents[1]
# The repository keeps the reader at its root; the person cache archive under tools/.
DEFAULT_READER = next((path for path in (_ROOT / 'hololive_wiki_reader_v31.py', _ROOT / 'tools' / 'hololive_wiki_reader_v31.py')
                       if path.is_file()), _ROOT / 'hololive_wiki_reader_v31.py')
PATH = Path(os.environ.get('READER_UNDER_TEST', str(DEFAULT_READER)))
spec = importlib.util.spec_from_file_location('reader_audit', PATH)
r = importlib.util.module_from_spec(spec)
spec.loader.exec_module(r)
URL = 'https://seesaawiki.jp/hololivetv/d/Test'


def document(body):
    return '<html><head><title>Test</title></head><body><div id="page-body-inner"><div class="user-area">' + body + '</div></div></body></html>'


def result(body, *options):
    args = r.build_cli().parse_args(['--url', URL, *options])
    output = r.make_result(document(body).encode(), {'url': URL, 'content_type': 'text/html; charset=utf-8'}, args)
    return output, args


class ParserAudit(unittest.TestCase):
    def test_external_inline_url_survives_long_label(self):
        # The 64-piece limit may bound comparison, but must not drop the source.
        for pieces in (63, 64, 65, 100):
            for fmt in ('text', 'md'):
                with self.subTest(pieces=pieces, fmt=fmt):
                    label = ''.join('<span>x</span>' for _ in range(pieces))
                    output, args = result('<a href="https://example.org/source">' + label + '</a>', '--format', fmt, '--all')
                    self.assertIn('https://example.org/source', r.render_result(output, args))
                    self.assertEqual(output['lines'][0]['text'], 'x' * pieces + ' (https://example.org/source)')
                    self.assertEqual(output['lines'][0]['text'].count('https://example.org/source'), 1)

    def test_empty_footnote_before_first_block_gets_appendix(self):
        body = '<a href="#footer-footnote1" title="note"></a><p>BODY</p><div class="footer-footnote"><li><a id="footer-footnote1">*1</a> : note</li></div>'
        output, args = result(body, '--format', 'text', '--lines', '1')
        self.assertEqual(output['lines'], [{'line': 1, 'text': 'BODY'}])
        self.assertEqual(output['selected_footnote_numbers'], ['1'])
        self.assertIn('*1: note', r.render_result(output, args))

    def test_empty_footnote_after_visible_text_still_gets_appendix(self):
        body = '<p>BODY</p><a href="#footer-footnote1" title="note"></a><div class="footer-footnote"><li><a id="footer-footnote1">*1</a> : note</li></div>'
        output, args = result(body, '--format', 'text', '--lines', '1')
        self.assertEqual(output['selected_footnote_numbers'], ['1'])
        self.assertIn('*1: note', r.render_result(output, args))

    def test_empty_marker_endpoint_mapping(self):
        marker = '<a href="#footer-footnote1" title="note"></a>'
        cases = [
            (marker + '<p>NEXT</p>', ['NEXT'], {1: ['1']}),
            ('<p>PREV</p>' + marker, ['PREV'], {1: ['1']}),
            ('<p>PREV</p>' + marker + '<p>NEXT</p>', ['PREV', 'NEXT'], {1: ['1']}),
            (marker, [], {}),
        ]
        for body, lines, mapping in cases:
            with self.subTest(body=body):
                parsed = r.parse_article(document(body), URL)
                self.assertEqual(parsed['lines'], lines)
                self.assertEqual(parsed['line_footnotes'], mapping)

    def test_empty_marker_does_not_shift_headings_or_link_mapping(self):
        marker = '<a href="#footer-footnote1" title="note"></a>'
        body = '<h2>A</h2><p><a href="https://example.org/a">LINK</a></p><h2>B</h2><p>END</p>'
        reference = r.parse_article(document(body), URL, link_mode='off')
        parsed = r.parse_article(document(marker + body), URL, link_mode='off')
        self.assertEqual(parsed['lines'], reference['lines'])
        self.assertEqual(parsed['headings'], reference['headings'])
        # The extra fragment URL has its own link ID; compare destination maps.
        def destinations(page):
            return {line: [page['links'][key] for key in keys] for line, keys in page['line_links'].items()}
        self.assertEqual(destinations(parsed), destinations(reference))

    def test_line_separators_remain_in_structured_attrs_only(self):
        for separator in ('\n', '\r', '\r\n', '\v', '\f', '\x1c', '\x1d', '\x1e', '\x85', '\u2028', '\u2029'):
            for attr in ('rowspan', 'colspan'):
                with self.subTest(separator=repr(separator), attr=attr):
                    html = document('<table><tr><td ' + attr + '="1' + separator + '2"><img alt="a' + separator + 'b"><a href="https://e.example/c' + separator + 'd">L</a></td><td>Y</td></tr></table>')
                    parsed = r.parse_article(html, URL, link_mode='inline')
                    self.assertEqual(len(parsed['lines']), 1)
                    self.assertEqual(parsed['tables'][0]['rows'][0]['cells'][0][attr + '_raw'], '1' + separator + '2')
                    self.assertTrue(any('c' + separator + 'd' in href for values in parsed['link_original_hrefs'].values() for href in values))

    def test_table_text_cache_equivalence(self):
        randomizer = random.Random(382)
        for case in range(120):
            body = '<a href="#footer-footnote1">*1</a><a href="https://example.org/a">X</a>'
            for depth in range(randomizer.randrange(1, 9)):
                body = '<table><tr><td>A' + body + 'B</td><td>Y</td></tr></table>'
                if randomizer.choice((True, False)):
                    body = '<del>' + body + '</del>'
            parser = r.ArticleParser(URL)
            parser.feed(document(body))
            cache = r._table_content_cache(parser.root)
            for node in r._walk(parser.root):
                if node.tag in ('td', 'table'):
                    self.assertEqual(r._node_text(node), r._node_text(node, table_text_cache=cache[0]))
                    self.assertEqual(r._node_text(node, omit_footnotes=True), r._node_text(node, omit_footnotes=True, table_text_cache=cache[1]))
                    self.assertEqual(r._table_references(node, {}), r._table_references(node, cache[2]))

    def test_match_paging_properties(self):
        for count in range(1, 10):
            lines = ['match' if i % 3 == 1 else 'other' for i in range(count)]
            matches = [i for i, text in enumerate(lines, 1) if text == 'match']
            for context, limit, offset in itertools.product(range(4), range(1, 5), range(len(matches) + 2)):
                args = r.build_cli().parse_args(['--url', URL, '--find', 'match', '--context', str(context), '--lines', str(limit), '--start', str(offset + 1)])
                selected, info = r.select_article_lines({'lines': lines}, args)
                selected_lines = [number for number, _ in selected]
                if offset < len(matches):
                    self.assertIn(matches[offset], selected_lines)
                else:
                    self.assertEqual(selected, [])
                self.assertFalse(set(matches[:offset]).intersection(selected_lines))
                last = selected_lines[-1] if selected_lines else float('inf')
                self.assertEqual(info['more_matches'], any(number > last for number in matches[offset:]))

    def test_link_mapping_has_no_text_guessing(self):
        html = document('<p>[1] plain https://example.org/</p><a href="https://example.org/"><p>first</p><p>second</p></a><p>none</p>')
        parsed = r.parse_article(html, URL, link_mode='off')
        self.assertEqual(parsed['line_links'], {2: ['1'], 3: ['1']})


if __name__ == '__main__':
    unittest.main()
