"""person_cache v2: lossless conversion, reader-identical selection, fast lookups. No HTTP.

A small synthetic v1 cache is written to a temporary directory in the byte
formats of the v1 tools. PERSON_CACHE_V1 may name a real extracted v1 cache
to run the same round trip on it (skipped otherwise).

In the repository: python -m unittest discover -s tests -v
In an extracted v2 archive: python3 -m unittest discover -s tests -v (inside the folder).
PERSON_CACHE_CODE and READER_UNDER_TEST override the code and reader locations.
"""
import argparse
import contextlib
import hashlib
import importlib.util
import io
import json
import os
from pathlib import Path
import random
import re
import shutil
import sys
import tempfile
import unittest

REPO = Path(__file__).resolve().parents[1]
# In the repository the code is person_cache/; in an extracted archive this
# file is tests/ beside build_fast_cache.py and the reader is under tools/.
LOCAL = REPO / 'person_cache' if (REPO / 'person_cache' / 'build_fast_cache.py').is_file() else REPO
CODE = Path(os.environ.get('PERSON_CACHE_CODE', str(LOCAL)))
_READER = next((path for path in (REPO / 'hololive_wiki_reader_v31.py', CODE / 'tools' / 'hololive_wiki_reader_v31.py',
                                  CODE / 'vendor' / 'jp_reader' / 'hololive_wiki_reader_v31.py') if path.is_file()),
               REPO / 'hololive_wiki_reader_v31.py')
READER = Path(os.environ.get('READER_UNDER_TEST', str(_READER)))


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


builder = load('build_fast_cache', CODE / 'build_fast_cache.py')
core = load('hololive_cache_core', CODE / 'hololive_cache_core.py')
reader = load('person_cache_reader', READER)

WIKI = 'https://seesaawiki.jp/hololivetv/d/'
HANAKO_URL = WIKI + '%a5%c6%a5%b9%a5%c8%b2%d6%bb%d2'
TARO_URL = WIKI + 'Test%20Taro'


def compact_nl(obj):
    return (json.dumps(obj, ensure_ascii=False, separators=(',', ':')) + '\n').encode('utf-8')


def indent2(obj):
    return json.dumps(obj, ensure_ascii=False, indent=2).encode('utf-8')


def page(title, url, updated, preamble, sections, *, tables=True, footnotes=None, total=True):
    """A v1 page record: preamble, then (level, heading, body) sections."""
    record = {'title': title, 'url': url, 'last_updated': updated}
    line = len(preamble)
    built, path = [], []
    for level, heading, body in sections:
        line += 1
        while path and path[-1][0] >= level:
            path.pop()
        built.append({'level': level, 'heading': heading, 'path': [p[1] for p in path],
                      'article_line': line, 'body': list(body)})
        path.append((level, heading))
        line += len(body)
    if total:
        record['total_lines'] = line
    record['preamble'] = list(preamble)
    record['sections'] = built
    if tables:
        record['tables'] = [{'index': 1, 'section': [sections[0][1]], 'rows': [['相手', '呼び方', '呼ばれ方']]}]
    if footnotes is not None:
        record['footnotes'] = footnotes
    return record


def snapshot_ref(title, url, owner, lines=10):
    digest = hashlib.sha256(title.encode()).hexdigest()
    return {'title': title, 'url': url, 'url_key': 'seesaawiki.jp:' + url.encode().hex(),
            'html_sha256': digest, 'parse_variant_sha256': digest[::-1], 'fetched_at': '2026-09-22T00:00:00+00:00',
            'parsed_at': '2026-09-22T00:00:01+00:00', 'source': 'http', 'source_inputs': [],
            'relative_path': None, 'audit': {'status': 'structure_checked', 'reasons': [], 'lines': lines,
                                              'tables': 1, 'footnotes': 0, 'model_full_read': 'undocumented'},
            'owner_slug': owner, 'shared_with_slugs': [], 'raw_content_embedded': False}


def write_v1(root):
    """Write a v1 cache (two JP talents, one EN person, one shared page)."""
    top = root / 'hololive_wiki_person_cache'
    files = {}
    talents = [('test_hanako', 'テスト花子', ['花子', 'はなちゃん']), ('test_jiro', 'テスト次郎', ['次郎'])]
    jp_rows, nickname_rows, people = [], [], []
    for order, (slug, name, aliases) in enumerate(talents, 1):
        main_url = HANAKO_URL if slug == 'test_hanako' else WIKI + slug
        other = talents[1][1] if order == 1 else talents[0][1]
        nicknames = [{'counterpart': name, 'calls': '私、花子' if order == 1 else '僕', 'called_by': ''},
                     {'counterpart': other, 'calls': '次郎くん' if order == 1 else '花子先輩',
                      'called_by': '花子先輩' if order == 1 else '次郎くん'},
                     {'counterpart': 'Test Taro', 'calls': 'Taro' if order == 1 else '', 'called_by': ''},
                     {'counterpart': 'YAGOO', 'calls': '', 'called_by': ''}]
        main = page(name, main_url, 'editor 2026年09月20日', ['Top [1]  > ' + name],
                    [(3, '性格', ['明るい。*1', '| 表 | ### 表内見出しではない |']), (4, '性格の補足', ['補足行']),
                     (3, '好きなもの', ['お茶']), (3, '性格', ['同名の見出し'])],
                    total=False, footnotes={'1': {'number': '1', 'text': '脚注本文', 'display_text': '脚注本文'}})
        quotes = page(name + '【語録】', main_url + '%a1%da%b8%ec%cf%bf%a1%db', 'editor 2026年08月01日', ['導入'],
                      [(4, '口癖', []), (5, '一行目の台詞\n二行目の台詞', ['二行目の台詞  [9]', '説明'])])
        songs = page(name + '【歌唱楽曲一覧】', main_url + '%a1%da%b2%ce%a1%db', None, [], [(3, '一覧', ['| 曲 |'])],
                     tables=False)
        sources = [{'title': rec['title'], 'label': label, 'role': 'persona', 'url': rec['url'],
                    'last_updated': rec['last_updated'], 'html_sha256': hashlib.sha256(rec['title'].encode()).hexdigest(),
                    'fetched_at': '2026-09-22T12:00:00+00:00', 'lines': 5, 'tables': 1}
                   for rec, label in ((main, '個別ページ'), (quotes, '語録'), (songs, '歌唱楽曲一覧'))]
        talent = {'schema': 'hololive-talent-cache/1', 'slug': slug, 'name': name, 'generation': '0期生',
                  'debut_order': order, 'aliases': aliases, 'wiki': 'hololivetv',
                  'profile': {'X(Twitter)': '@test_' + slug[5:], 'ファンの愛称': 'ファン'},
                  'persona': {'personality': '明るい。'}, 'timeline': {'2026年': '活動'},
                  'nicknames': nicknames, 'nicknames_page': None, 'quotes': quotes, 'drinks': None,
                  'main_page': main, 'sources': sources, 'missing_pages': []}
        titles = {'schema': 'hololive-talent-titles/1', 'slug': slug, 'name': name, 'generation': '0期生',
                  'games': None, 'songs': songs, 'twitter_videos': None}
        files[f'data/jp/talents/{slug}.json'] = compact_nl(talent)
        files[f'data/jp/titles/{slug}.json'] = compact_nl(titles)
        files[f'data/jp/cards/{slug}.md'] = (
            f'# {name}\n\n- 一人称: 私\n- …ほか 2名（呼称全件は digests/ と talents/ を参照）\n\n## もっと読む\n'
            f'- 人物像ダイジェスト: `data/digests/{slug}.md`\n- 全文レコード: `data/talents/{slug}.json`\n'
            f'- 関連タイトル: `data/titles/{slug}.json`\n').encode()
        files[f'data/jp/digests/{slug}.md'] = f'# {name} digest\n'.encode()
        jp_rows.append({'slug': slug, 'name': name, 'generation': '0期生', 'debut_order': order, 'aliases': aliases,
                        'pages': 3, 'lines': 20, 'tables': 2, 'nicknames': len(nicknames),
                        'persona_sections': ['personality'], 'timeline_years': ['2026年'],
                        'talent_file': f'talents/{slug}.json', 'titles_file': f'titles/{slug}.json',
                        'digest_file': f'digests/{slug}.md', 'card_file': f'cards/{slug}.md', 'missing_pages': []})
        for item in nicknames:
            if item['counterpart'] and item['counterpart'] != name:
                nickname_rows.append({'speaker': name, 'speaker_slug': slug, **item})
        refs = [snapshot_ref(name, main_url, slug)]
        people.append({'slug': slug, 'name': name, 'region': 'JP', 'generation': '0期生', 'aliases': aliases,
                       'primary_cache': {'card_file': f'jp/cards/{slug}.md'}, 'cached_page_count': 3,
                       'cached_article_lines': 20, 'structural_audit': 'independently_checked_from_compacted_records',
                       'model_full_read': 'undocumented', 'pages': refs, 'shared_related_pages': [],
                       'needs_review': [], 'primary_sources': sources, 'collection_status': 'structured_cached'})
    shared = page('交友関係', WIKI + '%b8%f2%cd%a7%b4%d8%b7%b8', 'editor 2026年09月22日', ['交友の導入'],
                  [(3, 'テスト花子', ['テスト次郎と仲良し'])], footnotes={})
    shared.update({'label': '交友関係', 'role': 'relations', 'source': 'http', 'nicknames': [], 'warnings': ['w']})
    files['data/jp/shared/0123456789ab.json'] = compact_nl(shared)
    taro_refs = [snapshot_ref('Test Taro', TARO_URL, 'test_taro', 40),
                 snapshot_ref('Test Taro【語録】', TARO_URL + '%a1%da%b8%ec%cf%bf%a1%db', 'test_taro'),
                 snapshot_ref('Test Taro【動画一覧】_2021データ', TARO_URL + '_2021', 'test_taro')]
    related = snapshot_ref('Myth', WIKI + 'Myth', None)
    people.append({'slug': 'test_taro', 'name': 'Test Taro', 'region': 'EN', 'generation': 'myth', 'aliases': [],
                   'primary_cache': {}, 'cached_page_count': 3, 'cached_article_lines': 60,
                   'structural_audit': 'structure_checked', 'model_full_read': 'undocumented', 'pages': taro_refs,
                   'shared_related_pages': [related], 'needs_review': [],
                   'nickname_file': 'people/test_taro/nicknames.json', 'nickname_record_count': 2,
                   'card_file': 'people/test_taro/card.md', 'collection_status': 'raw_cached',
                   'supplement_file': 'people/test_taro/profile.json', 'card_json_file': 'people/test_taro/card.json'})
    taro_nicks = [{'counterpart': 'テスト花子', 'calls': 'Hanako', 'called_by': 'Taro', 'source_title': 'Test Taro',
                   'source_url': TARO_URL, 'direction': 'calls=本人→相手; called_by=相手→本人'},
                  {'counterpart': '(視聴者)', 'calls': '', 'called_by': '', 'source_title': 'Test Taro',
                   'source_url': TARO_URL, 'direction': 'calls=本人→相手; called_by=相手→本人'}]
    files['data/people/test_taro/nicknames.json'] = indent2({'name': 'Test Taro', 'count': 2,
                                                             'direction': 'calls=本人→相手; called_by=相手→本人',
                                                             'records': taro_nicks})
    files['data/people/test_taro/card.md'] = '# Test Taro\n\n- 話し方: Shark jokes\n'.encode()
    files['data/people/test_taro/profile.json'] = indent2({'name': 'Test Taro', 'traits': 'Profile only text'})
    files['data/people/test_taro/card.json'] = indent2({'name': 'Test Taro', 'speech': 'Card json text'})
    files['data/people/stale_dir/card.md'] = b'# orphan\n'
    snapshots = sorted([ref for p in people for ref in p['pages']] + [related], key=lambda r: r['url'])
    index = {'schema': 'hololive-research-archive/1', 'source_site': 'https://seesaawiki.jp/hololivetv/',
             'fictional_world': {'no_graduates': True}, 'talent_count': 3, 'people': people,
             'raw_snapshots': snapshots, 'shared_page_refs': [related], 'odd': {'$ref': 'kept literally'}}
    files['data/index.json'] = indent2(index)
    files['data/jp/index.json'] = indent2({'schema': 'hololive-talent-cache-index/1', 'built_at': '2026-09-22T13:37:26Z',
                                           'reader_version': '3.8.3', 'talents': jp_rows,
                                           'shared': [{'title': '交友関係', 'label': '交友関係', 'role': 'relations',
                                                       'file': 'shared/0123456789ab.json', 'lines': 3}]})
    files['data/jp/nicknames.json'] = compact_nl({'schema': 'hololive-nickname-index/1', 'note': 'n',
                                                  'count': len(nickname_rows), 'records': nickname_rows})
    files['data/jp/README.md'] = b'jp readme\n'
    files['data/audits/audit.json'] = b'{"ok": true}\n'
    everyone = [(p['slug'], p['name'], p['region'], p['generation']) for p in people]
    files['hololive_wiki_quick_profiles_82.json'] = indent2({'schema': 'hololive-wiki-quick-profiles/1', 'people': [
        {'name': n, 'region': r, 'generation': g, 'slug': s, 'aliases': None, 'one_line_persona': n + 'の人物像',
         'speech': None, 'relationships': None, 'self_reference': None, 'source_urls': [],
         'read_status': {}, 'card_path': 'x'} for s, n, r, g in everyone]})
    files['hololive_wiki_roster_82.json'] = indent2({'schema': 'hololive-wiki-roster/1', 'people': [
        {'name': n, 'slug': s, 'region': r, 'generation': g, 'card_path': 'x', 'collection_status': 'c'}
        for s, n, r, g in everyone]})
    files['README.md'] = b'v1 readme\n'
    files['lookup.py'] = b'print("v1")\n'
    files['vendor/jp_reader/tool.py'] = b'# vendor\n'
    for relative, data in files.items():
        path = top / relative
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(data)
    try:
        (top / 'vendor/jp_reader/data').symlink_to('../../data/jp', target_is_directory=True)
    except OSError:
        pass            # Windows without the symlink privilege: the v1 cache simply has no link.
    manifest = ''.join(f'{hashlib.sha256(files[name]).hexdigest()}  {name}\n' for name in sorted(files))
    (top / 'MANIFEST.sha256').write_text(manifest, encoding='utf-8')
    return top, files


def wiki_root(path):
    lines = ['### メンバー一覧（ページへのリンク）  [1]', '| [colspan=5] 0期生 [2]  |',
             '| テスト花子 [3]  | [rowspan=2] Test Taro [4]  / テスト・タロウ / （元EN） |', '| 別人 [5]  |',
             '項目別リンク集', '| 🍵テスト花子 [3]  | 🍵語録 [6]  |']
    data = {'url': 'https://seesaawiki.jp/hololivetv/', 'fetched_at': '2026-09-23T00:00:00+00:00',
            'html_sha256': 'f' * 64, 'reader_version': '3.8.3', 'page_metadata': {'last_updated': 'x'},
            'lines': [{'line': i, 'text': t} for i, t in enumerate(lines, 1)],
            'headings': [{'level': 3, 'text': 'メンバー一覧（ページへのリンク）', 'article_line': 1}],
            'links': {'3': HANAKO_URL, '4': TARO_URL, '5': WIKI + 'x', '6': WIKI + 'y'}}
    path.write_text(json.dumps(data, ensure_ascii=False), encoding='utf-8')
    return path


def run(cache, *argv):
    stdout, stderr = io.StringIO(), io.StringIO()
    with contextlib.redirect_stdout(stdout), contextlib.redirect_stderr(stderr):
        code = core.main(['--cache', str(cache), *argv])
    return code, stdout.getvalue(), stderr.getvalue()


class PersonCacheTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.tmp = tempfile.TemporaryDirectory()
        root = Path(cls.tmp.name)
        cls.v1, cls.v1_files = write_v1(root / 'in')
        cls.v2 = root / 'out' / 'hololive_wiki_person_cache'
        cls.report = builder.build(root / 'in', cls.v2, wiki_root_json=wiki_root(root / 'root.json'))

    @classmethod
    def tearDownClass(cls):
        cls.tmp.cleanup()

    def test_every_v1_byte_is_restored(self):
        self.assertEqual(self.report['restore_verified'], len(self.v1_files))
        self.assertEqual(self.report['recipe_fallbacks'], [])
        # Talents, titles, the shared page, both JSON indexes are rebuilt, not stored twice.
        self.assertGreaterEqual(self.report['restore_methods']['recipe'], 7)
        with tempfile.TemporaryDirectory() as td:
            result = builder.restore_v1(self.v2, Path(td) / 'v1')
            restored = Path(td) / 'v1'
            for name, data in self.v1_files.items():
                self.assertEqual((restored / name).read_bytes(), data, name)
            self.assertEqual((restored / 'MANIFEST.sha256').read_bytes(), (self.v1 / 'MANIFEST.sha256').read_bytes())
            linked = (self.v1 / 'vendor/jp_reader/data').is_symlink()
            self.assertEqual(result['symlinks_expected'], 1 if linked else 0)
            if result['symlinks_created']:
                self.assertEqual(os.readlink(restored / 'vendor/jp_reader/data').replace(os.sep, '/'), '../../data/jp')
        self.assertFalse((self.v2 / 'data').exists())

    def test_jp_cards_point_at_v2_files(self):
        card = core.Cache(self.v2).person('テスト花子').card()
        self.assertNotIn('data/talents', card)
        self.assertIn('`people/test_hanako/pages/`', card)
        self.assertIn('`people/test_hanako/digest.md`', card)
        self.assertIn('（呼称全件は `nicknames.json` と `digest.md` を参照）', card)
        self.assertEqual(card.splitlines()[:3], ['# テスト花子', '', '- 一人称: 私'])
        # The v1 wording is what restore-v1 returns (checked byte for byte above).
        self.assertIn(b'data/talents/test_hanako.json', self.v1_files['data/jp/cards/test_hanako.md'])

    def test_corrupted_v1_input_is_rejected(self):
        with tempfile.TemporaryDirectory() as td:
            copy = Path(td) / 'hololive_wiki_person_cache'
            shutil.copytree(self.v1, copy, symlinks=True)
            (copy / 'data/jp/README.md').write_bytes(b'edited\n')
            with self.assertRaises(builder.BuildError):
                builder.build(copy, Path(td) / 'out')

    def test_page_file_line_n_is_article_line_n(self):
        cache = core.Cache(self.v2)
        quotes = cache.person('テスト花子').page('語録')
        self.assertEqual(quotes.lines, ['導入', '#### 口癖', '##### 一行目の台詞', '二行目の台詞  [9]', '説明'])
        self.assertEqual([h['article_line'] for h in quotes.headings()], [2, 3])
        self.assertEqual(quotes.headings()[1]['text'], '一行目の台詞\n二行目の台詞')
        main = cache.person('テスト花子').page('main')
        self.assertEqual(main.lines[1:4], ['### 性格', '明るい。*1', '| 表 | ### 表内見出しではない |'])
        text = (self.v2 / 'people/test_hanako/pages/main.txt').read_text(encoding='utf-8')
        self.assertEqual(text.split('\n')[4], '#### 性格の補足')

    def test_selection_matches_the_reader(self):
        cache = core.Cache(self.v2)
        pages = [cache.person('テスト花子').page('main'), cache.person('テスト花子').page('語録'),
                 cache.shared().page('friendships')]
        rng = random.Random(7)
        options = [dict(), dict(all=True), dict(start=2, lines=2), dict(find='性格'), dict(find='性格', context=1, lines=2),
                   dict(find='性格', context=2, start=2, lines=1), dict(section='性格の補足'), dict(section='好き'),
                   dict(section='性格'), dict(section='無い見出し'), dict(section='口癖', all=True),
                   dict(find='x-none'), dict(find='説明', context=3, all=True)]
        for _ in range(60):
            options.append(dict(find=rng.choice([None, '台詞', '性格', '。']), start=rng.randint(1, 4),
                                lines=rng.randint(1, 5), all=rng.random() < 0.2))
            if options[-1]['find'] is not None:
                options[-1]['context'] = rng.randint(0, 3)
        for current in pages:
            parsed = {'lines': current.lines, 'headings': current.headings()}
            for option in options:
                values = dict(section=None, find=None, context=0, start=1, lines=80, all=False)
                values.update(option)
                with self.subTest(page=current.title, option=option):
                    try:
                        expected = reader.select_article_lines(parsed, argparse.Namespace(**values))
                    except reader.ReaderError:
                        with self.assertRaises(core.CacheError):
                            current.select(**values)
                        continue
                    self.assertEqual(current.select(**values), expected)

    def test_names_aliases_readings_and_handles(self):
        cache = core.Cache(self.v2)
        for query in ('テスト花子', 'test_hanako', 'Test-Hanako', 'はなちゃん', '@test_hanako', 'テスト・タロウ',
                      'test taro', 'TEST_TARO', '次郎'):
            with self.subTest(query=query):
                cache.resolve(query)
        self.assertEqual(cache.resolve('テスト・タロウ')['slug'], 'test_taro')
        self.assertEqual(cache.resolve('花')['slug'], 'test_hanako')
        with self.assertRaises(core.CacheError):
            cache.resolve('テスト')          # partial match on two people
        with self.assertRaises(core.CacheError):
            cache.resolve('存在しない人')

    def test_catalog_records_the_wiki_root_without_status_groups(self):
        catalog = json.loads((self.v2 / 'catalog.json').read_text(encoding='utf-8'))
        self.assertEqual(catalog['wiki_root']['roster_people_not_listed'], ['テスト次郎'])
        self.assertEqual(catalog['wiki_root']['other_names_listed'], ['別人'])
        facts = json.loads((self.v2 / 'provenance/wiki_root.json').read_text(encoding='utf-8'))
        self.assertEqual(facts['roster_people_listed']['Test Taro']['readings'], ['テスト・タロウ'])
        self.assertNotIn('0期生', json.dumps(facts, ensure_ascii=False))
        # One JSON record per line keeps catalog.json grep-able.
        lines = (self.v2 / 'catalog.json').read_text(encoding='utf-8').splitlines()
        self.assertEqual(sum(1 for line in lines if line.startswith('{"slug":')), 3)

    def test_nicknames_forward_reverse_and_scene(self):
        code, output, _ = run(self.v2, 'nicknames', 'テスト花子', '--query', '次郎')
        self.assertEqual(code, 0)
        self.assertIn('テスト次郎: 呼び方=次郎くん; 呼ばれ方=花子先輩', output)
        code, output, _ = run(self.v2, 'nicknames', 'テスト花子', '--reverse')
        self.assertIn('テスト次郎: テスト次郎→テスト花子=花子先輩; テスト花子→テスト次郎=次郎くん', output)
        self.assertIn('Test Taro: Test Taro→テスト花子=Hanako; テスト花子→Test Taro=Taro', output)
        data = core.Cache(self.v2).person('Test Taro').nicknames()
        self.assertEqual(data['records'][0]['counterpart_slug'], 'test_hanako')
        self.assertIsNone(data['records'][1]['counterpart_slug'])
        code, output, _ = run(self.v2, 'nicknames', 'Test Taro')
        self.assertNotIn('(視聴者)', output)
        code, output, _ = run(self.v2, 'nicknames', 'Test Taro', '--all')
        self.assertIn('(視聴者)', output)
        code, output, _ = run(self.v2, 'scene', 'テスト花子', 'Test Taro', '--brief')
        self.assertEqual(code, 0)
        # Both tables agree: one value. They differ: the other table's entry is shown too.
        self.assertIn('- テスト花子→Test Taro: Taro\n', output)
        self.assertIn('- Test Taro→テスト花子: Hanako ／ テスト花子側の表: —', output)
        self.assertIn('自称（呼称表の本人行）: 私、花子', output)

    def test_read_commands_and_text_output(self):
        code, output, _ = run(self.v2, 'read', 'テスト花子', '--section', '性格の補足', '--footnotes')
        self.assertEqual(code, 0)
        self.assertIn('5: #### 性格の補足', output)
        code, output, _ = run(self.v2, 'read', 'テスト花子', '--find', '明るい', '--footnotes')
        self.assertIn('3: 明るい。*1', output)
        self.assertIn('*1: 脚注本文', output)
        code, output, _ = run(self.v2, 'read', '--title', 'テスト花子【語録】', '--format', 'json')
        result = json.loads(output)
        self.assertEqual((result['page_id'], result['total_lines'], result['http_requests']), ('quotes', 5, 0))
        upper_escapes = re.sub(r'%[0-9a-f]{2}', lambda m: m.group().upper(), HANAKO_URL)
        code, output, _ = run(self.v2, 'read', '--url', upper_escapes + '#fragment', '--lines', '1')
        self.assertIn('Top [1]  > テスト花子', output)
        code, output, _ = run(self.v2, 'read', 'shared', 'friendships', '--find', '仲良し')
        self.assertIn('3: テスト次郎と仲良し', output)
        code, output, error = run(self.v2, 'read', 'テスト花子', '--section', '性格')
        self.assertEqual(code, 1)
        self.assertIn('複数の見出し', error)

    def test_url_only_pages_need_online_and_use_the_reader(self):
        code, _, error = run(self.v2, 'read', 'Test Taro', '語録')
        self.assertEqual(code, 1)
        self.assertIn('--online', error)
        pages = core.Cache(self.v2).person('Test Taro').pages()['pages']
        self.assertEqual([p['id'] for p in pages], ['main', 'quotes', 'videos_2021_data'])
        with tempfile.TemporaryDirectory() as td:
            fake = Path(td) / 'fake_reader.py'
            log = Path(td) / 'argv.json'
            fake.write_text('import json,sys\nopen(%r,"w").write(json.dumps(sys.argv[1:]))\n' % str(log))
            with contextlib.redirect_stdout(io.StringIO()):
                code = core.main(['--cache', str(self.v2), 'read', 'Test Taro', '語録', '--online', '--reader', str(fake),
                                  '--find', 'x', '--context', '1'])
            self.assertEqual(code, 0)
            argv = json.loads(log.read_text())
            self.assertEqual(argv[:2], ['--url', TARO_URL + '%a1%da%b8%ec%cf%bf%a1%db'])
            self.assertIn('--find', argv)

    def test_online_forwards_display_selection_and_reader_cache_options(self):
        with tempfile.TemporaryDirectory() as td:
            fake = Path(td) / 'fake_reader.py'
            log = Path(td) / 'argv.json'
            fake.write_text('import json,sys\nopen(%r,"w").write(json.dumps(sys.argv[1:]))\n'
                            'sys.exit(7)\n' % str(log))
            code, _, _ = run(self.v2, 'read', 'Test Taro', '語録', '--online',
                             '--reader', str(fake), '--links', '--footnotes', '--tables',
                             '--section', '見出し', '--find', '*1', '--context', '2',
                             '--start', '3', '--lines', '4', '--all', '--format', 'md',
                             '--reader-cache-dir', str(Path(td) / 'reader_cache'))
            self.assertEqual(code, 7)  # preserve reader failures as well as success
            argv = json.loads(log.read_text())
            # Parse with the real reader: the cache boolean flags have different
            # argument types and must be translated, not merely copied.
            parsed = reader.build_cli().parse_args(argv)
            self.assertEqual(parsed.url, TARO_URL + '%a1%da%b8%ec%cf%bf%a1%db')
            self.assertEqual(parsed.links, 'references')
            self.assertEqual(parsed.footnotes, 'markers')
            self.assertIn('--footnotes', argv)
            self.assertEqual((parsed.section, parsed.find, parsed.context), ('見出し', '*1', 2))
            self.assertEqual((parsed.start, parsed.lines, parsed.all), (3, 4, True))
            self.assertEqual(parsed.format, 'md')
            self.assertTrue(parsed.tables)
            self.assertEqual(parsed.cache_dir, Path(td) / 'reader_cache')
            self.assertNotIn('--all-links', argv)  # request selected references only

    def test_previous_missing_page_never_invokes_online_reader(self):
        with tempfile.TemporaryDirectory() as td:
            fake = Path(td) / 'fake_reader.py'
            log = Path(td) / 'called.txt'
            fake.write_text('open(%r,"w").write("called")\n' % str(log))
            for source in (['Test Taro', '語録'], ['--title', 'Unknown Page'],
                           ['--url', WIKI + 'Unknown%20Page']):
                with self.subTest(source=source):
                    code, _, error = run(self.v2, 'read', *source, '--previous',
                                         '--online', '--reader', str(fake))
                    self.assertEqual(code, 1)
                    self.assertIn('旧版はキャッシュ未収録', error)
                    self.assertFalse(log.exists())

    def test_find_search_and_other_commands(self):
        code, output, _ = run(self.v2, 'find', 'テスト花子', '仲良し')
        self.assertIn('表示 0 件', output)
        code, output, _ = run(self.v2, 'find', 'Test Taro', 'text')
        # EN people: card plus both distinct supplements are searched.
        self.assertIn('profile.json:', output)
        self.assertIn('card.json:', output)
        code, output, _ = run(self.v2, 'search', '仲良し')
        self.assertIn('共有\t交友関係:3: テスト次郎と仲良し', output)
        code, output, _ = run(self.v2, 'search', '台詞', '--region', 'JP', '--limit', '1')
        self.assertIn('表示上限 1 件', output)
        for argv in (['list'], ['list', '--region', 'EN'], ['show', '花子', '次郎'], ['show', '花子', '--digest'],
                     ['profile', '花子', '--field', 'official'], ['pages', '花子'], ['pages', 'shared'],
                     ['sources', 'Test Taro'], ['tables', '花子', 'main'], ['footnotes', '花子', 'main'],
                     ['verify']):
            with self.subTest(argv=argv):
                code, output, error = run(self.v2, *argv)
                self.assertEqual(code, 0, error)
                self.assertTrue(output)
        code, _, error = run(self.v2, 'show', 'Test Taro', '--digest')
        self.assertEqual(code, 1)

    def test_verify_reports_changed_files(self):
        with tempfile.TemporaryDirectory() as td:
            copy = Path(td) / 'c'
            shutil.copytree(self.v2, copy)
            path = copy / 'people/test_hanako/pages/quotes.txt'
            path.write_bytes(path.read_bytes().replace('説明'.encode(), '改変'.encode()))
            code, output, _ = run(copy, 'verify')
            self.assertEqual(code, 1)
            self.assertIn('changed people/test_hanako/pages/quotes.txt', output)

    def test_check_updates_compares_what_the_cache_holds(self):
        cache = core.Cache(self.v2)
        main = cache.person('テスト花子').page('main')
        live = list(main.lines)
        live[1] = '###  性格  [12]'                         # markup spacing and link number only
        headings = [dict(h) for h in main.headings()]
        self.assertEqual(core.comparable(main.lines, main.headings()), core.comparable(live, headings))
        live[2] = '明るい。追記*1'
        self.assertNotEqual(core.comparable(main.lines, main.headings()), core.comparable(live, headings))
        with tempfile.TemporaryDirectory() as td:
            fake = Path(td) / 'fake_reader.py'
            payload = {'lines': [{'line': i, 'text': t} for i, t in enumerate(live, 1)], 'headings': headings,
                       'page_metadata': {'last_updated': 'editor 2026年09月20日'}}
            # The fake prints UTF-8 bytes like the real reader. Its source stays ASCII:
            # Python 3.9 on Windows rejects long source lines holding multibyte text.
            live_json = Path(td) / 'live.json'
            live_json.write_text(json.dumps(payload, ensure_ascii=False), encoding='utf-8')
            fake.write_text('import sys\nsys.stdout.buffer.write(open(%r, "rb").read())\n' % str(live_json))
            code, output, _ = run(self.v2, 'check-updates', '花子', '--pages', 'main', '--reader', str(fake),
                                  '--format', 'json')
            result = json.loads(output)
            self.assertEqual(result['summary'], {'changed': 1}, json.dumps(result, ensure_ascii=False))


def reader_snapshot(url, title, body, *, ads=True):
    """A reader --all result for a synthetic wiki page, made by the real reader."""
    tail = '<div class="ads-box"><script src="https://js.ad-stir.com/js/adstir.js"></script></div>' if ads else ''
    html = (f'<html><head><title>{title} - ホロライブ非公式wiki</title></head><body><div id="page-body">'
            f'<div id="page-body-inner"><div class="user-area">{body}</div>{tail}</div></div></body></html>')
    args = reader.build_cli().parse_args(['--url', url, '--all', '--all-links', '--tables', '--nicknames', '--images',
                                          '--surrogate-charrefs', 'utf16'])
    metadata = {'url': url, 'content_type': 'text/html; charset=utf-8', 'source': 'http', 'http_status': 200,
                'fetched_at': '2026-09-23T01:00:00+00:00', 'from_cache': False}
    return reader.make_result(html.encode('utf-8'), metadata, args)


def write_snapshots(directory):
    directory.mkdir(parents=True, exist_ok=True)
    pages = {
        'test_taro__main': reader_snapshot(TARO_URL, 'Test Taro', (
            '<h3>公式情報</h3><table><tr><td colspan="2">Test Taro（てすと・たろう）</td></tr>'
            '<tr><th>X(Twitter)</th><td><a href="https://x.com/testtaro">@testtaro</a></td></tr>'
            '<tr><th>誕生日</th><td>1月2日</td></tr></table>'
            '<h3>性格</h3><p>明るいサメ。<a href="https://www.youtube.com/watch?v=abc">初配信</a></p>')),
        'test_hanako__quotes': reader_snapshot(HANAKO_URL + '%A1%DA%B8%EC%CF%BF%A1%DB', 'テスト花子【語録】',
                                               '<p>導入</p><h4>口癖</h4><p>新しい台詞</p>'),
        'shared__group_myth': reader_snapshot(WIKI + 'Myth', 'Myth', '<h3>メンバー</h3><p>Test Taro</p>'),
        # The reader takes the article title from the URL: EUC-JP for ホロライブ【呼称一覧】.
        'shared__nicknames_all': reader_snapshot(WIKI + '%A5%DB%A5%ED%A5%E9%A5%A4%A5%D6%A1%DA%B8%C6%BE%CE%B0%EC%CD%F7%A1%DB',
                                                 'ホロライブ【呼称一覧】', (
            '<h4>Test Taro【呼称一覧】</h4><table><tr><th>相手</th><th>呼び方</th><th>呼ばれ方</th></tr>'
            '<tr><td>テスト花子</td><td>Hanako-senpai</td><td>Taro</td></tr></table>')),
    }
    for name, data in pages.items():
        (directory / (name + '.json')).write_text(json.dumps(data, ensure_ascii=False), encoding='utf-8')
    return pages


class OnlineSnapshotTests(unittest.TestCase):
    """v3: pages read online by the ad-filtering reader, merged into the cache."""

    @classmethod
    def setUpClass(cls):
        cls.tmp = tempfile.TemporaryDirectory()
        root = Path(cls.tmp.name)
        cls.v1, cls.v1_files = write_v1(root / 'in')
        cls.snapshots = root / 'snapshots'
        cls.pages = write_snapshots(cls.snapshots)
        audit = root / 'report.json'
        audit.write_text('{"summary": {}}', encoding='utf-8')
        cls.v3 = root / 'out' / 'hololive_wiki_person_cache'
        cls.report = builder.build(root / 'in', cls.v3, wiki_root_json=wiki_root(root / 'root.json'),
                                   snapshots_dir=cls.snapshots, audit_files=[audit])

    @classmethod
    def tearDownClass(cls):
        cls.tmp.cleanup()

    def test_v1_is_still_restored_byte_for_byte(self):
        self.assertEqual(self.report['restore_verified'], len(self.v1_files))
        self.assertEqual(self.report['recipe_fallbacks'], [])
        self.assertEqual(self.report['totals']['online_snapshot_pages'], 4)
        with tempfile.TemporaryDirectory() as td:
            builder.restore_v1(self.v3, Path(td) / 'v1')
            for name, data in self.v1_files.items():
                self.assertEqual((Path(td) / 'v1' / name).read_bytes(), data, name)

    def test_url_only_page_gets_the_snapshot_text_links_and_profile(self):
        cache = core.Cache(self.v3)
        main = cache.person('Test Taro').page('main')
        self.assertEqual(main.lines, [line['text'] for line in self.pages['test_taro__main']['lines']])
        self.assertEqual(main.origin, 'online_snapshot')
        code, output, _ = run(self.v3, 'read', 'Test Taro', '--find', '初配信', '--links')
        self.assertEqual(code, 0)
        self.assertRegex(output, r'\[\d+\] https://www\.youtube\.com/watch\?v=abc')
        self.assertIn('オンライン取得', output)
        info = cache.person('Test Taro').info()
        self.assertEqual(info['official'], {'X(Twitter)': '@testtaro', '誕生日': '1月2日'})
        self.assertEqual(cache.resolve('@testtaro')['slug'], 'test_taro')        # handles come from the table
        self.assertEqual(info['counts']['pages_from_online_snapshots'], 1)
        tables = main.tables('公式情報')
        self.assertEqual(tables[0]['rows'][0], ['Test Taro（てすと・たろう）'] * 2)   # colspan filled like v1
        # Other pages of the person stay URL-only.
        code, _, error = run(self.v3, 'read', 'Test Taro', '語録')
        self.assertIn('--online', error)

    def test_newer_snapshot_replaces_a_cached_page_and_keeps_the_old_one(self):
        cache = core.Cache(self.v3)
        quotes = cache.person('テスト花子').page('語録')
        self.assertIn('新しい台詞', quotes.lines)
        older = quotes.previous()
        self.assertEqual(older.lines, ['導入', '#### 口癖', '##### 一行目の台詞', '二行目の台詞  [9]', '説明'])
        code, output, _ = run(self.v3, 'read', 'テスト花子', '語録', '--previous', '--find', '説明')
        self.assertIn('5: 説明', output)
        self.assertIn('元キャッシュ', output)
        code, output, _ = run(self.v3, 'pages', 'テスト花子')
        self.assertIn('旧版あり --previous', output)
        # The v1 record is rebuilt from pages/previous/ (checked byte for byte above).
        self.assertTrue((self.v3 / 'people/test_hanako/pages/previous/quotes.txt').is_file())

    def test_previous_uses_its_own_version_metadata(self):
        cache = core.Cache(self.v3)
        current = cache.person('テスト花子').page('語録')
        old = current.previous()
        self.assertEqual(current.entry['reader_version'], reader.VERSION)
        self.assertIsNone(old.entry.get('reader_version'))  # v1 does not record it
        self.assertEqual(old.entry['links'], 0)
        self.assertEqual(old.entry['sections'], old.meta['sections'])
        self.assertEqual(old.entry['tables'], old.meta['tables'])
        self.assertEqual(old.entry['footnotes'], old.meta['footnotes'])
        self.assertEqual(old.origin, 'v1_cache')
        self.assertEqual(old.links(), {})
        self.assertEqual(old.entry['line_count'], len(old.lines))
        code, output, _ = run(self.v3, 'read', 'テスト花子', '語録',
                              '--previous', '--all', '--format', 'json')
        self.assertEqual(code, 0)
        result = json.loads(output)
        self.assertIsNone(result['reader_version'])
        self.assertEqual(result['origin'], 'v1_cache')
        self.assertEqual(result['total_lines'], 5)
        # Reading previous metadata must not alter the current entry or bytes
        # used by restore-v1.
        self.assertEqual(current.entry['reader_version'], reader.VERSION)
        restored = builder.restore_files(lambda path: (self.v3 / path).read_bytes())
        for name, data in self.v1_files.items():
            self.assertEqual(restored['files'][name], data, name)

    def test_previous_with_online_still_reads_the_saved_old_page(self):
        # --online is a fallback for absent text, not a force-refresh switch.
        # An unavailable reader proves this path stays offline.
        code, output, _ = run(self.v3, 'read', 'テスト花子', '語録', '--previous',
                              '--online', '--reader', str(self.v3 / 'missing_reader.py'),
                              '--find', '説明')
        self.assertEqual(code, 0)
        self.assertIn('5: 説明', output)
        self.assertIn('元キャッシュ', output)

    def test_shared_snapshots_and_related_pages(self):
        cache = core.Cache(self.v3)
        myth = cache.shared().page('group_myth')
        self.assertIn('Test Taro', myth.lines)
        related = cache.person('Test Taro').related()
        self.assertEqual(related[0]['shared_page'], 'group_myth')
        self.assertEqual(cache.locate(url=WIKI + 'Myth').title, 'Myth')
        code, output, _ = run(self.v3, 'nicknames', 'Test Taro')
        self.assertIn('read shared nicknames_all --section "Test Taro【呼称一覧】"', output)
        code, output, _ = run(self.v3, 'search', 'Hanako-senpai')
        self.assertIn('共有\tホロライブ【呼称一覧】', output)

    def test_guides_for_readers_and_ai_assistants(self):
        start = (self.v3 / 'START_HERE.md').read_text(encoding='utf-8')
        for text in ('INDEX.md', 'PROFILE.md', '資料です', '今回の会話で利用者が採用している場合だけ', '広告URLは0件'):
            self.assertIn(text, start)
        index = (self.v3 / 'INDEX.md').read_text(encoding='utf-8')
        self.assertIn('[PROFILE](people/test_taro/PROFILE.md)', index)
        self.assertIn('`group_myth`', index)
        profile = (self.v3 / 'people/test_taro/PROFILE.md').read_text(encoding='utf-8')
        self.assertIn('[pages/main.txt](pages/main.txt)', profile)
        self.assertIn('**X(Twitter)**: @testtaro', profile)
        self.assertIn('read shared group_myth', profile)
        rows = [json.loads(line) for line in (self.v3 / 'pages.jsonl').read_text(encoding='utf-8').splitlines()]
        self.assertTrue(any(row['owner'] == 'test_taro' and row['text'] == 'people/test_taro/pages/main.txt'
                            for row in rows))
        scan = json.loads((self.v3 / 'audits/cached_text_ad_scan.json').read_text(encoding='utf-8'))
        self.assertTrue(scan['checked'])
        self.assertEqual(scan['totals']['ad_urls_structural'] + scan['totals']['ad_urls_textual'], 0)
        self.assertEqual(scan['totals']['previous_versions'], 1)
        self.assertTrue((self.v3 / 'audits/online_2026-09-23/report.json').is_file())
        for launcher in ('hololive_cache.cmd', 'selftest.cmd', 'tools/hololive_wiki_reader.cmd'):
            data = (self.v3 / launcher).read_bytes()
            self.assertIn(b'\r\n', data)
            data.decode('ascii')
        self.assertTrue((self.v3 / 'tools/hololive_adblock.py').is_file())
        code, output, _ = run(self.v3, 'verify')
        self.assertEqual(code, 0, output)

    def test_reader_lookup_prefers_tools(self):
        # Inside the archive the loader sits beside tools/, never using vendor/'s v1 reader.
        from unittest import mock
        with mock.patch.object(core, 'ROOT', str(self.v3)):
            self.assertEqual(Path(core.find_reader()), self.v3 / 'tools' / 'hololive_wiki_reader_v31.py')

    def test_unsafe_or_mismatched_snapshots_are_refused(self):
        good = self.pages['test_taro__main']
        broken = {
            'not strict': {**good, 'ad_filter': {**good['ad_filter'], 'mode': 'off'}},
            'ad url': {**good, 'ad_filter': {**good['ad_filter'], 'output_scan': {'ad_urls_structural_count': 1}}},
            'unclosed': {**good, 'article_integrity': {'closing_tag_observed': False}},
            'partial': {**good, 'lines': good['lines'][1:]},
            'other site': {**good, 'url': 'https://example.com/x'},
        }
        for reason, data in broken.items():
            with self.subTest(reason=reason), self.assertRaises(builder.BuildError):
                builder.check_snapshot(data, reason)
        with tempfile.TemporaryDirectory() as td:
            folder = Path(td) / 'snapshots'
            folder.mkdir()
            (folder / 'test_taro__quotes.json').write_text(json.dumps(good, ensure_ascii=False), encoding='utf-8')
            with self.assertRaisesRegex(builder.BuildError, 'the snapshot is'):
                builder.build(self.v1.parent, Path(td) / 'a', snapshots_dir=folder)
            (folder / 'test_taro__quotes.json').unlink()
            (folder / 'nobody__main.json').write_text(json.dumps(good, ensure_ascii=False), encoding='utf-8')
            with self.assertRaisesRegex(builder.BuildError, 'nobody__main'):
                builder.build(self.v1.parent, Path(td) / 'b', snapshots_dir=folder)


@unittest.skipUnless(os.environ.get('PERSON_CACHE_V1'), 'set PERSON_CACHE_V1 to an extracted v1 cache')
class RealArchiveTests(unittest.TestCase):
    def test_real_archive_round_trip(self):
        with tempfile.TemporaryDirectory() as td:
            report = builder.build(os.environ['PERSON_CACHE_V1'], Path(td) / 'v2')
            self.assertEqual(report['recipe_fallbacks'], [])
            self.assertEqual(report['restore_verified'], report['v1_files'])
            cache = core.Cache(Path(td) / 'v2')
            self.assertEqual(len(cache.people), report['totals']['people'])


if __name__ == '__main__':
    unittest.main()
