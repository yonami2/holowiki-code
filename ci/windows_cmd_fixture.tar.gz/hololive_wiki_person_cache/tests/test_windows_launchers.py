"""Windows: the .cmd launchers of the person cache, run through cmd.exe, and source portability. No HTTP.

A small cache is built from test_person_cache's synthetic v1 cache and reader
snapshots, then its launchers are started the way a Windows user starts them:
Japanese arguments, UTF-8 output, and the exit code passed through.
"""
import os
from pathlib import Path
import subprocess
import tempfile
import unittest


@unittest.skipUnless(os.name == 'nt', 'runs the .cmd launchers through cmd.exe (Windows only)')
class WindowsLauncherTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        import test_person_cache as helpers
        cls.tmp = tempfile.TemporaryDirectory()
        root = Path(cls.tmp.name)
        helpers.write_v1(root / 'in')
        helpers.write_snapshots(root / 'snapshots')
        cls.cache = root / 'out' / 'hololive_wiki_person_cache'
        helpers.builder.build(root / 'in', cls.cache, wiki_root_json=helpers.wiki_root(root / 'root.json'),
                              snapshots_dir=root / 'snapshots')

    @classmethod
    def tearDownClass(cls):
        cls.tmp.cleanup()

    def launch(self, script, *args):
        # A .cmd file started directly is run by cmd.exe, as when typed at a prompt.
        return subprocess.run([str(self.cache / script), *args], capture_output=True, cwd=str(self.cache))

    def test_cache_launcher_passes_japanese_arguments_and_prints_utf8(self):
        result = self.launch('hololive_cache.cmd', 'read', 'テスト花子', '語録', '--find', '新しい台詞')
        self.assertEqual(result.returncode, 0, result.stderr.decode('utf-8', 'replace'))
        output = result.stdout.decode('utf-8')
        self.assertIn('新しい台詞', output)
        self.assertIn('テスト花子【語録】', output)

    def test_cache_launcher_returns_the_exit_code(self):
        result = self.launch('hololive_cache.cmd', 'show', '存在しない人')
        self.assertEqual(result.returncode, 1)
        self.assertIn('該当する人物がいません', result.stderr.decode('utf-8'))

    def test_verify_through_the_launcher(self):
        result = self.launch('hololive_cache.cmd', 'verify')
        self.assertEqual(result.returncode, 0, result.stdout.decode('utf-8', 'replace'))
        self.assertIn('"ok": true', result.stdout.decode('utf-8'))

    def test_reader_launcher_reads_a_saved_page_offline(self):
        page = Path(self.tmp.name) / 'saved.html'
        page.write_bytes('<html><head><title>保存ページ</title></head><body><div id="page-body-inner">'
                         '<div class="user-area"><h3>見出し</h3><p>本文の行</p></div></div></body></html>'.encode('utf-8'))
        result = self.launch('tools\\hololive_wiki_reader.cmd', '--url', 'https://seesaawiki.jp/hololivetv/d/test',
                             '--html-file', str(page), '--content-type', 'text/html; charset=utf-8',
                             '--all', '--format', 'text')
        self.assertEqual(result.returncode, 0, result.stderr.decode('utf-8', 'replace'))
        output = result.stdout.decode('utf-8')
        self.assertIn('本文の行', output)
        self.assertIn('ad_filter: strict', output)


class SourcePortabilityTests(unittest.TestCase):
    def test_no_long_source_line_holds_multibyte_text(self):
        # Python 3.9's tokenizer reads a line in 512-byte pieces on Windows and
        # rejects a multibyte character split between two pieces as non-UTF-8.
        root = Path(__file__).resolve().parents[1]
        skip = {'legacy', 'vendor', 'scripts', 'audits', 'people', 'shared', '.git'}
        long_lines = []
        for path in sorted(root.rglob('*.py')):
            if skip.intersection(path.relative_to(root).parts):
                continue
            for number, line in enumerate(path.read_bytes().split(b'\n'), 1):
                if len(line) > 400 and any(byte > 127 for byte in line):
                    long_lines.append(f'{path.relative_to(root)}:{number} ({len(line)} bytes)')
        self.assertEqual(long_lines, [])


if __name__ == '__main__':
    unittest.main()
