"""Advertisement filtering: rules, reader integration and network guard. No HTTP."""
import importlib.util
import json
import os
from pathlib import Path
import sys
import unittest
from unittest.mock import patch

REPO = Path(__file__).resolve().parents[1]
# The repository keeps the reader at its root; the person cache archive under tools/.
_READER = next((path for path in (REPO / 'hololive_wiki_reader_v31.py', REPO / 'tools' / 'hololive_wiki_reader_v31.py')
                if path.is_file()), REPO / 'hololive_wiki_reader_v31.py')
READER = Path(os.environ.get('READER_UNDER_TEST', str(_READER)))


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


adblock = load('hololive_adblock', READER.with_name('hololive_adblock.py'))
reader = load('adblock_reader', READER)
URL = 'https://seesaawiki.jp/hololivetv/d/Test'

# The layout Seesaa serves: header ad before the article container, then the
# article, ad box, share buttons, comments and a video ad player inside it.
PAGE = '''<html><head><title>Test</title>
<script src="https://cdn.browsiprod.com/bootstrap/bootstrap.js" id="browsi-tag"></script></head><body>
<div class="adsense-box adsense-main-top" id="adsense-location-top"><script src="https://js.ad-stir.com/js/adstir.js"></script></div>
<div id="seesaa-bnr"><script>document.write('<ins data-revive-zoneid="190"></ins>');</script></div>
<div id="page-body"><div id="page-body-inner" class="box-inner">
<div class="user-area">{article}</div>
<div class="ads-box"><ul><li><noscript><a href="http://tx.creativecarrer.com/ck.php"><img src="http://tx.creativecarrer.com/avw.php" alt="AD TEXT"></a></noscript></li>
<li><div id="crt-1607058">CRITEO SLOT</div></li></ul></div>
<div id="information-box"><a href="https://seesaawiki.jp/hololivetv/e/edit?id=1">このページを編集する</a></div>
<div id="page-social-link-bottom"><a href="https://b.hatena.ne.jp/entry/x">SHARE</a></div>
<div id="comment-box"><div class="text"><p>COMMENT: unrelated product talk</p></div></div>
<div class="gliaplayer-container" data-slot="seesaawiki_desktop">VIDEO AD</div>
<script src="https://player.gliacloud.com/player/seesaawiki_desktop" async></script>
</div></div>
<div class="side-box side-adsense"><h2>AD</h2><div class="ad-extra">SIDE AD</div></div>
</body></html>'''
ARTICLE = ('<h3>性格</h3><p>本文の一行目</p>'
           '<p>PR担当として広告に起用された<a href="https://www.jr-central.co.jp/collab">JR東海コラボ</a></p>'
           '<iframe src="https://www.youtube.com/embed/abc"></iframe>'
           '<p><a href="https://www.amazon.co.jp/dp/B0?tag=wiki-22">CD（Amazon）</a></p>')


def run(html, *options):
    args = reader.build_cli().parse_args(['--url', URL, '--all', '--all-links', '--images', *options])
    return reader.make_result(html.encode('utf-8'), {'url': URL, 'content_type': 'text/html; charset=utf-8'}, args)


class RuleTests(unittest.TestCase):
    def test_observed_seesaa_slots_and_hosts(self):
        cases = [('div', {'class': 'adsense-box adsense-main-top'}), ('div', {'class': 'ads-box'}),
                 ('div', {'id': 'seesaa-bnr'}), ('div', {'id': 'crt-1607058'}), ('ins', {'data-revive-zoneid': '190'}),
                 ('div', {'class': 'gliaplayer-container'}), ('div', {'class': 'side-box side-adsense'}),
                 ('script', {'src': 'https://js.ad-stir.com/js/adstir.js'}), ('script', {'src': '//static.criteo.net/js/x.js'}),
                 ('script', {'src': '//j.microad.net/js/compass.js'}), ('img', {'src': 'http://tx.creativecarrer.com/avw.php'}),
                 ('script', {'src': 'https://player.gliacloud.com/player/x'}),
                 ('iframe', {'src': 'https://googleads.g.doubleclick.net/x'})]
        for tag, attrs in cases:
            with self.subTest(tag=tag, attrs=attrs):
                self.assertEqual(adblock.classify_element(tag, attrs, URL)[0], 'ad')

    def test_no_substring_or_keyword_matches(self):
        keep = [('div', {'class': 'shadow-box adventure'}), ('a', {'href': 'https://example.com/ad/banner'}),
                ('a', {'href': 'https://notad-stir.com/x'}), ('img', {'src': 'https://i.ytimg.com/vi/x/0.jpg'}),
                ('a', {'href': 'https://hololive.hololivepro.com/'}), ('p', {'class': 'pr ad'}),
                ('div', {'id': 'crt'}), ('a', {'href': 'https://www.amazon.co.jp/dp/B0?tag=x'})]
        for tag, attrs in keep:
            with self.subTest(tag=tag, attrs=attrs):
                self.assertIsNone(adblock.classify_element(tag, attrs, URL))

    def test_article_containers_are_never_classified(self):
        for attrs in ({'class': 'user-area ads-box'}, {'class': 'footer-footnote ad-extra'},
                      {'id': 'page-body-inner', 'class': 'adsense-box'}):
            with self.subTest(attrs=attrs):
                self.assertIsNone(adblock.classify_element('div', attrs, URL))

    def test_url_forms_and_duplicate_attributes(self):
        # srcset candidates, host case and trailing dot, userinfo, a query right
        # after the host: all resolve to the real host, never by substring.
        for attrs in ([('srcset', 'a.jpg 1x, https://cas.criteo.com/y.png 2x')], [('src', 'HTTPS://JS.Ad-Stir.COM./x')],
                      [('href', 'https://user@static.criteo.net/x')], [('src', 'https://sub.doubleclick.net?x=/y')]):
            with self.subTest(attrs=attrs):
                self.assertEqual(adblock.classify_element('img', attrs, URL)[0], 'ad')
        # The per-authority cache must not leak a verdict to another host.
        self.assertIsNone(adblock.classify_element('a', [('href', 'https://sub.doubleclick.net.example.org/x')], URL))
        self.assertIsNone(adblock.classify_element('a', [('href', 'https://example.org/https://doubleclick.net/')], URL))
        # With duplicate attributes every value counts, and the article guard wins.
        self.assertIsNone(adblock.classify_element('div', [('class', 'ads-box'), ('class', 'user-area')], URL))
        self.assertEqual(adblock.classify_element('div', [('class', 'ads-box'), ('class', 'x')], URL),
                         ('ad', 'ad_class:ads-box'))

    def test_url_categories(self):
        self.assertEqual(adblock.url_category('https://pagead2.googlesyndication.com/x'), 'ad')
        self.assertEqual(adblock.url_category('https://www.googletagmanager.com/gtag/js'), 'tracking')
        self.assertEqual(adblock.url_category('https://px.a8.net/svt/ejp?a8mat=1'), 'affiliate')
        self.assertEqual(adblock.url_category('https://www.amazon.co.jp/dp/B0?tag=wiki-22'), 'affiliate')
        self.assertIsNone(adblock.url_category('https://www.amazon.co.jp/dp/B0'))
        self.assertIsNone(adblock.url_category('https://seesaawiki.jp/hololivetv/d/x'))

    def test_browser_ignored_ascii_characters_do_not_hide_ad_hosts(self):
        for whitespace in ('\t', '\r', '\n'):
            url = 'https://js.ad-' + whitespace + 'stir.com/ad'
            with self.subTest(whitespace=repr(whitespace)):
                self.assertEqual(adblock.classify_element('iframe', {'src': url}, URL)[0], 'ad')
                self.assertEqual(adblock.scan_output({'embedded_media': [{'src': url}]})
                                 ['ad_urls_structural_count'], 1)

    def test_nested_fields_and_image_alt_keep_the_correct_scan_category(self):
        scan = adblock.scan_output({
            'images': [{'src': 'https://example.org/a.png', 'alt': 'https://js.ad-stir.com/alt'}],
            'footnotes': {'1': {'marker_titles': [{'text': 'https://js.ad-stir.com/title'}],
                               'footer_entries': [{'embedded_media': [{'src': 'https://js.ad-stir.com/frame'}]}]}}
        })
        self.assertEqual(scan['ad_urls_textual_count'], 2)
        self.assertEqual(scan['ad_urls_structural_count'], 1)

    def test_separate_urls_survive_url_whitespace_normalization(self):
        for separator in ('\t', '\r', '\n', '\r\n'):
            with self.subTest(separator=repr(separator)):
                scan = adblock.scan_output({'footnotes': {'1': {'marker_titles': [
                    {'text': 'https://seesaawiki.jp/hololivetv/' + separator + 'https://js.ad-stir.com/ad'}]}}})
                self.assertEqual(scan['ad_urls_textual_count'], 1)


class ReaderIntegrationTests(unittest.TestCase):
    def test_ads_and_chrome_never_reach_the_article(self):
        result = run(PAGE.format(article=ARTICLE))
        text = '\n'.join(line['text'] for line in result['lines'])
        for noise in ('AD TEXT', 'CRITEO', 'COMMENT', 'VIDEO AD', 'SIDE AD', 'SHARE', 'このページを編集する'):
            self.assertNotIn(noise, text)
        self.assertIn('PR担当として広告に起用された', text)          # words are never used to delete text
        self.assertIn('https://www.jr-central.co.jp/collab', result['links'].values())
        scan = result['ad_filter']['output_scan']
        self.assertEqual(scan['ad_urls_structural_count'], 0)
        self.assertEqual(scan['affiliate_urls_count'], 1)            # kept as a source, reported
        self.assertTrue(any('affiliate' in warning for warning in result['warnings']))

    def test_filter_does_not_change_a_clean_article(self):
        html = PAGE.format(article=ARTICLE)
        strict, off = run(html), run(html, '--ad-filter', 'off')
        for key in ('lines', 'links', 'link_original_hrefs', 'images', 'headings', 'footnotes', 'total_lines'):
            self.assertEqual(strict[key], off[key], key)
        self.assertEqual(off['ad_filter'], {'mode': 'off'})

    def test_ads_inside_the_article_are_removed(self):
        article = ARTICLE + ('<p>後続の本文</p><div class="ads-box">INNER AD</div>'
                             '<a href="https://tx.creativecarrer.com/ck.php"><img src="https://tx.creativecarrer.com/a.gif" alt="BANNER"></a>'
                             '<ins class="adsbygoogle" data-ad-client="ca-pub-1">ADSENSE</ins>'
                             '<iframe src="https://googleads.g.doubleclick.net/pagead"></iframe><p>最後の本文</p>')
        strict, off = run(PAGE.format(article=article)), run(PAGE.format(article=article), '--ad-filter', 'off')
        text = '\n'.join(line['text'] for line in strict['lines'])
        for noise in ('INNER AD', 'BANNER', 'ADSENSE'):
            self.assertNotIn(noise, text)
        self.assertIn('後続の本文', text)
        self.assertIn('最後の本文', text)
        self.assertFalse(any('creativecarrer' in url for url in strict['links'].values()))
        self.assertTrue(any('creativecarrer' in url for url in off['links'].values()))
        self.assertEqual([i['src'] for i in strict['images']], [])
        self.assertGreaterEqual(strict['ad_filter']['skipped']['by_kind']['ad'], 4)

    def test_fallback_container_excludes_comments_and_ads(self):
        # Without .user-area the reader falls back to the whole container.
        html = PAGE.format(article='').replace('<div class="user-area"></div>', '<p>記事本文</p>')
        text = '\n'.join(line['text'] for line in run(html)['lines'])
        self.assertIn('記事本文', text)
        for noise in ('COMMENT', 'AD TEXT', 'CRITEO', 'VIDEO AD', 'SHARE', 'このページを編集する'):
            self.assertNotIn(noise, text)
        unfiltered = '\n'.join(line['text'] for line in run(html, '--ad-filter', 'off')['lines'])
        self.assertIn('COMMENT', unfiltered)

    def test_strict_refuses_an_unrecognized_ad_and_report_keeps_it(self):
        html = PAGE.format(article=ARTICLE + '<a href="https://tx.creativecarrer.com/ck.php">x</a>')
        with patch.object(adblock, 'classify_element', return_value=None):
            with self.assertRaises(reader.ReaderError) as caught:
                run(html)
            self.assertEqual(caught.exception.code, 'ad_content_detected')
            result = run(html, '--ad-filter', 'report')
        self.assertEqual(result['ad_filter']['output_scan']['ad_urls_structural_count'], 1)
        self.assertTrue(any('ad element was not recognized' in warning for warning in result['warnings']))

    def test_plain_text_urls_are_refused_in_strict_and_preserved_in_report(self):
        html = PAGE.format(article='<p>広告タグは https://js.ad-stir.com/js/adstir.js と書かれていた</p>')
        with self.assertRaises(reader.ReaderError) as caught:
            run(html)
        self.assertEqual(caught.exception.code, 'ad_content_detected')
        result = run(html, '--ad-filter', 'report')
        self.assertEqual(result['ad_filter']['output_scan']['ad_urls_textual_count'], 1)
        self.assertEqual(result['ad_filter']['output_scan']['ad_urls_structural_count'], 0)
        self.assertIn('https://js.ad-stir.com/js/adstir.js', str(result['lines']))

    def test_hidden_content_is_scanned_before_display_selection(self):
        html = PAGE.format(article='<h3>安全な節</h3><p>表示対象</p><h3>別の節</h3>'
                                   '<p>https://js.ad-stir.com/ad</p>')
        for options in (('--find', '表示対象'), ('--section', '安全な節'),
                        ('--links', 'off', '--footnotes', 'off'), ('--lines', '1')):
            with self.subTest(options=options), self.assertRaises(reader.ReaderError) as caught:
                run(html, *options)
            self.assertEqual(caught.exception.code, 'ad_content_detected')

    def test_image_alt_is_textual_and_refused_without_images_option(self):
        html = PAGE.format(article='<p>本文</p><img src="https://example.org/a.png" '
                                   'alt="https://js.ad-stir.com/ad">')
        args = reader.build_cli().parse_args(['--url', URL, '--links', 'off', '--lines', '1'])
        with self.assertRaises(reader.ReaderError) as caught:
            reader.make_result(html.encode(), {'url': URL, 'content_type': 'text/html; charset=utf-8'}, args)
        self.assertEqual(caught.exception.details['ad_filter']['output_scan']['ad_urls_textual_count'], 1)

    def test_conflicting_footnote_title_is_checked_even_when_footnotes_are_hidden(self):
        html = PAGE.format(article='<p>本文<a href="#footer-footnote1" '
                                   'title="https://js.ad-stir.com/ad">*1</a></p>')
        html = html.replace('<div class="ads-box">', '<div class="footer-footnote"><ul><li>'
                            '<a name="footer-footnote1">*1</a>: 正当な出典</li></ul></div>'
                            '<div class="ads-box">', 1)
        for options in ((), ('--footnotes', 'off')):
            with self.subTest(options=options), self.assertRaises(reader.ReaderError) as caught:
                run(html, *options)
            self.assertEqual(caught.exception.code, 'ad_content_detected')
        report = run(html, '--ad-filter', 'report')
        self.assertEqual(report['ad_filter']['output_scan']['ad_urls_textual_count'], 1)
        self.assertIn('marker_titles', str(report['ad_filter']['output_scan']['ad_urls_textual']))

    def test_unrecognized_iframe_is_scanned_even_without_visible_text(self):
        html = PAGE.format(article='<p>本文</p><iframe src="https://js.ad-stir.com/ad"></iframe>')
        with patch.object(adblock, 'classify_element', return_value=None):
            with self.assertRaises(reader.ReaderError) as caught:
                run(html, '--links', 'off', '--footnotes', 'off')
            self.assertEqual(caught.exception.details['ad_filter']['output_scan']['ad_urls_structural_count'], 1)
            report = run(html, '--ad-filter', 'report')
            self.assertIn('embedded_media', str(report['ad_filter']['output_scan']['ad_urls_structural']))

    def test_metadata_is_scanned_and_diagnostic_examples_are_not(self):
        html = PAGE.format(article='<p>本文</p>').replace('<title>Test</title>',
                                                       '<title>https://js.ad-stir.com/ad</title>')
        with self.assertRaises(reader.ReaderError) as caught:
            run(html)
        self.assertEqual(caught.exception.code, 'ad_content_detected')
        clean = run(PAGE.format(article='<p>本文</p>'))
        self.assertEqual(clean['ad_filter']['output_scan']['ad_urls_textual_count'], 0)

    def test_cached_foreign_module_does_not_bypass_missing_sibling(self):
        # A module loaded by another reader may be in sys.modules. It must not
        # make this reader's missing adjacent module silently acceptable.
        with patch.object(reader, '__file__', str(REPO / 'nowhere' / 'reader.py')):
            with self.assertRaises(reader.ReaderError) as caught:
                run(PAGE.format(article=ARTICLE))
        self.assertEqual(caught.exception.code, 'ad_filter_missing')

    def test_text_output_states_the_filter(self):
        args = reader.build_cli().parse_args(['--url', URL, '--format', 'text'])
        result = reader.make_result(PAGE.format(article=ARTICLE).encode(), {'url': URL, 'content_type': 'text/html; charset=utf-8'}, args)
        self.assertIn('ad_filter: strict; skipped ad slots', reader.render_result(result, args))

    def test_missing_module_fails_closed(self):
        with patch.dict(sys.modules, {'hololive_adblock': None}), \
                patch.object(reader, '__file__', str(REPO / 'nowhere' / 'reader.py')):
            del sys.modules['hololive_adblock']
            with self.assertRaises(reader.ReaderError) as caught:
                run(PAGE.format(article=ARTICLE))
            self.assertEqual(caught.exception.code, 'ad_filter_missing')
            self.assertEqual(run(PAGE.format(article=ARTICLE), '--ad-filter', 'off')['ad_filter']['mode'], 'off')


class NetworkTests(unittest.TestCase):
    def test_guard_allows_only_the_wiki(self):
        self.assertEqual(adblock.guard_request('https://seesaawiki.jp/hololivetv/'), 'https://seesaawiki.jp/hololivetv/')
        for url, reason in (('https://js.ad-stir.com/js/adstir.js', 'advertising host'),
                            ('https://www.google-analytics.com/analytics.js', 'tracking host'),
                            ('http://seesaawiki.jp/hololivetv/', 'not the wiki host'),
                            ('https://example.com/', 'not the wiki host')):
            with self.subTest(url=url), self.assertRaises(adblock.BlockedRequest) as caught:
                adblock.guard_request(url)
            self.assertEqual(caught.exception.reason, reason)

    def test_network_log_records_and_blocks_http_destinations(self):
        # Plain HTTPConnection: only the destination bookkeeping is under test.
        Connection = reader.http.client.HTTPConnection
        opened = []
        with patch.object(Connection, 'connect', lambda self: opened.append(self.host)) as fake:
            with adblock.NetworkLog(block=True) as log:
                Connection('seesaawiki.jp').connect()
                proxied = Connection('127.0.0.1', 38207)
                proxied.set_tunnel('seesaawiki.jp')
                proxied.connect()                                    # the real site behind a proxy
                with self.assertRaises(adblock.BlockedRequest):
                    Connection('js.ad-stir.com').connect()
            self.assertIs(Connection.connect, fake)                  # restored on exit
        self.assertEqual(opened, ['seesaawiki.jp', '127.0.0.1'])     # the ad host was never opened
        summary = log.summary()
        self.assertEqual(summary['http_destinations'], ['js.ad-stir.com', 'seesaawiki.jp'])
        self.assertEqual(summary['ad_destinations'], ['js.ad-stir.com'])
        self.assertEqual(summary['blocked'], ['js.ad-stir.com'])
        self.assertTrue(issubclass(adblock.BlockedRequest, OSError))

    def test_fetch_records_request_hosts(self):
        class Response:
            headers = reader.Message()
            def __init__(self):
                self.headers['Content-Type'] = 'text/html; charset=utf-8'
                self.body = [PAGE.format(article=ARTICLE).encode()]
            def __enter__(self): return self
            def __exit__(self, *a): return False
            def getcode(self): return 200
            def geturl(self): return URL
            def read(self, size=-1): return self.body.pop() if self.body else b''
        class Opener:
            def open(self, request, timeout=None): return Response()
        raw, metadata = reader.fetch_page(URL, opener=Opener())
        self.assertEqual(metadata['network_hosts'], ['seesaawiki.jp'])


class InventoryTests(unittest.TestCase):
    def test_inventory_places_every_slot(self):
        report = adblock.inventory(PAGE.format(article=ARTICLE), URL)
        self.assertEqual(report['article_ad_elements'], [])
        self.assertGreater(report['by_zone']['outside_article_container']['ad'], 0)
        self.assertGreater(report['by_zone']['article_container_other']['chrome'], 0)
        self.assertIn('ad-stir.com', report['ad_hosts_in_markup'])
        rules = json.loads(json.dumps(sorted(adblock.AD_HOSTS)))
        self.assertIn('gliacloud.com', rules)


if __name__ == '__main__':
    unittest.main()
