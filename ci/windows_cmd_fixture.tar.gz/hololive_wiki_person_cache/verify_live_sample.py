#!/usr/bin/env python3
"""Re-run the live check behind the person cache README (HTTP, about 30 requests).

1. Reads the wiki top page with the reader and checks that every roster
   member listed in its member table links to the same main-page URL as the
   cache.
2. Reads the 28 sample pages with the reader and compares each with the
   cached text, exactly as `hololive_cache.py check-updates` does: own-line
   headings by parsed text, every other line verbatim.

The wiki keeps changing, so a later run can report more `changed` pages than
the README did; that is the cache going stale, not a failed check.

  python3 verify_live_sample.py --cache <cache folder> [--reader <reader .py>] [--out report.json]

The reader defaults to tools/hololive_wiki_reader_v31.py inside the cache folder.
"""

import argparse
import json
import os
import subprocess
import sys
import time
from urllib.parse import unquote_to_bytes, urlsplit

# (owner slug or "shared", page id): the pages compared on 2026-09-23.
SAMPLE = [
    ("houshou_marine", "main"), ("houshou_marine", "glossary"), ("tokino_sora", "quotes"),
    ("sakura_miko", "main"), ("usada_pekora", "main"), ("sakura_miko", "quotes"),
    ("shirakami_fubuki", "glossary"), ("minato_aqua", "episodes"), ("hakui_koyori", "nicknames_page"),
    ("oozora_subaru", "quotes"), ("ichijou_ririka", "glossary"), ("tokoyami_towa", "costumes"),
    ("kikirara_vivi", "main"), ("isaki_riona", "main"), ("azki", "references"),
    ("hoshimachi_suisei", "designer_art"), ("nekomata_okayu", "minecraft"), ("yukihana_lamy", "own_works"),
    ("robocosan", "main"), ("todoroki_hajime", "nicknames_page"), ("shirogane_noel", "games"),
    ("momosuzu_nene", "bgm"), ("natsuiro_matsuri", "videos"), ("aki_rosenthal", "songs"),
    ("akai_haato", "videos"), ("takane_lui", "songs"), ("shared", "combos_units"),
    ("shared", "designers_modelers"),
]
FLAGS = ["--all", "--surrogate-charrefs", "utf16", "--cache-policy", "diagnostic", "--format", "json"]


def read_live(reader, url):
    process = subprocess.run([sys.executable, reader, "--url", url, *FLAGS], capture_output=True)
    if process.returncode:
        raise RuntimeError(process.stderr.decode("utf-8", "replace")[-300:])
    return json.loads(process.stdout)


def path_bytes(url):
    return unquote_to_bytes(urlsplit(url).path)


def main():
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--cache", required=True, help="extracted cache folder (hololive_wiki_person_cache)")
    parser.add_argument("--reader", help="hololive_wiki_reader_v31.py (default: tools/ in the cache folder)")
    parser.add_argument("--delay", type=float, default=1.0, help="seconds between requests (min 0.5)")
    parser.add_argument("--out", help="write the JSON report here")
    args = parser.parse_args()
    if args.delay < 0.5:
        parser.error("--delay must be at least 0.5")
    args.reader = args.reader or os.path.join(args.cache, "tools", "hololive_wiki_reader_v31.py")
    sys.path.insert(0, os.path.abspath(args.cache))
    import build_fast_cache as builder
    import hololive_cache as hc
    cache = hc.Cache(args.cache)
    report = {"pages": []}

    root = read_live(args.reader, "https://seesaawiki.jp/hololivetv/")
    root_path = os.path.join(args.cache, ".live_root.json")
    with open(root_path, "w", encoding="utf-8") as stream:
        json.dump(root, stream, ensure_ascii=False)
    try:
        facts = builder.wiki_root_facts(root_path, cache.people)
    finally:
        os.remove(root_path)
    by_name = {person["name"]: person for person in cache.people}
    mismatched = [name for name, item in facts["roster_people_listed"].items()
                  if not by_name[name]["wiki_url"] or path_bytes(by_name[name]["wiki_url"]) != path_bytes(item["url"])]
    report["wiki_root"] = {"fetched_at": root.get("fetched_at"), "listed": len(facts["roster_people_listed"]),
                           "url_mismatches": mismatched, "not_listed": facts["roster_people_not_listed"]}
    print(f"top page: listed {len(facts['roster_people_listed'])}/{len(cache.people)}, "
          f"URL mismatches {mismatched}, not listed {facts['roster_people_not_listed']}", flush=True)

    for owner, page_id in SAMPLE:
        time.sleep(args.delay)
        page = cache.shared().page(page_id) if owner == "shared" else cache.person(owner).page(page_id)
        try:
            live = read_live(args.reader, page.url)
        except RuntimeError as exc:
            result = {"owner": owner, "page": page_id, "status": "error", "detail": str(exc)}
        else:
            live_lines = [item["text"] for item in live["lines"]]
            same = hc.comparable(page.lines, page.headings()) == hc.comparable(live_lines, live.get("headings", []))
            live_updated = (live.get("page_metadata") or {}).get("last_updated")
            result = {"owner": owner, "page": page_id, "title": page.title,
                      "status": "same" if same else "changed",
                      "cached_lines": len(page.lines), "live_lines": len(live_lines),
                      "last_updated_equal": live_updated == page.entry.get("last_updated"),
                      "cached_last_updated": page.entry.get("last_updated"), "live_last_updated": live_updated}
        report["pages"].append(result)
        print(f"{result['status']:8s} {owner}/{page_id}  {result.get('cached_lines')}→{result.get('live_lines')}行  "
              f"更新日時一致={result.get('last_updated_equal')}", flush=True)

    summary = {}
    for result in report["pages"]:
        summary[result["status"]] = summary.get(result["status"], 0) + 1
    report["summary"] = summary
    print("summary:", json.dumps(summary, ensure_ascii=False))
    if args.out:
        with open(args.out, "w", encoding="utf-8") as stream:
            json.dump(report, stream, ensure_ascii=False, indent=1)
    return 1 if summary.get("error") or mismatched else 0


if __name__ == "__main__":
    raise SystemExit(main())
