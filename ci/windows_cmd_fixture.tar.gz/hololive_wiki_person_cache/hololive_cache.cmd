@echo off
rem Runs hololive_cache.py in Python's UTF-8 mode with the py launcher if present, else python.
setlocal
set PYTHONUTF8=1
set "PYEXE=python"
where py >nul 2>nul && set "PYEXE=py -3"
%PYEXE% "%~dp0hololive_cache.py" %*
exit /b %errorlevel%
