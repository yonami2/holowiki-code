#!/usr/bin/env python3
"""Offline reader for the hololive wiki person cache v3 (standard library only).

This module holds the implementation; hololive_cache.py is its small command
line entry point, so Python can reuse this file's cached bytecode on every run.

Every command reads only the small files it needs: catalog.json (the whole
roster) plus the named people's card, page, nickname or source files.

  list          people, optionally one region/generation
  show          summary cards of one or more people (--digest: long JP digest)
  scene         cards plus how every listed person calls every other one
  profile       person.json (--field to pick one item)
  pages         a person's pages: id, label, lines, last update, text or URL only
  read          one page with the reader's --find/--context/--section/--start/--lines
                rules; --title/--url address it like the reader; --online asks the
                reader for pages whose text is not cached; --links lists the URLs
                of the [n] references shown; --previous reads the older version
  find          one person's pages, card and supplements (case-insensitive)
  search        every cached page (optionally one region)
  nicknames     calls=本人→相手, called_by=相手→本人; --reverse shows other tables
  sources       URLs, fetch times and HTML hashes behind a person's data
  tables        a page's tables (rowspan/colspan already resolved)
  footnotes     a page's footnotes
  check-updates compare cached pages with the live wiki through the reader (HTTP)
  verify        check every file against MANIFEST.sha256

Line numbers of pages/<id>.txt are the reader's article line numbers.
Import it as a module for many lookups in one process: Cache().person("名前").
"""

from __future__ import annotations

import json
import os
import re
import sys

SCHEMAS = ("hololive-wiki-person-cache/3", "hololive-wiki-person-cache/2")
ROOT = os.path.dirname(os.path.abspath(__file__))
WORLD_NOTE = '過去の創作用設定「卒業生はいない」はwikiの事実ではありません。今回の会話で利用者が採用している場合だけ適用し、現実の所属・活動状態は公式情報を優先して確認してください。'
HEADING_NOTE = ("見出し行は解析済み見出しから再構成（リンク番号[n]なし）。本文中の [n] はリンク参照番号で、"
                "元キャッシュのページにはURL対応表が無い。")
SNAPSHOT_NOTE = "行は取得時のリーダー出力そのもの。本文中の [n] はリンク参照番号で、--links でURLを表示できる。"
NICKNAME_NOTE = "calls=本人→相手、called_by=相手→本人。空欄は資料に記載なし（不存在を意味しない）。"
READER_NAME = "hololive_wiki_reader_v31.py"


class CacheError(Exception):
    pass


def _read_bytes(path):
    try:
        with open(path, "rb") as stream:
            return stream.read()
    except FileNotFoundError as exc:
        raise CacheError(f"キャッシュのファイルがありません: {path}") from exc


def _json(path):
    return json.loads(_read_bytes(path))


def _text(path):
    return _read_bytes(path).decode("utf-8")


def normalize_key(text):
    """NFKC + casefold, ignoring spaces, underscores, dots and apostrophes."""
    import unicodedata
    return re.sub(r"[\s_\-・･·'’`]+", "", unicodedata.normalize("NFKC", str(text)).casefold())


def url_path_key(url):
    from urllib.parse import unquote_to_bytes, urlsplit
    parts = urlsplit(url.partition("#")[0])
    return parts.netloc.lower() + ":" + unquote_to_bytes(parts.path).hex()


# --- cache, people and pages ---------------------------------------------------

class Cache:
    def __init__(self, root=None):
        self.root = os.fspath(root) if root else ROOT
        self._catalog = None
        self._keys = None
        self._page_index = None

    def path(self, *parts):
        return os.path.join(self.root, *parts)

    @property
    def catalog(self):
        if self._catalog is None:
            path = self.path("catalog.json")
            if not os.path.isfile(path):
                hint = (" v1 形式（data/index.json）です。build_fast_cache.py build で変換してください。"
                        if os.path.isfile(self.path("data", "index.json")) else "")
                raise CacheError(f"catalog.json がありません: {self.root}{hint}")
            data = _json(path)
            if data.get("schema") not in SCHEMAS:
                raise CacheError(f"未対応のキャッシュ形式です: {data.get('schema')}")
            self._catalog = data
        return self._catalog

    @property
    def people(self):
        return self.catalog["people"]

    def _lookup(self):
        if self._keys is None:
            keys = {}
            for entry in self.people:
                handles = entry.get("handles", [])
                for value in (entry["name"], entry["slug"], *entry.get("aliases", []),
                              *entry.get("readings", []), *handles, *(h.lstrip("@") for h in handles)):
                    slugs = keys.setdefault(normalize_key(value), [])
                    if entry["slug"] not in slugs:
                        slugs.append(entry["slug"])
            self._keys = keys
        return self._keys

    def resolve(self, query):
        """Exact name/slug/alias/reading/handle first, then a unique partial name."""
        by_slug = {entry["slug"]: entry for entry in self.people}
        key = normalize_key(query)
        if not key:
            raise CacheError("名前が空です。")
        exact = self._lookup().get(key, [])
        if len(exact) == 1:
            return by_slug[exact[0]]
        if len(exact) > 1:
            raise CacheError("複数の人物に一致します。正式名か slug を指定してください: "
                             + "、".join(by_slug[s]["name"] for s in exact))
        partial = [entry for entry in self.people
                   if any(key in normalize_key(value) for value in
                          (entry["name"], entry["slug"], *entry.get("readings", [])))]
        if len(partial) == 1:
            return partial[0]
        if partial:
            raise CacheError("複数の人物に一致します。正式名か slug を指定してください: "
                             + "、".join(entry["name"] for entry in partial))
        import difflib
        close = difflib.get_close_matches(query, [entry["name"] for entry in self.people], n=5, cutoff=0.4)
        raise CacheError(f"該当する人物がいません: {query}" + (f"（候補: {'、'.join(close)}）" if close else ""))

    def person(self, query):
        return Person(self, self.resolve(query))

    def shared(self):
        return SharedPages(self)

    @property
    def page_index(self):
        if self._page_index is None:
            self._page_index = _json(self.path("page_index.json"))["pages"]
        return self._page_index

    def locate(self, *, title=None, url=None):
        """Find a page by exact wiki title or URL, as the reader addresses pages."""
        if url is not None:
            key = url_path_key(url)
            hits = [item for item in self.page_index if item["url"] and url_path_key(item["url"]) == key]
        else:
            hits = [item for item in self.page_index if item["title"] == title]
        if not hits:
            return None
        item = hits[0]
        if item["owner"] == "shared":
            return self.shared().page(item["id"])
        if item["owner"] == "related":
            return RemotePage(item)
        return Person(self, next(e for e in self.people if e["slug"] == item["owner"])).page(item["id"])


class Person:
    def __init__(self, cache, entry):
        self.cache, self.entry = cache, entry
        self.slug, self.name = entry["slug"], entry["name"]
        self._pages = None

    def file(self, key):
        relative = self.entry["files"].get(key)
        return self.cache.path(relative) if isinstance(relative, str) else None

    def card(self):
        return _text(self.file("card"))

    def digest(self):
        path = self.file("digest")
        return _text(path) if path else None

    def info(self):
        return _json(self.file("person"))

    def nicknames(self):
        return _json(self.file("nicknames"))

    def sources(self):
        return _json(self.file("sources"))

    def pages(self):
        if self._pages is None:
            self._pages = _json(self.file("pages"))
        return self._pages

    def text_pages(self):
        directory = os.path.join(os.path.dirname(self.file("pages")), "pages")
        return [Page(directory, entry, owner=self.name) for entry in self.pages()["pages"] if entry["text"]]

    def page(self, which="main"):
        pages = self.pages()["pages"]
        entry = match_page(pages, which, prefix=self.name)
        if entry is None:
            known = "、".join(f"{p['id']}（{p['label']}）" for p in pages) or "なし"
            raise CacheError(f"{self.name} にページ「{which}」はありません。候補: {known}")
        if not entry["text"]:
            return RemotePage(entry, owner=self)
        return Page(os.path.join(os.path.dirname(self.file("pages")), "pages"), entry, owner=self.name)

    def related(self):
        return self.pages().get("related") or []


def match_page(pages, which, prefix=""):
    """Match a page id, label, full title, the title after the name, or 【label】."""
    key = normalize_key(which)
    for entry in pages:
        title = entry.get("title") or ""
        label = entry.get("label") or ""
        names = {entry["id"], label, title, "【" + label + "】"}
        if prefix and title.startswith(prefix):
            names.add(title[len(prefix):])
        if key in {normalize_key(name) for name in names if name}:
            return entry
    return None


class SharedPages:
    def __init__(self, cache):
        self.cache = cache
        self.data = _json(cache.path("shared", "pages.json"))

    def pages(self):
        return [Page(self.cache.path("shared"), entry, owner="共有ページ") for entry in self.data["pages"]]

    def page(self, which):
        entry = match_page(self.data["pages"], which)
        if entry is None:
            raise CacheError("共有ページが見つかりません。候補: "
                             + "、".join(f"{p['id']}（{p['title']}）" for p in self.data["pages"]))
        return Page(self.cache.path("shared"), entry, owner="共有ページ")


class Page:
    """One cached article: text lines plus the stored structure."""
    has_text = True

    def __init__(self, directory, entry, owner=""):
        self.directory, self.entry, self.owner = directory, entry, owner
        self._text = self._lines = self._meta = None

    @property
    def title(self):
        return self.entry["title"]

    @property
    def url(self):
        return self.entry["url"]

    @property
    def text(self):
        if self._text is None:
            self._text = _text(os.path.join(self.directory, self.entry["text"]))
        return self._text

    @property
    def lines(self):
        if self._lines is None:
            self._lines = self.text[:-1].split("\n") if self.text else []
        return self._lines

    @property
    def meta(self):
        if self._meta is None:
            self._meta = _json(os.path.join(self.directory, self.entry["meta"]))
        return self._meta

    @property
    def record(self):
        return self.meta["record"]

    @property
    def origin(self):
        return self.entry.get("origin") or "v1_cache"

    def note(self):
        return SNAPSHOT_NOTE if self.origin == "online_snapshot" else HEADING_NOTE

    def links(self):
        return self.record.get("links") or {}

    def previous(self):
        """The older cached version of a page that an online snapshot replaced."""
        older = self.entry.get("previous")
        if not older:
            raise CacheError(f"{self.title} に旧版はありません。")
        # Identity is shared, but version-specific values belong to the old
        # metadata. Never label a v1 page with the new snapshot's reader/counts.
        meta = _json(os.path.join(self.directory, older["meta"]))
        entry = {key: self.entry[key] for key in ("id", "title", "label", "role", "url")
                 if key in self.entry}
        for key in ("title", "url", "last_updated", "fetched_at", "html_sha256",
                    "line_count", "sections", "tables", "footnotes", "links",
                    "origin", "reader_version"):
            if key in meta:
                entry[key] = meta[key]
        entry.update(older)
        entry["previous"] = None
        entry.setdefault("links", len(meta.get("record", {}).get("links") or {}))
        previous = Page(self.directory, entry, owner=self.owner)
        previous._meta = meta
        return previous

    def headings(self):
        return [{"level": s["level"], "text": s["heading"], "article_line": s["article_line"],
                 "path": s.get("path", [])} for s in self.record.get("sections") or []]

    def select(self, **options):
        return select_article_lines({"lines": self.lines, "headings": self.headings()}, Options(**options))

    def tables(self, section=None):
        tables = self.record.get("tables") or []
        if section is None:
            return tables
        return [table for table in tables if section in (table.get("section") or [])]

    def footnotes(self):
        return self.record.get("footnotes") or {}

    def grep(self, folded_term):
        """(line number, line) whose casefolded text contains the term."""
        if folded_term not in self.text.casefold():
            return []
        return [(number, line) for number, line in enumerate(self.lines, 1) if folded_term in line.casefold()]


class RemotePage:
    """A page known only by URL and metadata; its text is not in the cache."""
    has_text = False

    def __init__(self, entry, owner=None):
        self.entry, self.owner = entry, owner
        self.title, self.url = entry["title"], entry["url"]


# --- the reader's selection rules (kept identical; see the parity tests) -------

class Options:
    def __init__(self, section=None, find=None, context=0, start=1, lines=80, all=False):
        if context and find is None:
            raise CacheError("--context には --find が必要です。")
        if start < 1 or lines < 1:
            raise CacheError("--start と --lines は1以上です。")
        self.section, self.find, self.context = section, find, context
        self.start, self.lines, self.all = start, lines, all


def select_article_lines(parsed, args):
    """Port of hololive_wiki_reader_v31.select_article_lines (v3.8.3)."""
    import bisect
    numbered = list(enumerate(parsed["lines"], 1))
    section = None
    if args.section is not None:
        marks = []
        for entry in parsed.get("headings", []):
            start = entry.get("article_line")
            if not start:
                continue
            match = re.match(r"^(#{1,6})\s+", parsed["lines"][start - 1])
            if match and len(match.group(1)) == entry["level"]:
                marks.append({"line": start, "level": entry["level"], "text": entry["text"], "heading": entry})
        exact = [mark for mark in marks if mark["text"] == args.section]
        candidates = exact or [mark for mark in marks if args.section in mark["text"]]
        if not candidates:
            raise CacheError(f"見出しが見つかりません: {args.section}")
        if len(candidates) != 1:
            raise CacheError("複数の見出しに一致します。より詳しく指定してください: "
                             + " / ".join(f"{m['line']}行 {m['text']}" for m in candidates[:20]))
        chosen = candidates[0]
        end = next((mark["line"] - 1 for mark in marks
                    if mark["line"] > chosen["line"] and mark["level"] <= chosen["level"]), len(numbered))
        section = {"heading": chosen["text"], "level": chosen["level"], "start_line": chosen["line"],
                   "end_line": end, "total_lines": end - chosen["line"] + 1,
                   "source_heading": chosen["heading"]}
        numbered = [(i, line) for i, line in numbered if chosen["line"] <= i <= end]
    matches = numbered if args.find is None else [(i, line) for i, line in numbered if args.find in line]
    selection = matches
    contextual = args.find is not None and args.context
    if contextual:
        wanted = {j for i, _ in matches for j in range(max(1, i - args.context), i + args.context + 1)}
        selection = [(i, line) for i, line in numbered if i in wanted]
    offset = 0 if args.all else args.start - 1
    selection_offset = offset
    if contextual and not args.all:
        if offset >= len(matches):
            selected = []
            selection_offset = len(selection)
        else:
            first_match = matches[offset][0]
            lower = max(first_match - args.context, matches[offset - 1][0] + 1 if offset else 1)
            selection_lines = [line for line, _ in selection]
            selection_offset = bisect.bisect_left(selection_lines, lower)
            first_position = bisect.bisect_left(selection_lines, first_match)
            selection_offset = max(selection_offset, first_position - args.lines + 1)
            selected = selection[selection_offset:selection_offset + args.lines]
    else:
        selected = selection if args.all else selection[offset:offset + args.lines]
    info = {"more_before": selection_offset > 0 and bool(selection),
            "more_after": selection_offset + len(selected) < len(selection),
            "total_selection_lines": len(selection), "selection_offset": selection_offset + 1}
    if section:
        info["section"] = section
    if args.find is not None:
        last_line = selected[-1][0] if selected else float("inf")
        more_matches = any(line > last_line for line, _ in matches[offset:])
        info.update(total_matches=len(matches), more_matches=more_matches, match_offset=offset + 1, context=args.context)
    return selected, info


# --- commands ---------------------------------------------------------------------

def out(text=""):
    sys.stdout.write(text + "\n")


def cmd_list(cache, args):
    for entry in cache.people:
        if args.region and entry["region"] != args.region:
            continue
        if args.generation and normalize_key(args.generation) not in normalize_key(entry["generation"]):
            continue
        out(f"{entry['region']}\t{entry['generation']}\t{entry['name']}\t{entry['slug']}\t"
            f"{entry['status']}\t本文{entry['pages_with_text']}/{entry['pages_known']}ページ")


def header(person):
    entry = person.entry
    status = person.info()["status"]
    lines = [f"{entry['name']} | {entry['region']} | {entry['generation']}", WORLD_NOTE,
             f"cache={status['collection_status']} pages={entry['pages_with_text']}/{entry['pages_known']} "
             f"machine={status['structural_audit']} model_full_read={status['model_full_read']}"]
    if status.get("coverage_note"):
        lines.append("資料注記: " + status["coverage_note"])
    if not entry["pages_with_text"] and entry["pages_known"]:
        lines.append("本文は未収録（URL・行数のみ）。read <名前> <ページ> --online でリーダー取得できます。")
    elif entry["pages_with_text"] < entry["pages_known"]:
        lines.append(f"本文があるのは {entry['pages_with_text']}/{entry['pages_known']} ページ（pages で一覧）。"
                     "残りは read <名前> <ページ> --online でリーダー取得できます。")
    if entry.get("pages_from_online_snapshots"):
        lines.append(f"うち {entry['pages_from_online_snapshots']} ページはオンライン取得の新しい版（取得日は pages / sources）。")
    return "\n".join(lines)


def cmd_show(cache, args):
    people = [cache.person(name) for name in args.person]
    for position, person in enumerate(people):
        if position:
            out("\n" + "=" * 40 + "\n")
        out(header(person))
        out()
        text = person.digest() if args.digest else person.card()
        if text is None:
            raise CacheError(f"{person.name} にはダイジェストがありません（JP45名のみ）。--digest を外してください。")
        sys.stdout.write(text if text.endswith("\n") else text + "\n")


def pair_names(cache, people):
    """How each listed person calls each other one, from both people's tables."""
    rows = []
    tables = {person.slug: person.nicknames() for person in people}
    for speaker in people:
        for target in people:
            if speaker is target:
                continue
            own = [r for r in tables[speaker.slug]["records"] if r.get("counterpart_slug") == target.slug]
            other = [r for r in tables[target.slug]["records"] if r.get("counterpart_slug") == speaker.slug]
            rows.append({"from": speaker.name, "to": target.name,
                         "from_table": "、".join(dict.fromkeys(r["calls"] for r in own if r["calls"])),
                         "to_table": "、".join(dict.fromkeys(r["called_by"] for r in other if r["called_by"]))})
    return rows


def cmd_scene(cache, args):
    people = []
    for name in args.person:
        person = cache.person(name)
        if all(person.slug != other.slug for other in people):
            people.append(person)
    if len(people) < 2:
        raise CacheError("scene には2人以上を指定してください。")
    out(WORLD_NOTE)
    out("## 呼び方（A→B）。左=Aの呼称表の『呼び方』、右=Bの呼称表の『呼ばれ方』。空欄は記載なし。")
    for row in pair_names(cache, people):
        agree = row["from_table"] and row["from_table"] == row["to_table"]
        out(f"- {row['from']}→{row['to']}: {row['from_table'] or '—'}"
            + ("" if agree else f" ／ {row['to']}側の表: {row['to_table'] or '—'}"))
    for person in people:
        info = person.info()
        quick = info.get("quick") or {}
        out(f"\n## {person.name}（{person.entry['region']} / {person.entry['generation']}）")
        if info.get("self_reference_row"):
            out(f"- 自称（呼称表の本人行）: {info['self_reference_row']}")
        for key, label in (("one_line_persona", "人物像"), ("speech", "話し方"), ("relationships", "関係")):
            if quick.get(key):
                out(f"- {label}: {quick[key]}")
        if not args.brief:
            out()
            card = person.card()
            sys.stdout.write(card if card.endswith("\n") else card + "\n")


def cmd_profile(cache, args):
    info = cache.person(args.person).info()
    if args.field:
        if args.field not in info:
            raise CacheError("項目がありません。候補: " + "、".join(info))
        info = info[args.field]
    out(json.dumps(info, ensure_ascii=False, indent=1))


def cmd_pages(cache, args):
    if args.person in {"shared", "共有"}:
        for page in cache.shared().pages():
            entry = page.entry
            out(f"{entry['id']}\t{entry['label']}\t{entry['line_count']}行\t{text_state(entry)}\t"
                f"最終更新={entry['last_updated']}\t{entry['title']}")
        return
    person = cache.person(args.person)
    data = person.pages()
    out(f"{person.name}: {data['text_status']}")
    for entry in data["pages"]:
        lines = entry["line_count"] if entry["line_count"] is not None else "?"
        out(f"{entry['id']}\t{entry['label']}\t{lines}行\t{text_state(entry)}\t"
            f"最終更新={entry['last_updated'] or '—'}\t{entry['title']}")
    related = data.get("related") or []
    cached = [item for item in related if item.get("shared_page")]
    if cached:
        out("関連する共有ページ（本文あり、read shared <ID>）:")
        for item in cached:
            out(f"\t{item['shared_page']}\t{item['title']}")
    if related and args.related:
        out("関連する共有記事（URLのみ）:")
        for item in related:
            if not item.get("shared_page"):
                out(f"\t{item['title']}\t{item['line_count']}行\t{item['url']}")


def text_state(entry):
    if not entry.get("text"):
        return "URLのみ"
    if entry.get("origin") == "online_snapshot":
        state = f"本文あり（{(entry.get('fetched_at') or '')[:10]} オンライン取得）"
        return state + ("・旧版あり --previous" if entry.get("previous") else "")
    return "本文あり"


def resolve_page(cache, args):
    if args.title or args.url:
        return cache.locate(title=args.title, url=args.url)
    if args.person is None:
        raise CacheError("人物名か --title / --url を指定してください。")
    if args.person in {"shared", "共有"}:
        return cache.shared().page(args.page or "")
    return cache.person(args.person).page(args.page or "main")


def find_reader(explicit=None):
    # tools/ holds the reader with its ad filter. The copy under vendor/ belongs
    # to the v1 archive (restore-v1) and is never used for reading.
    candidates = [explicit] if explicit else [
        os.path.join(ROOT, "tools", READER_NAME), os.path.join(ROOT, READER_NAME),
        os.path.join(os.getcwd(), READER_NAME), os.path.join(os.path.dirname(ROOT), READER_NAME)]
    for path in candidates:
        if path and os.path.isfile(path):
            return path
    raise CacheError("リーダー hololive_wiki_reader_v31.py が見つかりません（tools/ に同梱）。--reader で場所を指定してください。")


def run_reader(args, url=None, title=None):
    import subprocess
    argv = [sys.executable, find_reader(args.reader)] + (["--url", url] if url else ["--title", title])
    for flag in ("find", "section"):
        if getattr(args, flag) is not None:
            argv += ["--" + flag, getattr(args, flag)]
    if args.context:
        argv += ["--context", str(args.context)]
    argv += ["--start", str(args.start), "--lines", str(args.lines), "--format", args.format]
    if args.all:
        argv.append("--all")
    if args.tables:
        argv.append("--tables")
    if args.links:
        argv += ["--links", "references"]
    if args.footnotes:
        argv += ["--footnotes", "markers"]
    if args.reader_cache_dir:
        argv += ["--cache-dir", args.reader_cache_dir]
    sys.stdout.flush()
    return subprocess.run(argv).returncode


def cmd_read(cache, args):
    page = resolve_page(cache, args)
    if page is None or not page.has_text:
        if args.previous:
            raise CacheError("旧版はキャッシュ未収録です。--previous では現在のwikiを取得しません。")
        if not args.online:
            where = page.url if page is not None else (args.url or args.title)
            raise CacheError(f"本文はキャッシュ未収録です: {where}。--online を付けるとリーダーで取得します（HTTP通信あり）。")
        return run_reader(args, url=page.url if page is not None else args.url,
                          title=None if page is not None or args.url else args.title)
    if args.previous:
        page = page.previous()
    selected, info = page.select(section=args.section, find=args.find, context=args.context,
                                 start=args.start, lines=args.lines, all=args.all)
    tables = page.tables(info["section"]["heading"] if "section" in info else None) if args.tables else None
    notes = {}
    if args.footnotes:
        available = page.footnotes()
        numbers = dict.fromkeys(n for _, line in selected for n in re.findall(r"\*(\d+)", line))
        notes = {n: available[n] for n in numbers if n in available}
    links = None
    if args.links:
        available = page.links()
        numbers = dict.fromkeys(n for _, line in selected for n in re.findall(r"\[(\d+)\]", line))
        links = {n: available[n] for n in numbers if n in available}
    entry = page.entry
    if args.format == "json":
        result = {"source": "person_cache", "from_cache": True, "http_requests": 0, "owner": page.owner,
                  "page_id": entry["id"], "page_title": entry["title"], "label": entry.get("label"),
                  "url": entry["url"], "last_updated": entry.get("last_updated"),
                  "fetched_at": entry.get("fetched_at"), "html_sha256": entry.get("html_sha256"),
                  "origin": page.origin, "reader_version": entry.get("reader_version"),
                  "previous_version_available": bool(entry.get("previous")),
                  "total_lines": len(page.lines), "returned_lines": len(selected), **info,
                  "lines": [{"line": i, "text": text} for i, text in selected],
                  "headings": page.headings(), "limitations": page.note()}
        if tables is not None:
            result["tables"] = tables
        if args.footnotes:
            result["footnotes"] = notes
        if links is not None:
            result["links"] = links
        out(json.dumps(result, ensure_ascii=False, indent=1))
        return 0
    out(f"# {entry['title']}（{page.owner} / {entry.get('label') or entry['id']}）")
    out(f"url: {entry['url']}")
    origin = "オンライン取得" if page.origin == "online_snapshot" else "元キャッシュ"
    out(f"source: person_cache（通信なし・{origin}） fetched_at: {entry.get('fetched_at')} "
        f"最終更新: {entry.get('last_updated')}" + ("（旧版あり: --previous）" if entry.get("previous") else ""))
    summary = (f"Article lines: {len(page.lines)}; selection lines: {info['total_selection_lines']}; "
               f"returned: {len(selected)}; more_after: {info['more_after']}")
    if "total_matches" in info:
        summary += f"; matches: {info['total_matches']}; more_matches: {info['more_matches']}"
    out(summary)
    if "section" in info:
        section = info["section"]
        out(f"section: {section['heading']}（{section['start_line']}–{section['end_line']}行）")
    for number, text in selected:
        out(f"{number}: {text}")
    if tables is not None:
        out(f"Tables ({len(tables)}):")
        out(json.dumps(tables, ensure_ascii=False))
    if notes:
        out("Footnotes for displayed lines:")
        for number, note in notes.items():
            out(f"*{number}: {note.get('display_text', note.get('text', ''))}")
    if links:
        out("Links for displayed lines:")
        for number, url in links.items():
            out(f"[{number}] {url}")
    elif args.links and not page.links():
        out("Links: このページ（元キャッシュ）にはURL対応表がありません。")
    out("NOTE: " + page.note())
    return 0


def text_sources(person):
    """(title, grep) for a person's cached pages, then card and supplement files."""
    for page in person.text_pages():
        yield page.title, page.grep
    yield "card.md", lines_grep(person.card().splitlines())
    for relative in person.entry["files"].get("supplement", []):
        data = _json(person.cache.path(relative))
        yield os.path.basename(relative), lines_grep(json.dumps(data, ensure_ascii=False, indent=2).splitlines())


def lines_grep(lines):
    return lambda term: [(n, line) for n, line in enumerate(lines, 1) if term in line.casefold()]


def cmd_find(cache, args):
    person = cache.person(args.person)
    term = args.term.casefold()
    total = 0
    for title, grep in text_sources(person):
        for number, line in grep(term):
            out(f"{title}:{number}: {line[:450]}")
            total += 1
            if total >= args.limit:
                out(f"表示上限 {args.limit} 件。全件は --limit を増やしてください。")
                return
    out(f"表示 {total} 件")


def cmd_search(cache, args):
    term = args.term.casefold()
    total = 0

    def hits():
        for entry in cache.people:
            if args.region and entry["region"] != args.region:
                continue
            person = Person(cache, entry)
            for title, grep in text_sources(person):
                for number, line in grep(term):
                    yield person.name, title, number, line
        if not args.no_shared and not args.region:
            for page in cache.shared().pages():
                for number, line in page.grep(term):
                    yield "共有", page.title, number, line
    for name, title, number, line in hits():
        out(f"{name}\t{title}:{number}: {line[:300]}")
        total += 1
        if total >= args.limit:
            out(f"表示上限 {args.limit} 件。--limit で増やせます。")
            return
    out(f"表示 {total} 件")


def cmd_nicknames(cache, args):
    person = cache.person(args.person)
    data = person.nicknames()
    section = person.info().get("nickname_page_section")
    query = args.query.casefold() if args.query else None
    target = None
    if args.query:
        try:
            target = cache.resolve(args.query)["slug"]
        except CacheError:
            target = None
    out(NICKNAME_NOTE)
    shown = 0
    if args.reverse:
        out(f"他の人物の呼称表にある {person.name} の行:")
        for item in data["mentioned_by"]:
            if query and not (query in item["by"].casefold() or item["by_slug"] == target):
                continue
            out(f"{item['by']}: {item['by']}→{person.name}={item['by_calls_self'] or '—'}; "
                f"{person.name}→{item['by']}={item['self_calls_by'] or '—'}")
            shown += 1
        if not shown:
            out("該当する記録なし。")
        return
    for item in data["records"]:
        if not args.all and not (item["calls"] or item["called_by"]):
            continue
        if query and not (query in item["counterpart"].casefold() or (target and item.get("counterpart_slug") == target)):
            continue
        out(f"{item['counterpart']}: 呼び方={item['calls']}; 呼ばれ方={item['called_by']}")
        shown += 1
    if not data["records"]:
        out("呼称レコードなし。")
    elif not shown:
        out("該当する呼称記録なし。--all で未記載行も、--reverse で相手側の表も表示できます。")
    if section:
        out(f"全員分の呼称表（オンライン取得）: read shared {section['shared_page']} --section \"{section['section']}\"")


def cmd_sources(cache, args):
    data = cache.person(args.person).sources()
    if data.get("online_snapshots"):
        out("オンライン取得（リーダー、広告ブロック strict）:")
        for item in data["online_snapshots"]:
            out(f"{item['title']} | {item['fetched_at']} | {item['html_sha256']} | reader {item['reader_version']} | {item['url']}")
    if data["primary_sources"]:
        out("JP構造化アーカイブの元ソース:")
        for item in data["primary_sources"]:
            out(f"{item['title']} | {item['fetched_at']} | {item['html_sha256']} | {item['url']}")
    if data["snapshots"]:
        out("reader生JSONスナップショット（本文は未同梱）:")
        for item in data["snapshots"]:
            out(f"{item['title']} | {item['fetched_at']} | {item['html_sha256']} | {item['audit']['status']} | {item['url']}")
    if data["shared_related_pages"]:
        out("関連する共有記事:")
        for item in data["shared_related_pages"]:
            out(f"{item['title']} | {item['fetched_at']} | {item['audit']['status']} | {item['url']}")
    if data["needs_review"]:
        out("要確認: " + json.dumps(data["needs_review"], ensure_ascii=False))


def cmd_tables(cache, args):
    page = resolve_page(cache, args)
    if page is None or not page.has_text:
        raise CacheError("本文未収録のページには表がありません。")
    tables = page.tables(args.section)
    out(json.dumps(tables, ensure_ascii=False, indent=None if args.compact else 1))
    if not tables:
        sys.stderr.write("表なし（一覧系ページの表は本文行に含まれます）。\n")


def cmd_footnotes(cache, args):
    page = resolve_page(cache, args)
    if page is None or not page.has_text:
        raise CacheError("本文未収録のページには脚注がありません。")
    notes = page.footnotes()
    for number in args.numbers or list(notes):
        note = notes.get(str(number))
        out(f"*{number}: " + (note.get("display_text", note.get("text", "")) if note else "（なし）"))


def comparable(lines, headings):
    """Lines as the cache can hold them, for update checks.

    The cache keeps each own-line heading only as its parsed text, so compare
    such lines as '#'*level + ' ' + that text on both sides. The rendered line
    also carries link numbers and spacing from the heading's markup, which
    would otherwise look like an edit. Every other line is compared verbatim.
    """
    result = list(lines)
    for heading in headings:
        number = heading.get("article_line")
        if not number or number > len(result):
            continue
        marks = re.match(r"^(#{1,6})\s", result[number - 1])
        if marks and len(marks.group(1)) == heading["level"]:
            parts = (heading.get("text") or "").splitlines()
            result[number - 1] = "#" * heading["level"] + " " + (parts[0] if parts else "")
    return result


def cmd_check_updates(cache, args):
    import subprocess
    import time
    reader = find_reader(args.reader)
    targets = []
    for entry in (cache.people if args.all else [cache.resolve(args.person)]):
        person = Person(cache, entry)
        for page_entry in person.pages()["pages"]:
            if args.pages and page_entry["id"] not in args.pages:
                continue
            if page_entry["text"] or args.include_url_only:
                targets.append((person, page_entry))
    if args.limit:
        targets = targets[:args.limit]
    results = []
    for number, (person, entry) in enumerate(targets):
        if number:
            time.sleep(args.delay)
        argv = [sys.executable, reader, "--url", entry["url"], "--all", "--surrogate-charrefs", "utf16",
                "--cache-policy", "diagnostic", "--format", "json"]
        if args.reader_cache_dir:
            argv += ["--cache-dir", args.reader_cache_dir]
        process = subprocess.run(argv, capture_output=True)
        if process.returncode:
            result = {"person": person.name, "page": entry["id"], "status": "error",
                      "detail": process.stderr.decode("utf-8", "replace")[-300:]}
        else:
            live = json.loads(process.stdout)
            live_lines = [item["text"] for item in live["lines"]]
            live_updated = (live.get("page_metadata") or {}).get("last_updated")
            result = {"person": person.name, "page": entry["id"], "title": entry["title"],
                      "cached_last_updated": entry.get("last_updated"), "live_last_updated": live_updated,
                      "cached_lines": entry["line_count"], "live_lines": len(live_lines)}
            if entry["text"]:
                page = person.page(entry["id"])
                same = comparable(page.lines, page.headings()) == comparable(live_lines, live.get("headings", []))
                result["status"] = "same" if same else "changed"
                if same and live_updated != entry.get("last_updated"):
                    result["status"] = "same_text_new_timestamp"
            else:
                result["status"] = ("url_only_same_line_count" if entry["line_count"] == len(live_lines)
                                    else "url_only_line_count_changed")
        results.append(result)
        if args.format == "text":
            if result["status"] == "error":
                out(f"error\t{result['person']}\t{result['page']}\t{result['detail']}")
            else:
                out(f"{result['status']}\t{result['person']}\t{result['page']}\t"
                    f"{result['cached_lines']}→{result['live_lines']}行\t"
                    f"{result['cached_last_updated']} → {result['live_last_updated']}")
            sys.stdout.flush()
    summary = {}
    for result in results:
        summary[result["status"]] = summary.get(result["status"], 0) + 1
    if args.format == "json":
        out(json.dumps({"http_requests": len(results), "summary": summary, "pages": results}, ensure_ascii=False, indent=1))
    else:
        out("summary: " + json.dumps(summary, ensure_ascii=False)
            + "  (same=本文一致 / changed=要再取得。見出し行は解析済み見出しテキストで比較)")
    return 1 if summary.get("error") else 0


def cmd_verify(cache, args):
    import hashlib
    problems, checked, listed = [], 0, {"MANIFEST.sha256"}
    for raw in _text(cache.path("MANIFEST.sha256")).splitlines():
        digest, relative = raw.split("  ", 1)
        listed.add(relative)
        path = cache.path(relative)
        if not os.path.isfile(path):
            problems.append("missing " + relative)
            continue
        checked += 1
        if hashlib.sha256(_read_bytes(path)).hexdigest() != digest:
            problems.append("changed " + relative)
    extra = []
    for directory, folders, files in os.walk(cache.root):
        folders[:] = [name for name in folders if name != "__pycache__"]
        for name in files:
            relative = os.path.relpath(os.path.join(directory, name), cache.root).replace(os.sep, "/")
            if relative not in listed:
                extra.append(relative)
    out(json.dumps({"checked": checked, "problems": problems, "unlisted_files": sorted(extra)[:50],
                    "ok": not problems}, ensure_ascii=False, indent=1))
    return 0 if not problems else 1


# --- command line -------------------------------------------------------------------
# Only the requested command's parser is built: constructing all fourteen costs
# more than loading the cache itself. Without a recognizable command (or for
# --help) every parser is built.

def _page_arguments(p, selection=True):
    p.add_argument("person", nargs="?", help="人物名・別名・slug、または shared")
    p.add_argument("page", nargs="?", help="ページID・ラベル・タイトル（既定: main）")
    p.add_argument("--title", help="wiki記事タイトルで指定（リーダーの --title と同じ）")
    p.add_argument("--url", help="wiki記事URLで指定")
    if selection:
        p.add_argument("--find", help="文字列を含む行（正規表現ではない）")
        p.add_argument("--context", type=int, choices=range(0, 21), default=0)
        p.add_argument("--section", help="一意に一致する見出しの節")
        p.add_argument("--start", type=int, default=1)
        p.add_argument("--lines", type=int, default=80)
        p.add_argument("--all", action="store_true")
        p.add_argument("--format", choices=("text", "json", "md"), default="text")
        p.add_argument("--tables", action="store_true")
        p.add_argument("--footnotes", action="store_true", help="表示行の *n 脚注を添える")
        p.add_argument("--links", action="store_true", help="表示行の [n] リンクのURLを添える（オンライン取得のページ）")
        p.add_argument("--previous", action="store_true", help="オンライン取得で置き換えた旧版（元キャッシュ）を読む")
        p.add_argument("--online", action="store_true", help="本文未収録ならリーダーで取得（HTTP）")
        p.add_argument("--reader", help="hololive_wiki_reader_v31.py の場所")
        p.add_argument("--reader-cache-dir", help="リーダーの --cache-dir")


def _arguments_list(p):
    p.add_argument("--region", choices=["JP", "EN", "ID"])
    p.add_argument("--generation")


def _arguments_show(p):
    p.add_argument("person", nargs="+", help="1人以上")
    p.add_argument("--digest", action="store_true", help="JP45名の長い人物像ダイジェスト")


def _arguments_scene(p):
    p.add_argument("person", nargs="+", help="2人以上")
    p.add_argument("--brief", action="store_true", help="カード本文を省き要点だけ")


def _arguments_profile(p):
    p.add_argument("person")
    p.add_argument("--field")


def _arguments_pages(p):
    p.add_argument("person", help="人物名、または shared")
    p.add_argument("--related", action="store_true", help="関連する共有記事も表示")


def _arguments_find(p):
    p.add_argument("person")
    p.add_argument("term")
    p.add_argument("--limit", type=int, default=25)


def _arguments_search(p):
    p.add_argument("term")
    p.add_argument("--region", choices=["JP", "EN", "ID"])
    p.add_argument("--limit", type=int, default=40)
    p.add_argument("--no-shared", action="store_true", help="共有ページを除く")


def _arguments_nicknames(p):
    p.add_argument("person")
    p.add_argument("--query")
    p.add_argument("--all", action="store_true", help="空欄の呼称行も表示")
    p.add_argument("--reverse", action="store_true", help="他の人物の呼称表での記載を表示")


def _arguments_sources(p):
    p.add_argument("person")


def _arguments_tables(p):
    _page_arguments(p, selection=False)
    p.add_argument("--section")
    p.add_argument("--compact", action="store_true")


def _arguments_footnotes(p):
    _page_arguments(p, selection=False)
    p.add_argument("--numbers", nargs="*")


def _arguments_check_updates(p):
    p.add_argument("person", nargs="?")
    p.add_argument("--all", action="store_true", help="全人物")
    p.add_argument("--pages", nargs="*", help="ページID（既定: 本文のある全ページ）")
    p.add_argument("--include-url-only", action="store_true", help="本文未収録ページも行数で照合")
    p.add_argument("--limit", type=int)
    p.add_argument("--delay", type=float, default=1.0, help="要求の間隔秒（既定1.0、最小0.5）")
    p.add_argument("--reader")
    p.add_argument("--reader-cache-dir")
    p.add_argument("--format", choices=("text", "json"), default="text")


COMMANDS = {
    "list": (cmd_list, _arguments_list, "人物一覧"),
    "show": (cmd_show, _arguments_show, "要約カード（複数人可）"),
    "scene": (cmd_scene, _arguments_scene, "複数人の相互の呼び方とカード"),
    "profile": (cmd_profile, _arguments_profile, "person.json"),
    "pages": (cmd_pages, _arguments_pages, "ページ一覧"),
    "read": (cmd_read, _page_arguments, "ページ本文（リーダーと同じ選択規則）"),
    "find": (cmd_find, _arguments_find, "人物の資料を検索"),
    "search": (cmd_search, _arguments_search, "全人物の本文を検索"),
    "nicknames": (cmd_nicknames, _arguments_nicknames, "呼称"),
    "sources": (cmd_sources, _arguments_sources, "出典"),
    "tables": (cmd_tables, _arguments_tables, "ページの表"),
    "footnotes": (cmd_footnotes, _arguments_footnotes, "ページの脚注"),
    "check-updates": (cmd_check_updates, _arguments_check_updates, "リーダーで現在のwikiと照合（HTTP）"),
    "verify": (cmd_verify, lambda p: None, "MANIFEST.sha256 で全ファイルを検査"),
}


def build_cli(only=None):
    import argparse
    cli = argparse.ArgumentParser(prog="hololive_cache.py", description=__doc__,
                                  formatter_class=argparse.RawDescriptionHelpFormatter)
    cli.add_argument("--cache", help="v2 キャッシュのディレクトリ（既定: このファイルの場所）")
    sub = cli.add_subparsers(dest="command", required=True, metavar="COMMAND")
    for name, (_, arguments, summary) in COMMANDS.items():
        if only is None or name == only:
            arguments(sub.add_parser(name, help=summary, description=summary))
    return cli


def main(argv=None):
    for stream in (sys.stdout, sys.stderr):
        try:
            stream.reconfigure(encoding="utf-8")
        except (AttributeError, OSError, ValueError):
            pass
    argv = sys.argv[1:] if argv is None else list(argv)
    command = next((item for item in argv if item in COMMANDS), None)
    cli = build_cli(command)
    args = cli.parse_args(argv)
    if args.command == "check-updates":
        if not (args.all or args.person):
            cli.error("check-updates には人物名か --all が必要です")
        if args.delay < 0.5:
            cli.error("--delay は0.5秒以上にしてください")
    if args.command == "scene" and len(args.person) < 2:
        cli.error("scene には2人以上を指定してください")
    try:
        return COMMANDS[args.command][0](Cache(args.cache), args) or 0
    except CacheError as exc:
        sys.stdout.flush()
        sys.stderr.write(json.dumps({"error": str(exc)}, ensure_ascii=False) + "\n")
        return 1


def run_cli():
    try:
        try:
            return main()
        finally:
            sys.stdout.flush()
    except BrokenPipeError:
        with open(os.devnull, "w") as sink:
            os.dup2(sink.fileno(), sys.stdout.fileno())
        return 0


if __name__ == "__main__":
    raise SystemExit(run_cli())
