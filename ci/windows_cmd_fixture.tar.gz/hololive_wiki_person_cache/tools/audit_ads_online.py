#!/usr/bin/env python3
"""Online audit: read wiki pages with the reader and prove no ads were loaded.

For every target page this records, with the reader in this process:
  network   every HTTP destination (including a proxy's CONNECT target), DNS
            lookup and TCP connection; only seesaawiki.jp may appear
  markup    where the page's ad slots are (hololive_adblock.inventory)
  article   the reader's result with --ad-filter strict, its output scan, and
            a field-by-field comparison with --ad-filter off
  naive     what a generic HTML-to-text fetch would have read instead: the
            text length and the ad URLs it would have picked up
  timing    download, and parsing with the filter on and off

Requests are sequential with a pause (default 1 s). The clean results can be
kept (--pages-dir) for the person cache; raw HTML contains ad code and is only
written with --raw-dir, for auditors, never as reading material.

  python audit_ads_online.py --targets audit_targets.json --out audit_report.json \\
      [--pages-dir pages] [--raw-dir raw] [--delay 1.0] [--limit N]
"""

import argparse
import copy
import json
import os
import sys
import time
from datetime import datetime, timezone
from html.parser import HTMLParser
from pathlib import Path
from urllib.parse import urljoin

HERE = Path(__file__).resolve().parent
ARTICLE_FIELDS = ("lines", "links", "link_original_hrefs", "tables", "nicknames", "images",
                  "footnotes", "headings", "page_metadata", "total_lines", "article_integrity")


def load_modules():
    import importlib.util
    modules = []
    for name, file in (("hololive_adblock", "hololive_adblock.py"), ("hololive_wiki_reader_v31", "hololive_wiki_reader_v31.py")):
        spec = importlib.util.spec_from_file_location(name, HERE / file)
        module = importlib.util.module_from_spec(spec)
        sys.modules[name] = module
        spec.loader.exec_module(module)
        modules.append(module)
    return modules


class NaiveText(HTMLParser):
    """Roughly what a generic web fetch converts a page into.

    Every text node outside <script>/<style> (noscript included, as common
    HTML-to-text tools do), plus every href/src it would list as a link.
    """

    def __init__(self, base):
        super().__init__(convert_charrefs=True)
        self.base, self.raw, self.chars, self.urls = base, None, 0, []

    def handle_starttag(self, tag, attrs):
        if tag in {"script", "style"}:
            self.raw = tag
        for name, value in attrs:
            if name in {"href", "src"} and value:
                try:
                    self.urls.append(urljoin(self.base, value))
                except ValueError:
                    pass

    def handle_endtag(self, tag):
        if tag == self.raw:
            self.raw = None

    def handle_data(self, data):
        if not self.raw:
            self.chars += len(" ".join(data.split()))


def audit_page(reader, adblock, target, delay_state, options):
    wiki_url = target.get("url")
    if not wiki_url:
        encoded, _ = reader.encode_title(target["title"])
        wiki_url = reader.encoded_title_url(encoded)
    argv = ["--url", wiki_url, "--all", "--all-links", "--tables", "--nicknames", "--images",
            "--surrogate-charrefs", "utf16"]
    args = reader.build_cli().parse_args(argv)
    args_off = copy.copy(args)
    args_off.ad_filter = "off"
    if delay_state["last"] is not None:
        pause = options.delay - (time.monotonic() - delay_state["last"])
        if pause > 0:
            time.sleep(pause)
    record = {"id": target["id"], "label": target.get("label"), "purpose": target.get("purpose"), "url": wiki_url}
    with adblock.NetworkLog() as network:
        started = time.perf_counter()
        try:
            raw, metadata = reader.read_page_with_layout(wiki_url, args, reader.RateLimiter())
        except reader.ReaderError as exc:
            record.update(status="error", error_code=exc.code, error=str(exc))
            return record, None, None
        finally:
            delay_state["last"] = time.monotonic()
        download = time.perf_counter() - started
    metadata.update(source="http", from_cache=False)
    source = reader.decode_and_prepare(raw, metadata, args)
    started = time.perf_counter()
    strict_error = None
    try:
        strict = reader.make_result(raw, metadata, args, source)
    except reader.ReaderError as exc:
        strict, strict_error = None, {"code": exc.code, "message": str(exc)}
    parse_strict = time.perf_counter() - started
    started = time.perf_counter()
    unfiltered = reader.make_result(raw, metadata, args_off, source)
    parse_off = time.perf_counter() - started
    html = source[0]
    naive = NaiveText(wiki_url)
    naive.feed(html)
    naive.close()
    naive_ad_urls = sorted({url for url in naive.urls if adblock.url_category(url) == "ad"})
    differences = [] if strict is None else [key for key in ARTICLE_FIELDS if strict.get(key) != unfiltered.get(key)]
    article_chars = sum(len(line["text"]) for line in (strict or unfiltered)["lines"])
    record.update({
        "status": "ok" if strict is not None else "refused",
        "http_status": metadata.get("http_status"), "fetched_at": metadata.get("fetched_at"),
        "html_sha256": unfiltered["html_sha256"], "html_bytes": metadata.get("html_bytes"),
        "wire_bytes": metadata.get("wire_bytes"), "http_requests": metadata.get("http_requests"),
        "network": network.summary(), "reader_network_hosts": metadata.get("network_hosts"),
        "title": unfiltered["page_title"], "last_updated": unfiltered["page_metadata"].get("last_updated"),
        "total_lines": unfiltered["total_lines"],
        "article_closed": unfiltered["article_integrity"]["closing_tag_observed"],
        "markup": adblock.inventory(html, wiki_url),
        "ad_filter": strict["ad_filter"] if strict else None, "strict_error": strict_error,
        "article_fields_changed_by_filter": differences,
        "naive_fetch": {"text_chars": naive.chars, "ad_urls": naive_ad_urls[:20], "ad_url_count": len(naive_ad_urls)},
        "article_text_chars": article_chars,
        "seconds": {"download": round(download, 3), "parse_filter_on": round(parse_strict, 3),
                    "parse_filter_off": round(parse_off, 3)},
        "warnings": (strict or unfiltered)["warnings"],
    })
    return record, strict, raw


def summarize(records, network):
    ok = [r for r in records if r["status"] == "ok"]

    def total(key):
        return sum(r["seconds"][key] for r in ok)

    return {
        "pages": len(records), "ok": len(ok), "errors": [r["id"] for r in records if r["status"] != "ok"],
        "http_destinations": network["http_destinations"], "non_wiki_destinations": network["non_wiki_destinations"],
        "ad_destinations": network["ad_destinations"],
        "pages_with_ad_slots_in_markup": sum(1 for r in ok if r["markup"]["by_zone"]),
        "ad_elements_in_markup": sum(z.get("ad", 0) for r in ok for z in r["markup"]["by_zone"].values()),
        "ad_elements_inside_article": sum(len(r["markup"]["article_ad_elements"]) for r in ok),
        "ad_slots_skipped_by_reader": sum(r["ad_filter"]["skipped"]["by_kind"].get("ad", 0) for r in ok),
        "chrome_skipped_by_reader": sum(r["ad_filter"]["skipped"]["by_kind"].get("chrome", 0) for r in ok),
        "ad_urls_in_article_links_images": sum(r["ad_filter"]["output_scan"]["ad_urls_structural_count"] for r in ok),
        "ad_urls_in_article_text": sum(r["ad_filter"]["output_scan"]["ad_urls_textual_count"] for r in ok),
        "affiliate_urls_in_article": sum(r["ad_filter"]["output_scan"]["affiliate_urls_count"] for r in ok),
        "pages_where_filter_changed_article": [r["id"] for r in ok if r["article_fields_changed_by_filter"]],
        "pages_with_unclosed_article": [r["id"] for r in ok if not r["article_closed"]],
        "naive_fetch_ad_urls": sum(r["naive_fetch"]["ad_url_count"] for r in ok),
        "naive_fetch_text_chars": sum(r["naive_fetch"]["text_chars"] for r in ok),
        "article_text_chars": sum(r["article_text_chars"] for r in ok),
        "html_bytes": sum(r["html_bytes"] or 0 for r in ok),
        "seconds": {"download": round(total("download"), 2), "parse_filter_on": round(total("parse_filter_on"), 2),
                    "parse_filter_off": round(total("parse_filter_off"), 2)},
    }


def main(argv=None):
    for stream in (sys.stdout, sys.stderr):
        try:
            stream.reconfigure(encoding="utf-8")
        except (AttributeError, OSError, ValueError):
            pass
    cli = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    cli.add_argument("--targets", type=Path, default=HERE / "audit_targets.json")
    cli.add_argument("--out", type=Path, required=True, help="JSON report")
    cli.add_argument("--pages-dir", type=Path, help="keep each page's strict reader result here")
    cli.add_argument("--raw-dir", type=Path, help="keep raw HTML here (contains ad code; audit use only)")
    cli.add_argument("--delay", type=float, default=1.0, help="seconds between requests (min 0.5)")
    cli.add_argument("--limit", type=int, help="first N targets only")
    options = cli.parse_args(argv)
    if options.delay < 0.5:
        cli.error("--delay must be at least 0.5")
    adblock, reader = load_modules()
    targets = json.loads(options.targets.read_text(encoding="utf-8"))["targets"][:options.limit]
    for directory in (options.pages_dir, options.raw_dir):
        if directory:
            directory.mkdir(parents=True, exist_ok=True)
    records, delay_state = [], {"last": None}
    started = datetime.now(timezone.utc).isoformat()
    with adblock.NetworkLog() as whole_run:
        for number, target in enumerate(targets, 1):
            record, strict, raw = audit_page(reader, adblock, target, delay_state, options)
            records.append(record)
            if strict is not None and options.pages_dir:
                (options.pages_dir / (target["id"] + ".json")).write_text(
                    json.dumps(strict, ensure_ascii=False), encoding="utf-8")
            if raw is not None and options.raw_dir:
                (options.raw_dir / (target["id"] + ".html")).write_bytes(raw)
            if record["status"] == "ok":
                skipped = record["ad_filter"]["skipped"]["by_kind"]
                print(f"[{number:2d}/{len(targets)}] ok  {record['label']}  hosts={record['network']['http_destinations']} "
                      f"ad slots in page={sum(z.get('ad', 0) for z in record['markup']['by_zone'].values())} "
                      f"skipped ad/chrome={skipped.get('ad', 0)}/{skipped.get('chrome', 0)} "
                      f"ad URLs in article={record['ad_filter']['output_scan']['ad_urls_structural_count']} "
                      f"changed={record['article_fields_changed_by_filter'] or '-'} "
                      f"{record['seconds']['download']}s", flush=True)
            else:
                print(f"[{number:2d}/{len(targets)}] {record['status']} {record['label']}: "
                      f"{record.get('error') or record.get('strict_error')}", flush=True)
    report = {"schema": "hololive-ad-audit/1", "started_at": started,
              "finished_at": datetime.now(timezone.utc).isoformat(),
              "reader_version": reader.VERSION, "adblock_version": adblock.VERSION,
              "python": sys.version.split()[0], "platform": sys.platform,
              "proxy_in_use": bool(os.environ.get("HTTPS_PROXY") or os.environ.get("https_proxy")),
              "run_network": whole_run.summary(), "summary": summarize(records, whole_run.summary()),
              "pages": records}
    options.out.write_text(json.dumps(report, ensure_ascii=False, indent=1), encoding="utf-8")
    print(json.dumps(report["summary"], ensure_ascii=False, indent=1))
    summary = report["summary"]
    failed = (summary["errors"] or summary["non_wiki_destinations"] or summary["ad_urls_in_article_links_images"]
              or summary["pages_where_filter_changed_article"])
    return 1 if failed else 0


if __name__ == "__main__":
    raise SystemExit(main())
