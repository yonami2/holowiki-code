@echo off
rem Runs hololive_wiki_reader_v31.py in Python's UTF-8 mode with the py launcher if present, else python.
setlocal
set PYTHONUTF8=1
set "PYEXE=python"
where py >nul 2>nul && set "PYEXE=py -3"
%PYEXE% "%~dp0hololive_wiki_reader_v31.py" %*
exit /b %errorlevel%
