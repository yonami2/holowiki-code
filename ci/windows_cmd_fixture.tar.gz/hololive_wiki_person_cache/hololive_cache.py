#!/usr/bin/env python3
"""Command-line entry point of the hololive wiki person cache v2.

The implementation lives in hololive_cache_core.py. Keeping this script small
lets Python reuse that module's cached bytecode (__pycache__) on every run
instead of recompiling it. `import hololive_cache` exposes the same API
(Cache, Person, Page, select_article_lines, ...).
"""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from hololive_cache_core import *  # noqa: E402,F401,F403
from hololive_cache_core import run_cli  # noqa: E402

if __name__ == "__main__":
    raise SystemExit(run_cli())
